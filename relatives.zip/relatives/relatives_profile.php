<?php
session_start();

header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

include 'conn.php';

if (!isset($_SESSION['relative_id'])) {
    echo "<script>
        alert('Please log in first');
        window.location.href = '/elderlycare/index.php';
    </script>";
    exit();
}

$relative_id = $_SESSION['relative_id'];

// Fetch relative info
$stmt = $conn->prepare("SELECT * FROM relatives WHERE id = ?");
$stmt->bind_param("i", $relative_id);
$stmt->execute();
$result = $stmt->get_result();
$relative = $result->fetch_assoc();
$stmt->close();

// Set relative name
$relativeName = !empty($relative['name']) ? $relative['name'] : 'Relative';
$_SESSION['relative_name'] = $relativeName;
$stmt = $conn->prepare("
    SELECT ci.full_name AS caregiver_name
    FROM relatives r
    LEFT JOIN caregivers c ON r.caregiver_id = c.id
    LEFT JOIN caregivers_info ci ON ci.caregiver_id = c.id
    WHERE r.id = ?
");
$stmt->bind_param("i", $relative_id);
$stmt->execute();
$result = $stmt->get_result();
if ($row = $result->fetch_assoc()) {
    $caregiverName = !empty($row['caregiver_name']) ? $row['caregiver_name'] : 'Not Assigned';
} else {
    $caregiverName = 'Not Assigned';
}
$stmt->close();

$notifications = [];

$notifQuery = "SELECT * FROM relative_notification WHERE relative_id = ? ORDER BY created_at DESC LIMIT 5";
$stmt = $conn->prepare($notifQuery);
$stmt->bind_param("i", $relative_id);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $notifications[] = $row;
}
$stmt->close();

if (isset($_GET['notif_id'])) {
    $notif_id = $_GET['notif_id'];
    $markAsRead = "UPDATE relative_notification SET is_read = 1 WHERE id = ?";
    $stmt = $conn->prepare($markAsRead);
    $stmt->bind_param("i", $notif_id);
    $stmt->execute();
    $stmt->close();
}

$sql = "SELECT COUNT(*) AS notifCount FROM relative_notification WHERE relative_id = ? AND is_read = 0";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $relative_id);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();
$notifCount = $row['notifCount'];
$stmt->close();


?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Patients</title>

<!-- Favicons -->
<link href="/elderlycare/assets/img/logo.png" rel="icon">

<!-- Google Fonts -->
<link href="https://fonts.gstatic.com" rel="preconnect">
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

<!-- Vendor CSS Files -->
<link href="/elderlycare/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/quill/quill.snow.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/quill/quill.bubble.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/remixicon/remixicon.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/simple-datatables/style.css" rel="stylesheet">

<!-- Template Main CSS File -->
<link href="/elderlycare/assets/css/style.css" rel="stylesheet">
</head>
<style>
  
 
  .notification-item.unread {
    background-color: #f0f8ff;
  }
  .notification-item.unread p {
    font-weight: bold;
  }

.dropdown-menu.notifications {
  max-height: 300px;      
  overflow-y: auto;
  padding-right: 0;       
}


.dropdown-menu.notifications::-webkit-scrollbar {
  width: 6px;
}
.dropdown-menu.notifications::-webkit-scrollbar-track {
  background: transparent;
}
.dropdown-menu.notifications::-webkit-scrollbar-thumb {
  background-color: rgba(0,0,0,0.2);
  border-radius: 3px;
}
@media (max-width: 576px), (max-width: 780px) {
  .dropdown-menu.profile {
    position: fixed !important;
    top: 60px;
    left: 0 !important;
    right: 0 !important;
    border-radius: 0;
    z-index: 1050;
  }
}

@media (max-width: 576px) {
  .dropdown-menu.notifications {
    position: fixed !important;
    top: 60px;
    left: 0 !important;
    right: 0 !important;
    width: 100vw !important;
    max-width: none !important;
    border-radius: 0;
    z-index: 1050;
  }
}
</style>
<body>


<header id="header" class="header fixed-top d-flex align-items-center">
  <div class="d-flex align-items-center justify-content-between">
    <a href="relatives_dashboard.php" class="logo d-flex align-items-center">
      <img src="/elderlycare/assets/img/logo.png" alt="Logo" />
      <span class="d-none d-lg-block">ElderlyCare</span>
    </a>
    <i class="bi bi-list toggle-sidebar-btn"></i>
  </div>

  <nav class="header-nav ms-auto">
    <ul class="d-flex align-items-center">

     <li class="nav-item dropdown">
  <a class="nav-link nav-icon" href="#" data-bs-toggle="dropdown">
    <i class="bi bi-bell"></i>
    <?php if ($notifCount > 0): ?>
      <span class="badge bg-primary badge-number"><?= $notifCount; ?></span>
    <?php endif; ?>
  </a>

  <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow notifications">
    <li class="dropdown-header">
      You have <?= $notifCount; ?> new notification<?= $notifCount !== 1 ? 's' : ''; ?>
    </li>
    <li><hr class="dropdown-divider"></li>

    <?php if (count($notifications) > 0): ?>
      <?php foreach ($notifications as $note): 
        $liClass = $note['is_read'] == 0 ? 'notification-item unread' : 'notification-item';
      ?>
        <li class="<?= $liClass ?>">
          <i class="bi bi-info-circle text-info"></i>
          <div>
            <a href="?notif_id=<?= $note['id']; ?>">
              <p><?= htmlspecialchars($note['message']); ?></p>
              <small class="text-muted"><?= date("M d, Y H:i", strtotime($note['created_at'])); ?></small>
            </a>
          </div>
        </li>
        <li><hr class="dropdown-divider"></li>
      <?php endforeach; ?>
    <?php else: ?>
      <li class="notification-item">
        <div><p>No new notifications</p></div>
      </li>
    <?php endif; ?>
  </ul>
</li>      
      <!-- Profile Dropdown -->
      <li class="nav-item dropdown pe-3">
        <a class="nav-link nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown">
          <?php if (!empty($relative['pic'])): ?>
            <img src="uploads/relatives/<?= htmlspecialchars($relative['pic']) ?>"
                 alt="Profile"
                 class="rounded-circle"
                 style="object-fit: cover; width: 40px; height: 40px;" />
          <?php else: ?>
            <div class="rounded-circle bg-secondary d-flex justify-content-center align-items-center"
                 style="width: 40px; height: 40px;">
              <i class="bi bi-person text-white fs-5"></i>
            </div>
          <?php endif; ?>
          <span class="d-none d-md-block dropdown-toggle ps-2"><?= htmlspecialchars($relativeName) ?></span>
        </a>

        <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow profile">
          <li class="dropdown-header">
            <h6><?= htmlspecialchars($relativeName) ?></h6>
            <span>Relative</span>
          </li>

          <li><hr class="dropdown-divider" /></li>

          <li>
            <a class="dropdown-item d-flex align-items-center" href="relatives_profile.php">
              <i class="bi bi-person"></i>
              <span>My Profile</span>
            </a>
          </li>

          <li><hr class="dropdown-divider" /></li>

          <li>
            <a class="dropdown-item d-flex align-items-center" href="/elderlycare/logout.php">
              <i class="bi bi-box-arrow-right"></i>
              <span>Sign Out</span>
            </a>
          </li>
        </ul>
      </li>

    </ul>
  </nav>
</header>

<aside id="sidebar" class="sidebar">
  <ul class="sidebar-nav" id="sidebar-nav">
    <li class="nav-item">
      <a class="nav-link collapsed" href="relatives_dashboard.php">
        <i class="bi bi-house-door"></i>
        <span>Dashboard</span>
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="admin_profile.php">
        <i class="bi bi-person"></i>
        <span>Profile</span>
      </a>
    </li>
  </ul>
</aside>

<main id="main" class="main">
  <div class="pagetitle">
    <h2>Relative Profile</h2>
    <nav>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="RelativeDashboard.php">Home</a></li>
        <li class="breadcrumb-item active">Profile</li>
      </ol>
    </nav>
  </div>

  <section class="section profile">
    <div class="row justify-content-center">
      <div class="card">
        <div class="card-body pt-3">

          <ul class="nav nav-tabs nav-tabs-bordered">
            <li class="nav-item">
              <button class="nav-link active" data-bs-toggle="tab" data-bs-target="#relative-overview">Overview</button>
            </li>
            <li class="nav-item">
              <button class="nav-link" data-bs-toggle="tab" data-bs-target="#edit-relative-profile">Edit Profile</button>
            </li>
            <li class="nav-item">
              <button class="nav-link" data-bs-toggle="tab" data-bs-target="#relative-change-password">Change Password</button>
            </li>
          </ul>

          <div class="tab-content pt-2">

            <div class="tab-pane fade show active" id="relative-overview">
              <h5 class="card-title">Profile Details</h5>

              <div class="row mb-3">
                <div class="col-lg-3 col-md-4 label">Profile Picture</div>
                <div class="col-lg-6 col-md-8 text-center">
                  <?php if (!empty($relative['pic'])): ?>
                    <img src="uploads/relatives/<?= htmlspecialchars($relative['pic']) ?>" 
                        alt="Profile Picture" 
                        class="img-fluid" 
                        style="max-width: 150px; border-radius: 20%;">
                  <?php else: ?>
                    <div style="font-size: 100px; color: #ccc;">
                      <i class="bi bi-person-circle"></i>
                    </div>
                  <?php endif; ?>
                </div>
              </div>

              <div class="row mb-3">
                <div class="col-lg-3 col-md-4 label">Name</div>
                <div class="col-lg-9 col-md-8"><?= htmlspecialchars($relative['name']) ?></div>
              </div>

              <div class="row mb-3">
                <div class="col-lg-3 col-md-4 label">Username</div>
                <div class="col-lg-9 col-md-8"><?= htmlspecialchars($relative['username']) ?></div>
              </div>

              <div class="row mb-3">
                <div class="col-lg-3 col-md-4 label">Email</div>
                <div class="col-lg-9 col-md-8"><?= htmlspecialchars($relative['email']) ?></div>
              </div>

              <div class="row mb-3">
                <div class="col-lg-3 col-md-4 label">Assigned Caregiver</div>
                <div class="col-lg-9 col-md-8"><?= htmlspecialchars($caregiverName) ?></div>
              </div>
          </div>
                      
          <div class="tab-pane fade" id="edit-relative-profile">
            <form action="process.php" method="POST" enctype="multipart/form-data">
              <input type="hidden" name="relative_id" value="<?= $relative['id'] ?>">
              <input type="hidden" name="remove_image" id="removeImageFlag" value="0">

              <div class="row mb-3">
                <label for="profileImage" class="col-md-7 col-lg-5 col-form-label">Profile Image</label>
                <div class="col-lg-2 col-md-8 text-center">

                  <?php if (!empty($relative['pic'])): ?>
                    <img src="uploads/relatives/<?= $relative['pic'] ?>" 
                        alt="Profile" 
                        class="img-fluid mb-3 rounded-circle" 
                        style="max-width: 150px;" 
                        id="profileImagePreview">
                  <?php else: ?>
                    <div class="mb-3" style="font-size: 100px; color: #ccc;" id="profileImagePreview">
                      <i class="bi bi-person-circle"></i>
                    </div>
                  <?php endif; ?>

                  <input type="file" name="relative_pic" class="form-control" id="profileImageInput" style="display: none;" onchange="previewImage(event)">

                  <div class="d-flex justify-content-center gap-2">
                    <a href="javascript:void(0);" class="btn" title="Upload new profile image" onclick="document.getElementById('profileImageInput').click();">
                      <i class="bi bi-upload"></i> Upload
                    </a>
                    <a href="#" class="btn" title="Remove my profile image" onclick="removeProfileImage(); return false;">
                      <i class="bi bi-trash"></i> Remove
                    </a>
                  </div>
                </div>
              </div>

              <div class="row mb-3">
                <label class="col-md-4 col-lg-3 col-form-label">Username</label>
                <div class="col-md-8 col-lg-9">
                  <input name="username" type="text" class="form-control" value="<?= htmlspecialchars($relative['username']) ?>">
                </div>
              </div>

              <div class="row mb-3">
                <label class="col-md-4 col-lg-3 col-form-label">Name</label>
                <div class="col-md-8 col-lg-9">
                  <input name="name" type="text" class="form-control" value="<?= htmlspecialchars($relative['name']) ?>">
                </div>
              </div>

              <div class="row mb-3">
                <label class="col-md-4 col-lg-3 col-form-label">Email</label>
                <div class="col-md-8 col-lg-9">
                  <input name="email" type="email" class="form-control" value="<?= htmlspecialchars($relative['email']) ?>">
                </div>
              </div>

              <div class="text-center">
                <button type="submit" name="updateRelative" class="btn">Save Changes</button>
              </div>
            </form>
          </div>


            <!-- Change Password Tab -->
            <div class="tab-pane fade pt-3" id="relative-change-password">
                  <form action="process.php" method="POST">
                      <input type="hidden" name="relative_id" value="<?= $relative['id'] ?>">

                      <!-- Current Password -->
                      <div class="row mb-3">
                          <label for="current_password" class="col-md-4 col-lg-3 col-form-label">Current Password</label>
                          <div class="col-md-8 col-lg-9">
                              <div class="input-group">
                                  <input name="current_password" id="current_password" type="password" class="form-control" placeholder="Enter Current Password">
                                  <span class="input-group-text" onclick="togglePassword('current_password', this)">
                                      <i class="bi bi-eye"></i>
                                  </span>
                              </div>
                          </div>
                      </div>

                      <!-- New Password -->
                      <div class="row mb-3">
                          <label for="new_password" class="col-md-4 col-lg-3 col-form-label">New Password</label>
                          <div class="col-md-8 col-lg-9">
                              <div class="input-group">
                                  <input name="new_password" id="new_password" type="password" class="form-control" placeholder="Enter New Password">
                                  <span class="input-group-text" onclick="togglePassword('new_password', this)">
                                      <i class="bi bi-eye"></i>
                                  </span>
                              </div>
                          </div>
                      </div>

                      <!-- Confirm New Password -->
                      <div class="row mb-3">
                          <label for="confirm_password" class="col-md-4 col-lg-3 col-form-label">Confirm New Password</label>
                          <div class="col-md-8 col-lg-9">
                              <div class="input-group">
                                  <input name="confirm_password" id="confirm_password" type="password" class="form-control" placeholder="Re-enter New Password">
                                  <span class="input-group-text" onclick="togglePassword('confirm_password', this)">
                                      <i class="bi bi-eye"></i>
                                  </span>
                              </div>
                          </div>
                      </div>

                      <div class="text-center">
                          <button type="submit" name="changeRelativePassword" class="btn">Change Password</button>
                      </div>
                  </form>
              </div>
            </div>
          </div>
        </div>
  </section>
</main>
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

<script>
    function togglePassword(inputId, toggleElement) {
        const input = document.getElementById(inputId);
        const icon = toggleElement.querySelector('i');

        if (input.type === 'password') {
            input.type = 'text';
            icon.classList.remove('bi-eye');
            icon.classList.add('bi-eye-slash');
        } else {
            input.type = 'password';
            icon.classList.remove('bi-eye-slash');
            icon.classList.add('bi-eye');
        }
    }
</script>




<script>
function previewImage(event) {
  const reader = new FileReader();
  reader.onload = function () {
    const output = document.getElementById('profileImagePreview');
    if (output.tagName === 'IMG') {
      output.src = reader.result;
    } else {
      output.outerHTML = `<img src="${reader.result}" class="img-fluid mb-3 rounded-circle" style="max-width: 150px;" id="profileImagePreview">`;
    }
  };
  reader.readAsDataURL(event.target.files[0]);
}

function removeProfileImage() {
  document.getElementById('removeImageFlag').value = '1';
  const preview = document.getElementById('profileImagePreview');
  if (preview) preview.style.display = 'none';
}
</script>





<footer id="footer" class="footer">
    <div class="copyright">
        &copy; Copyright <strong><span>FilSha</span></strong>. All Rights Reserved
    </div>
    <div class="credits">
       
    </div>
</footer>

<a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">

<script src="/elderlycare/assets/js/main.js"></script>
<script src="/elderlycare/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>


</body>

</html>
