<?php
session_start(); 

include 'conn.php'; 
if (isset($_POST['relative_login'])) {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    $username = mysqli_real_escape_string($conn, $username);
    $password = mysqli_real_escape_string($conn, $password);

    if (empty($username) || empty($password)) {
        $_SESSION['message'] = "Please enter your username and password.";
        header("Location: relatives_login.php");
        exit;
    }

    $query = "SELECT id, username, password, name FROM relatives WHERE username = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "s", $username);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($result && mysqli_num_rows($result) === 1) {
        $row = mysqli_fetch_assoc($result);

        if (password_verify($password, $row['password'])) {
            $_SESSION['relative_id'] = $row['id'];
            $_SESSION['username'] = $row['username'];
            $_SESSION['user_type'] = 'relative';
            $_SESSION['message'] = "Login successful! Welcome back, " . $row['name'] . "!";

            header("Location: relatives_dashboard.php");
            exit;
        } else {
            $_SESSION['message'] = "Incorrect password. Please try again.";
            header("Location: relatives_login.php");
            exit;
        }
    } else {
        $_SESSION['message'] = "Username not found.";
        header("Location: relatives_login.php");
        exit;
    }
}


if (isset($_POST['relative_login'])) {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    $username = mysqli_real_escape_string($conn, $username);
    $password = mysqli_real_escape_string($conn, $password);

    if (empty($username) || empty($password)) {
        echo "<script>
                alert('Please enter your username and password.');
                window.location.href = 'relatives_login.php';
              </script>";
        exit;
    }

    $query = "SELECT id, username, password FROM relatives WHERE username = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "s", $username);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($result && mysqli_num_rows($result) === 1) {
        $row = mysqli_fetch_assoc($result);

        if (password_verify($password, $row['password'])) {
            $_SESSION['relative_id'] = $row['id'];
            $_SESSION['username'] = $row['username'];

            echo "<script>
                    alert('Login successful!');
                    window.location.href = 'relatives_dashboard.php';
                  </script>";
            exit;
        } else {
            echo "<script>
                    alert('Invalid username or password.');
                    window.location.href = 'relatives_login.php';
                  </script>";
            exit;
        }
    } else {
        echo "<script>
                alert('Username not found.');
                window.location.href = 'relatives_login.php';
              </script>";
        exit;
    }
}


if (isset($_POST['updateRelative'])) {
    $relative_id = $_POST['relative_id'];
    $username = trim($_POST['username']);
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $removeImage = isset($_POST['remove_image']) && $_POST['remove_image'] == '1';


    $username = mysqli_real_escape_string($conn, $username);
    $name = mysqli_real_escape_string($conn, $name);
    $email = mysqli_real_escape_string($conn, $email);

  
    $query = mysqli_query($conn, "SELECT pic FROM relatives WHERE id = $relative_id");
    $row = mysqli_fetch_assoc($query);
    $currentImage = $row['pic'];
    $profileImageName = $currentImage;


    if (isset($_FILES['relative_pic']) && $_FILES['relative_pic']['error'] === UPLOAD_ERR_OK) {
        $fileTmp = $_FILES['relative_pic']['tmp_name'];
        $fileName = basename($_FILES['relative_pic']['name']);
        $fileExt = pathinfo($fileName, PATHINFO_EXTENSION);
        $allowedExt = ['jpg', 'jpeg', 'png', 'gif'];

        if (in_array(strtolower($fileExt), $allowedExt)) {
            $newFileName = 'relative_' . time() . '.' . $fileExt;
            $destination = 'uploads/relatives/' . $newFileName;

            if (!is_dir('uploads/relatives')) {
                mkdir('uploads/relatives', 0777, true);
            }

            if (move_uploaded_file($fileTmp, $destination)) {
                // Delete old file
                if (!empty($currentImage) && file_exists("uploads/relatives/$currentImage")) {
                    unlink("uploads/relatives/$currentImage");
                }
                $profileImageName = $newFileName;
            } else {
                $_SESSION['error'] = "Failed to upload image.";
                header("Location: relatives_profile.php");
                exit();
            }
        }
    }


    if ($removeImage) {
        if (!empty($currentImage) && file_exists("uploads/relatives/$currentImage")) {
            unlink("uploads/relatives/$currentImage");
        }
        $profileImageName = ''; 
    }

  
    $sql = "UPDATE relatives SET username = ?, name = ?, email = ?, pic = ? WHERE id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "ssssi", $username, $name, $email, $profileImageName, $relative_id);

   if (mysqli_stmt_execute($stmt)) {
    echo "<script>
            alert('Profile updated successfully.');
            window.location.href = 'relatives_profile.php';
          </script>";
} else {
    echo "<script>
            alert('Failed to update profile.');
            window.location.href = 'relatives_profile.php';
          </script>";
}
mysqli_stmt_close($stmt);
exit();

}




if (isset($_POST['changeRelativePassword'])) {


    $relative_id = $_POST['relative_id'];
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

   
    if ($new_password !== $confirm_password) {
        echo "<script>
                alert('New password and confirm password do not match.');
                window.location.href = 'relatives_profile.php';
              </script>";
        exit;
    }

    
    $stmt = $conn->prepare("SELECT password FROM relatives WHERE id = ?");
    $stmt->bind_param("i", $relative_id);
    $stmt->execute();
    $stmt->bind_result($hashed_password);
    $stmt->fetch();
    $stmt->close();

   
    if (!password_verify($current_password, $hashed_password)) {
        echo "<script>
                alert('Current password is incorrect.');
                window.location.href = 'relatives_profile.php';
              </script>";
        exit;
    }


    $new_hashed = password_hash($new_password, PASSWORD_DEFAULT);
    $stmt = $conn->prepare("UPDATE relatives SET password = ? WHERE id = ?");
    $stmt->bind_param("si", $new_hashed, $relative_id);

    if ($stmt->execute()) {
        session_unset();
        session_destroy();
        echo "<script>
                alert('Password changed successfully. Please log in again.');
                window.location.href = 'relatives_login.php';
              </script>";
    } else {
        echo "<script>
                alert('Failed to update password.');
                window.location.href = 'relatives_profile.php';
              </script>";
    }

    $stmt->close();
    exit;
}

?>
