<?php
session_start();


header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

include 'conn.php'; 


if (!isset($_SESSION['relative_id'])) {
    echo "<script>
        alert('Please log in first');
        window.location.href = '/elderlycare/index.php';
    </script>";
    exit();
}

$relativeName = 'Relative';
$relative = null;
$patient = null;

$userId = $_SESSION['relative_id'];


$stmt = $conn->prepare("SELECT name FROM relatives WHERE id = ?");
$stmt->bind_param("i", $userId);
$stmt->execute();
$stmt->bind_result($name);
if ($stmt->fetch()) {
    $relativeName = $name;
    $_SESSION['relative_name'] = $name;
}
$stmt->close();

$stmt = $conn->prepare("SELECT * FROM relatives WHERE id = ?");
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();
$relative = $result->fetch_assoc();
$stmt->close();

if ($relative && !empty($relative['patient_id'])) {
    $patient_id = $relative['patient_id'];

    $stmt = $conn->prepare("SELECT * FROM patients WHERE id = ?");
    $stmt->bind_param("i", $patient_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $patient = $result->fetch_assoc();
    $stmt->close();
}


$notifications = [];


$notifQuery = "SELECT * FROM relative_notification WHERE relative_id = ? ORDER BY created_at DESC LIMIT 5";
$stmt = $conn->prepare($notifQuery);
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $notifications[] = $row;
}
$stmt->close();

if (isset($_GET['notif_id'])) {
    $notif_id = $_GET['notif_id'];
    $markAsRead = "UPDATE relative_notification SET is_read = 1 WHERE id = ?";
    $stmt = $conn->prepare($markAsRead);
    $stmt->bind_param("i", $notif_id);
    $stmt->execute();
    $stmt->close();
}


$sql = "SELECT COUNT(*) AS notifCount FROM relative_notification WHERE relative_id = ? AND is_read = 0";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();
$notifCount = $row['notifCount'];
$stmt->close();
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>My Dashboard</title>

  <link href="/elderlycare/assets/img/logo.png" rel="icon" />
  <link href="https://fonts.gstatic.com" rel="preconnect" />
  <link href="https://fonts.googleapis.com/css?family=Open+Sans|Nunito|Poppins" rel="stylesheet" />
  <link href="/elderlycare/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet" />
  <link href="/elderlycare/assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet" />
  <link href="/elderlycare/assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet" />
  <link href="/elderlycare/assets/vendor/quill/quill.snow.css" rel="stylesheet" />
  <link href="/elderlycare/assets/vendor/quill/quill.bubble.css" rel="stylesheet" />
  <link href="/elderlycare/assets/vendor/remixicon/remixicon.css" rel="stylesheet" />
  <link href="/elderlycare/assets/vendor/simple-datatables/style.css" rel="stylesheet" />
  <link href="/elderlycare/assets/css/style.css" rel="stylesheet" />
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">


  <style>
    .notification-item.unread {
  background-color: #eef6ff; 
  font-weight: bold;
}

    .notification-item.unread p {
      font-weight: bold;
    }
    .notifications {
      max-height: 300px;
      overflow-y: auto;
    }

    .calendar-wrapper {
      font-family: Arial, sans-serif;
      margin-top: 20px;
    }
    table {
      width: 100%;
      border-collapse: collapse;
    }
    th, td {
      padding: 10px;
      text-align: center;
      vertical-align: middle;
      border: 1px solid #ddd;
    }
    th {
      background-color: #f4f4f4;
      font-weight: bold;
    }
    .empty {
      background-color: #f9f9f9;
    }
    .day {
      position: relative;
      padding: 10px;
      transition: background-color 0.3s;
      cursor: pointer;
    }
    .day:hover {
      background-color: #f0f0f0;
    }
    .appointment {
      margin-top: 5px;
      background-color: rgb(93, 110, 206);
      color: white;
      padding: 5px;
      border-radius: 5px;
      font-size: 12px;
      text-align: left;
      display: block;
    }
    .appointment strong {
      display: block;
    }
    .calendar-nav {
      display: flex;
      justify-content: space-between;
      margin-bottom: 15px;
    }
    .calendar-nav form {
      margin: 0;
    }
    .past-appointment {
      background-color: rgb(241, 88, 88) !important;
    }
    .empty {
      background-color: #f8f9fa;
    }
    
  .scrollable-card {
    max-height: 300px;
    overflow-y: auto;
  }
  .modal{
    margin-top:200px; 
    margin-bottom: auto;
  }
@media (max-width: 576px), (max-width: 780px) {
  .dropdown-menu.profile {
    position: fixed !important;
    top: 60px;
    left: 0 !important;
    right: 0 !important;
    border-radius: 0;
    z-index: 1050;
  }
}

@media (max-width: 576px) {
  .dropdown-menu.notifications {
    position: fixed !important;
    top: 60px;
    left: 0 !important;
    right: 0 !important;
    width: 100vw !important;
    max-width: none !important;
    border-radius: 0;
    z-index: 1050;
  }
}
  </style>
</head>

<body>
<header id="header" class="header fixed-top d-flex align-items-center">
  <div class="d-flex align-items-center justify-content-between">
    <a href="relatives_dashboard.php" class="logo d-flex align-items-center">
      <img src="/elderlycare/assets/img/logo.png" alt="Logo" />
      <span class="d-none d-lg-block">ElderlyCare</span>
    </a>
    <i class="bi bi-list toggle-sidebar-btn"></i>
  </div>

  <nav class="header-nav ms-auto">
    <ul class="d-flex align-items-center">

     <li class="nav-item dropdown">
  <a class="nav-link nav-icon" href="#" data-bs-toggle="dropdown">
    <i class="bi bi-bell"></i>
    <?php if ($notifCount > 0): ?>
      <span class="badge bg-primary badge-number"><?= $notifCount; ?></span>
    <?php endif; ?>
  </a>

  <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow notifications">
    <li class="dropdown-header">
      You have <?= $notifCount; ?> new notification<?= $notifCount !== 1 ? 's' : ''; ?>
    </li>
    <li><hr class="dropdown-divider"></li>

    <?php if (count($notifications) > 0): ?>
      <?php foreach ($notifications as $note): 
        $liClass = $note['is_read'] == 0 ? 'notification-item unread' : 'notification-item';
      ?>
        <li class="<?= $liClass ?>">
          <i class="bi bi-info-circle text-info"></i>
          <div>
            <a href="?notif_id=<?= $note['id']; ?>">
              <p><?= htmlspecialchars($note['message']); ?></p>
              <small class="text-muted"><?= date("M d, Y H:i", strtotime($note['created_at'])); ?></small>
            </a>
          </div>
        </li>
        <li><hr class="dropdown-divider"></li>
      <?php endforeach; ?>
    <?php else: ?>
      <li class="notification-item">
        <div><p>No new notifications</p></div>
      </li>
    <?php endif; ?>
  </ul>
</li>




      
      <!-- Profile Dropdown -->
      <li class="nav-item dropdown pe-3">
        <a class="nav-link nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown">
          <?php if (!empty($relative['pic'])): ?>
            <img src="uploads/relatives/<?= htmlspecialchars($relative['pic']) ?>"
                 alt="Profile"
                 class="rounded-circle"
                 style="object-fit: cover; width: 40px; height: 40px;" />
          <?php else: ?>
            <div class="rounded-circle bg-secondary d-flex justify-content-center align-items-center"
                 style="width: 40px; height: 40px;">
              <i class="bi bi-person text-white fs-5"></i>
            </div>
          <?php endif; ?>
          <span class="d-none d-md-block dropdown-toggle ps-2"><?= htmlspecialchars($relativeName) ?></span>
        </a>

        <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow profile">
          <li class="dropdown-header">
            <h6><?= htmlspecialchars($relativeName) ?></h6>
            <span>Relative</span>
          </li>

          <li><hr class="dropdown-divider" /></li>

          <li>
            <a class="dropdown-item d-flex align-items-center" href="relatives_profile.php">
              <i class="bi bi-person"></i>
              <span>My Profile</span>
            </a>
          </li>

          <li><hr class="dropdown-divider" /></li>

          <li>
            <a class="dropdown-item d-flex align-items-center" href="/elderlycare/logout.php">
              <i class="bi bi-box-arrow-right"></i>
              <span>Sign Out</span>
            </a>
          </li>
        </ul>
      </li>

    </ul>
  </nav>
</header>


<aside id="sidebar" class="sidebar">
  <h3 class="text-white text-center">Relatives Dashboard</h3>
  <ul class="sidebar-nav" id="sidebar-nav">
    <li class="nav-item"><a class="nav-link" href="relatives_dashboard.php"><i class="bi bi-house-door"></i><span>Dashboard</span></a></li>
  </ul>
</aside>
<main id="main" class="main">
  <?php if (isset($_SESSION['message'])): ?>
<div class="alert alert-success alert-dismissible fade show mt-5" 
     role="alert" 
     style="max-width: 500px; margin: 0 auto; text-align: center;">
    <?= $_SESSION['message']; ?>
</div>
<script>
    setTimeout(() => {
        const alertBox = document.querySelector('.alert');
        if(alertBox){
            alertBox.classList.remove('show');
            alertBox.classList.add('hide');
            setTimeout(() => alertBox.remove(), 300);
        }
    }, 3000); 
</script>
<?php unset($_SESSION['message']); endif; ?>

  <div class="pagetitle">
    <h2>Dashboard</h2>
    <nav>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="#">Home</a></li>
        <li class="breadcrumb-item active">Dashboard</li>
      </ol>
    </nav>
  </div>

<div class="text-center mb-4">
    <div id="welcomeAlert" class="alert alert-primary d-inline-block" role="alert" style="font-family: Tahoma, sans-serif;">
        👋 Welcome, <strong><?= htmlspecialchars($relativeName); ?></strong>! Here's your dashboard overview.
    </div>
</div>

<script>
    // Remove the alert after 5 seconds (5000 milliseconds)
    setTimeout(() => {
        const alertBox = document.getElementById('welcomeAlert');
        if (alertBox) {
            alertBox.style.transition = "opacity 0.5s"; // optional fade effect
            alertBox.style.opacity = "0";
            setTimeout(() => alertBox.remove(), 300); // remove after fade
        }
    }, 5000);
</script>

  <section class="section dashboard">

  <div class="row g-4">

  
    <div class="col-lg-4 mb-4">
      <div class="card" style="cursor: pointer;" data-bs-toggle="modal" data-bs-target="#dailyTasksModal">
        <div class="card-body scrollable-card">
          <h5 class="card-title">📋 Daily Tasks & Routines</h5>
          <ul class="list-group">
            <?php
            if (isset($relative['patient_id'])) {
              $today = date('Y-m-d');
              $patientId = $relative['patient_id'];
              $taskQuery = $conn->prepare("
          SELECT task_description, routine_time, frequency
          FROM patient_tasks
          WHERE patient_id = ?
            AND (
              task_date = ?
              OR (frequency = 'Daily' AND task_date <= ?)
              OR (frequency = 'Weekly' AND task_date <= ? AND DAYOFWEEK(task_date) = DAYOFWEEK(?))
              OR (frequency = 'Monthly' AND task_date <= ? AND DAY(task_date) = DAY(?))
            )
          ORDER BY routine_time
        ");
        $taskQuery->bind_param("issssss", $patientId, $today, $today, $today, $today, $today, $today);

              $taskQuery->execute();
              $result = $taskQuery->get_result();

              $count = 0;
              if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                  if ($count++ >= 3) break;
                  echo '<li class="list-group-item d-flex justify-content-between align-items-center flex-wrap">';
                  echo '<div><strong>' . htmlspecialchars($row['task_description']) . '</strong><br />';
                  echo '<small class="text-muted">' . htmlspecialchars($row['frequency']) . '</small></div>';
                  echo '<span class="badge bg-primary mt-2 mt-md-0">' . htmlspecialchars(date("g:i A", strtotime($row['routine_time']))) . '</span></li>';
                }
              } else {
                echo '<li class="list-group-item">No tasks assigned for today.</li>';
              }
              $taskQuery->close();
            } else {
              echo '<li class="list-group-item text-danger">No patient linked to this relative.</li>';
            }
            ?>
          </ul>
        </div>
      </div>
    </div>

   
    <div class="col-lg-4 mb-4">
      <div class="card" style="cursor: pointer;" data-bs-toggle="modal" data-bs-target="#appointmentsModal">
        <div class="card-body scrollable-card">
          <h5 class="card-title">📅 Upcoming Appointments</h5>
          <ul class="list-group">
            <?php
            $appointmentList = [];
            if (!empty($relative['patient_id'])) {
              $patientId = $relative['patient_id'];
              $today = date('Y-m-d');
              $apptStmt = $conn->prepare("SELECT title, appointment_date, appointment_time FROM appointments WHERE patient_id = ? AND appointment_date >= ? ORDER BY appointment_date ASC, appointment_time ASC LIMIT 3");
              $apptStmt->bind_param("is", $patientId, $today);
              $apptStmt->execute();
              $apptResult = $apptStmt->get_result();
              while ($row = $apptResult->fetch_assoc()) {
                $appointmentList[] = $row;
              }
              $apptStmt->close();
            }

            if (!empty($appointmentList)) {
              foreach ($appointmentList as $appt) {
                echo '<li class="list-group-item">';
                echo '<strong>' . htmlspecialchars($appt['title']) . ':</strong> ';
                echo date("F j", strtotime($appt['appointment_date'])) . ' @ ' . date("g:i A", strtotime($appt['appointment_time'])) . '<br />';
                echo '<small>' . ucfirst($appt['title']) . ' scheduled</small></li>';
              }
            } else {
              echo '<li class="list-group-item">No upcoming appointments.</li>';
            }
            ?>
          </ul>
        </div>
      </div>
    </div>


    <div class="col-lg-4 mb-4">
      <div class="card" style="cursor: pointer;" data-bs-toggle="modal" data-bs-target="#medicinesModal">
        <div class="card-body scrollable-card">
          <h5 class="card-title">💊 Daily Medicines</h5>
          <ul class="list-group">
            <?php
            if (isset($relative['patient_id'])) {
              $patientId = $relative['patient_id'];
              $medQuery = $conn->prepare("SELECT medicine_name, dosage, time_to_take, notes FROM patient_medicines WHERE patient_id = ?");
              $medQuery->bind_param("i", $patientId);
              $medQuery->execute();
              $medResult = $medQuery->get_result();

              $count = 0;
              if ($medResult->num_rows > 0) {
                while ($med = $medResult->fetch_assoc()) {
                  if ($count++ >= 3) break;
                  echo '<li class="list-group-item">';
                  echo '<strong>' . htmlspecialchars($med['medicine_name']) . '</strong> (' . htmlspecialchars($med['dosage'] ?: 'N/A') . ')<br />';
                  echo '<small class="text-muted">' . ($med['time_to_take'] ? date("g:i A", strtotime($med['time_to_take'])) : 'Time N/A');
                  echo $med['notes'] ? ' - ' . htmlspecialchars($med['notes']) : '';
                  echo '</small></li>';
                }
              } else {
                echo '<li class="list-group-item">No medicines assigned to the patient.</li>';
              }
              $medQuery->close();
            } else {
              echo '<li class="list-group-item text-danger">No patient linked to this relative.</li>';
            }
            ?>
          </ul>
        </div>
      </div>
    </div>


    <div class="col-lg-12 mb-4">
      <div class="card" style="cursor: pointer;" data-bs-toggle="modal" data-bs-target="#vitalSignsModal">
        <div class="card-body scrollable-card">
          <h5 class="card-title">🩺 Recent Vital Signs</h5>

          <?php
          if (isset($relative['patient_id'])) {
            $patientId = $relative['patient_id'];
            $vitalQuery = $conn->prepare("SELECT blood_pressure, heart_rate, temperature, respiration_rate, pulse_rate, oxygen_saturation, notes, created_at FROM vital_signs WHERE patient_id = ? ORDER BY created_at DESC LIMIT 3");
            $vitalQuery->bind_param("i", $patientId);
            $vitalQuery->execute();
            $vitalResult = $vitalQuery->get_result();

            if ($vitalResult->num_rows > 0) {
              echo '<table class="table table-sm table-bordered mb-0">';
              echo '<thead class="table-light">';
              echo '<tr>';
              echo '<th>BP</th><th>HR</th><th>Temp (°C)</th><th>Resp Rate</th><th>Pulse</th><th>O2 Sat</th><th>Notes</th><th>Recorded At</th>';
              echo '</tr></thead><tbody>';

              while ($row = $vitalResult->fetch_assoc()) {
                echo '<tr>';
                echo '<td>' . htmlspecialchars($row['blood_pressure']) . '</td>';
                echo '<td>' . htmlspecialchars($row['heart_rate']) . '</td>';
                echo '<td>' . htmlspecialchars($row['temperature']) . '</td>';
                echo '<td>' . htmlspecialchars($row['respiration_rate']) . '</td>';
                echo '<td>' . htmlspecialchars($row['pulse_rate']) . '</td>';
                echo '<td>' . htmlspecialchars($row['oxygen_saturation']) . '</td>';
                echo '<td>' . htmlspecialchars($row['notes'] ?: '-') . '</td>';
                echo '<td>' . htmlspecialchars($row['created_at']) . '</td>';
                echo '</tr>';
              }
              echo '</tbody></table>';
           } else { ?>
                <div class="alert alert-info text-center">No tasks assigned for today.</div>
              <?php
              }
              $vitalQuery->close();
              } else {
                echo '<p class="text-danger">No patient linked to this relative.</p>';
              }
              ?>


        </div>
      </div>
    </div>

    <div class="col-lg-12">
      <div class="card" style="cursor: pointer;" data-bs-toggle="modal" data-bs-target="#taskStatusModal">
        <div class="card-body scrollable-card">
          <h5 class="card-title">📋 Task Completion Status (Today)</h5>

          <?php if (isset($relative['patient_id'])):
            $today = date('Y-m-d');
            $patientId = $relative['patient_id'];

            $taskQuery = $conn->prepare("
              SELECT pt.task_description, pt.routine_time, pt.frequency,
                     IF(tcl.id IS NOT NULL, 'completed', 'pending') AS status
              FROM patient_tasks pt
              LEFT JOIN task_completion_log tcl 
                ON pt.id = tcl.task_id AND DATE(tcl.completed_at) = ?
              WHERE pt.patient_id = ? AND pt.task_date = ?
              LIMIT 3
            ");
            $taskQuery->bind_param("sis", $today, $patientId, $today);
            $taskQuery->execute();
            $taskResult = $taskQuery->get_result();
          ?>

            <?php if ($taskResult->num_rows > 0): ?>
              <div class="table-responsive scrollable-card">
                <table class="table table-bordered table-hover mb-0">
                  <thead class="table-light">
                    <tr>
                      <th>Task Description</th>
                      <th>Routine Time</th>
                      <th>Frequency</th>
                      <th>Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php while ($row = $taskResult->fetch_assoc()): ?>
                      <tr>
                        <td><?= htmlspecialchars($row['task_description']) ?></td>
                        <td><?= date("g:i A", strtotime($row['routine_time'])) ?></td>
                        <td><?= htmlspecialchars($row['frequency']) ?></td>
                        <td>
                          <?= $row['status'] === 'completed'
                            ? '<span class="badge bg-success">Completed</span>'
                            : '<span class="badge bg-warning text-dark">Pending</span>'; ?>
                        </td>
                      </tr>
                    <?php endwhile; ?>
                  </tbody>
                </table>
              </div>
            <?php else: ?>
              <div class="alert alert-info">No tasks assigned for today.</div>
            <?php endif; $taskQuery->close(); ?>
          <?php else: ?>
            <div class="alert alert-danger">No patient linked to this relative.</div>
          <?php endif; ?>

        </div>
      </div>
    </div>


    <div class="col-lg-12 mt-4">
      <div class="card" style="cursor: pointer;" data-bs-toggle="modal" data-bs-target="#medicineStatusModal">
        <div class="card-body">
          <h5 class="card-title">💊 Medicine Administration Status (Today)</h5>

          <?php if (isset($relative['patient_id'])):
            $today = date('Y-m-d');
            $patientId = $relative['patient_id'];

            $medQuery = $conn->prepare("
              SELECT pm.medicine_name, pm.dosage, pm.time_to_take, pm.notes,
                     IF(ml.id IS NOT NULL, 'completed', 'pending') AS status
              FROM patient_medicines pm
              LEFT JOIN medicine_log ml 
                ON pm.id = ml.medicine_id AND DATE(ml.administered_at) = ?
              WHERE pm.patient_id = ?
              LIMIT 3
            ");
            $medQuery->bind_param("si", $today, $patientId);
            $medQuery->execute();
            $medResult = $medQuery->get_result();
          ?>

            <?php if ($medResult->num_rows > 0): ?>
              <div class="table-responsive scrollable-card">
                <table class="table table-bordered table-hover mb-0">
                  <thead class="table-light">
                    <tr>
                      <th>Medicine Name</th>
                      <th>Dosage</th>
                      <th>Time to Take</th>
                      <th>Notes</th>
                      <th>Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php while ($row = $medResult->fetch_assoc()): ?>
                      <tr>
                        <td><?= htmlspecialchars($row['medicine_name']) ?></td>
                        <td><?= htmlspecialchars($row['dosage'] ?: '-') ?></td>
                        <td><?= $row['time_to_take'] ? date("g:i A", strtotime($row['time_to_take'])) : '-' ?></td>
                        <td><?= htmlspecialchars($row['notes']) ?: '-' ?></td>
                        <td>
                          <?= $row['status'] === 'completed'
                            ? '<span class="badge bg-success">Completed</span>'
                            : '<span class="badge bg-warning text-dark">Pending</span>'; ?>
                        </td>
                      </tr>
                    <?php endwhile; ?>
                  </tbody>
                </table>
              </div>
            <?php else: ?>
              <div class="alert alert-info">No medicines assigned for today.</div>
            <?php endif; $medQuery->close(); ?>
          <?php endif; ?>
        </div>
      </div>
    </div>

  </div>


  <div class="modal fade" id="dailyTasksModal" tabindex="-1" aria-labelledby="dailyTasksModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-scrollable">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="dailyTasksModalLabel">📋 Daily Tasks & Routines - Full List</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <ul class="list-group">
            <?php
            if (isset($relative['patient_id'])) {
              $taskQuery = $conn->prepare("SELECT task_description, routine_time, frequency FROM patient_tasks WHERE patient_id = ? AND task_date = ?");
              $taskQuery->bind_param("is", $patientId, $today);
              $taskQuery->execute();
              $result = $taskQuery->get_result();

              if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                  echo '<li class="list-group-item d-flex justify-content-between align-items-center flex-wrap">';
                  echo '<div><strong>' . htmlspecialchars($row['task_description']) . '</strong><br />';
                  echo '<small class="text-muted">' . htmlspecialchars($row['frequency']) . '</small></div>';
                  echo '<span class="badge bg-primary mt-2 mt-md-0">' . htmlspecialchars(date("g:i A", strtotime($row['routine_time']))) . '</span></li>';
                }
              } else {
                echo '<li class="list-group-item">No tasks assigned for today.</li>';
              }
              $taskQuery->close();
            }
            ?>
          </ul>
        </div>
      </div>
    </div>
  </div>

  <!-- Appointments Modal -->
  <div class="modal fade" id="appointmentsModal" tabindex="-1" aria-labelledby="appointmentsModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-scrollable">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="appointmentsModalLabel">📅 Upcoming Appointments - Full List</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <ul class="list-group">
            <?php
            if (!empty($relative['patient_id'])) {
              $apptStmt = $conn->prepare("SELECT title, appointment_date, appointment_time FROM appointments WHERE patient_id = ? AND appointment_date >= ? ORDER BY appointment_date ASC, appointment_time ASC LIMIT 50");
              $apptStmt->bind_param("is", $patientId, $today);
              $apptStmt->execute();
              $apptResult = $apptStmt->get_result();

              if ($apptResult->num_rows > 0) {
                while ($row = $apptResult->fetch_assoc()) {
                  echo '<li class="list-group-item">';
                  echo '<strong>' . htmlspecialchars($row['title']) . ':</strong> ';
                  echo date("F j", strtotime($row['appointment_date'])) . ' @ ' . date("g:i A", strtotime($row['appointment_time'])) . '<br />';
                  echo '<small>' . ucfirst($row['title']) . ' scheduled</small></li>';
                }
              } else {
                echo '<li class="list-group-item">No upcoming appointments.</li>';
              }
              $apptStmt->close();
            }
            ?>
          </ul>
        </div>
      </div>
    </div>
  </div>

  <!-- Medicines Modal -->
  <div class="modal fade" id="medicinesModal" tabindex="-1" aria-labelledby="medicinesModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-scrollable">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="medicinesModalLabel">💊 Daily Medicines - Full List</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <ul class="list-group">
            <?php
            if (isset($relative['patient_id'])) {
              $medQuery = $conn->prepare("SELECT medicine_name, dosage, time_to_take, notes FROM patient_medicines WHERE patient_id = ?");
              $medQuery->bind_param("i", $patientId);
              $medQuery->execute();
              $medResult = $medQuery->get_result();

              if ($medResult->num_rows > 0) {
                while ($med = $medResult->fetch_assoc()) {
                  echo '<li class="list-group-item">';
                  echo '<strong>' . htmlspecialchars($med['medicine_name']) . '</strong> (' . htmlspecialchars($med['dosage'] ?: 'N/A') . ')<br />';
                  echo '<small class="text-muted">' . ($med['time_to_take'] ? date("g:i A", strtotime($med['time_to_take'])) : 'Time N/A');
                  echo $med['notes'] ? ' - ' . htmlspecialchars($med['notes']) : '';
                  echo '</small></li>';
                }
              } else {
                echo '<li class="list-group-item">No medicines assigned to the patient.</li>';
              }
              $medQuery->close();
            }
            ?>
          </ul>
        </div>
      </div>
    </div>
  </div>

  <!-- Vital Signs Modal -->
  <div class="modal fade" id="vitalSignsModal" tabindex="-1" aria-labelledby="vitalSignsModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-scrollable">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="vitalSignsModalLabel">🩺 Vital Signs - Full List</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <?php
          if (isset($relative['patient_id'])) {
            $vitalQuery = $conn->prepare("SELECT blood_pressure, heart_rate, temperature, respiration_rate, pulse_rate, oxygen_saturation, notes, created_at FROM vital_signs WHERE patient_id = ? ORDER BY created_at DESC");
            $vitalQuery->bind_param("i", $patientId);
            $vitalQuery->execute();
            $vitalResult = $vitalQuery->get_result();

            if ($vitalResult->num_rows > 0) {
              echo '<table class="table table-bordered table-hover">';
              echo '<thead class="table-light">';
              echo '<tr>';
              echo '<th>Blood Pressure</th><th>Heart Rate</th><th>Temperature (°C)</th><th>Respiration Rate</th><th>Pulse Rate</th><th>Oxygen Saturation</th><th>Notes</th><th>Recorded At</th>';
              echo '</tr></thead><tbody>';

              while ($row = $vitalResult->fetch_assoc()) {
                echo '<tr>';
                echo '<td>' . htmlspecialchars($row['blood_pressure']) . '</td>';
                echo '<td>' . htmlspecialchars($row['heart_rate']) . '</td>';
                echo '<td>' . htmlspecialchars($row['temperature']) . '</td>';
                echo '<td>' . htmlspecialchars($row['respiration_rate']) . '</td>';
                echo '<td>' . htmlspecialchars($row['pulse_rate']) . '</td>';
                echo '<td>' . htmlspecialchars($row['oxygen_saturation']) . '</td>';
                echo '<td>' . htmlspecialchars($row['notes'] ?: '-') . '</td>';
                echo '<td>' . htmlspecialchars($row['created_at']) . '</td>';
                echo '</tr>';
              }
              echo '</tbody></table>';
            } else {
              echo '<p>No vital signs recorded yet.</p>';
            }
            $vitalQuery->close();
          } else {
            echo '<p class="text-danger">No patient linked to this relative.</p>';
          }
          ?>
        </div>
      </div>
    </div>
  </div>

  <!-- Task Status Modal -->
  <div class="modal fade" id="taskStatusModal" tabindex="-1" aria-labelledby="taskStatusModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-scrollable">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="taskStatusModalLabel">📋 Task Completion Status (Today) - Full List</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <?php if (isset($relative['patient_id'])):
            $taskQuery = $conn->prepare("
              SELECT pt.task_description, pt.routine_time, pt.frequency,
                     IF(tcl.id IS NOT NULL, 'completed', 'pending') AS status
              FROM patient_tasks pt
              LEFT JOIN task_completion_log tcl 
                ON pt.id = tcl.task_id AND DATE(tcl.completed_at) = ?
              WHERE pt.patient_id = ? AND pt.task_date = ?
            ");
            $taskQuery->bind_param("sis", $today, $patientId, $today);
            $taskQuery->execute();
            $taskResult = $taskQuery->get_result();
          ?>

            <?php if ($taskResult->num_rows > 0): ?>
              <div class="table-responsive scrollable-card">
                <table class="table table-bordered table-hover">
                  <thead class="table-light">
                    <tr>
                      <th>Task Description</th>
                      <th>Routine Time</th>
                      <th>Frequency</th>
                      <th>Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php while ($row = $taskResult->fetch_assoc()): ?>
                      <tr>
                        <td><?= htmlspecialchars($row['task_description']) ?></td>
                        <td><?= date("g:i A", strtotime($row['routine_time'])) ?></td>
                        <td><?= htmlspecialchars($row['frequency']) ?></td>
                        <td>
                          <?= $row['status'] === 'completed'
                            ? '<span class="badge bg-success">Completed</span>'
                            : '<span class="badge bg-warning text-dark">Pending</span>'; ?>
                        </td>
                      </tr>
                    <?php endwhile; ?>
                  </tbody>
                </table>
              </div>
            <?php else: ?>
              <div class="alert alert-info">No tasks assigned for today.</div>
            <?php endif; $taskQuery->close(); ?>
          <?php else: ?>
            <div class="alert alert-danger">No patient linked to this relative.</div>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>

  <!-- Medicine Status Modal -->
  <div class="modal fade" id="medicineStatusModal" tabindex="-1" aria-labelledby="medicineStatusModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-scrollable">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="medicineStatusModalLabel">💊 Medicine Administration Status (Today) - Full List</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <?php if (isset($relative['patient_id'])):
            $medQuery = $conn->prepare("
              SELECT pm.medicine_name, pm.dosage, pm.time_to_take, pm.notes,
                     IF(ml.id IS NOT NULL, 'completed', 'pending') AS status
              FROM patient_medicines pm
              LEFT JOIN medicine_log ml 
                ON pm.id = ml.medicine_id AND DATE(ml.administered_at) = ?
              WHERE pm.patient_id = ?
            ");
            $medQuery->bind_param("si", $today, $patientId);
            $medQuery->execute();
            $medResult = $medQuery->get_result();
          ?>

            <?php if ($medResult->num_rows > 0): ?>
              <div class="table-responsive scrollable-card">
                <table class="table table-bordered table-hover">
                  <thead class="table-light">
                    <tr>
                      <th>Medicine Name</th>
                      <th>Dosage</th>
                      <th>Time to Take</th>
                      <th>Notes</th>
                      <th>Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php while ($row = $medResult->fetch_assoc()): ?>
                      <tr>
                        <td><?= htmlspecialchars($row['medicine_name']) ?></td>
                        <td><?= htmlspecialchars($row['dosage'] ?: '-') ?></td>
                        <td><?= $row['time_to_take'] ? date("g:i A", strtotime($row['time_to_take'])) : '-' ?></td>
                        <td><?= htmlspecialchars($row['notes']) ?: '-' ?></td>
                        <td>
                          <?= $row['status'] === 'completed'
                            ? '<span class="badge bg-success">Completed</span>'
                            : '<span class="badge bg-warning text-dark">Pending</span>'; ?>
                        </td>
                      </tr>
                    <?php endwhile; ?>
                  </tbody>
                </table>
              </div>
            <?php else: ?>
              <div class="alert alert-info">No medicines assigned for today.</div>
            <?php endif; $medQuery->close(); ?>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>

</section>

</main>

<script>
document.addEventListener('DOMContentLoaded', function () {
  const notifDropdown = document.querySelector('.nav-icon[data-bs-toggle="dropdown"]');

  notifDropdown.addEventListener('click', function () {
    fetch('mark_notifications_read.php', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      }
    })
    .then(res => res.text())
    .then(data => {
    
      const badge = document.querySelector('.badge-number');
      if (badge) badge.style.display = 'none';
    });
  });
});
</script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<?php include 'messages_relatives.php'; ?>



<footer id="footer" class="footer">
  <div class="copyright">
    &copy; Copyright <strong><span>ElderlyCare</span></strong>. All Rights Reserved
  </div>
</footer>

<script src="/elderlycare/assets/vendor/apexcharts/apexcharts.min.js"></script>
<script src="/elderlycare/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="/elderlycare/assets/vendor/chart.js/chart.umd.js"></script>
<script src="/elderlycare/assets/vendor/echarts/echarts.min.js"></script>
<script src="/elderlycare/assets/vendor/quill/quill.js"></script>
<script src="/elderlycare/assets/vendor/simple-datatables/simple-datatables.js"></script>
<script src="/elderlycare/assets/vendor/tinymce/tinymce.min.js"></script>
<script src="/elderlycare/assets/vendor/php-email-form/validate.js"></script>
<script src="/elderlycare/assets/js/main.js"></script>

</body>
</html>
