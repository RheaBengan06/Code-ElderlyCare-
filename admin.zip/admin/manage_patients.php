<?php
session_start();
include 'conn.php';

if (!isset($_SESSION['admin_id'])) {
    echo "<script>
        alert('Please log in first');
        window.location.href = '/elderlycare/index.php';
    </script>";
    exit();
}

header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

$notif_sql = "SELECT id, message, is_read, type, reference_id, created_at 
              FROM admin_notifications 
              WHERE type != 'medicine' AND user_type = 'caregiver'
              ORDER BY created_at DESC 
              LIMIT 7";

$notif_result = mysqli_query($conn, $notif_sql);
$notifications = mysqli_fetch_all($notif_result, MYSQLI_ASSOC);

$unread_count = 0;
foreach ($notifications as $n) {
    if ($n['is_read'] == 0) $unread_count++;
}

if (isset($_POST['markAllRead'])) {
    $sql = "UPDATE admin_notifications 
            SET is_read = 1 
            WHERE user_type = 'caregiver'";
    mysqli_query($conn, $sql);

    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}

if (isset($_GET['notif_id'])) {
    $notif_id = intval($_GET['notif_id']);

    // Mark as read only if created by caregiver
    mysqli_query($conn, "UPDATE admin_notifications 
                         SET is_read = 1 
                         WHERE id = $notif_id AND user_type = 'caregiver'");

    $notif_info = mysqli_fetch_assoc(
        mysqli_query($conn, "SELECT type, reference_id 
                             FROM admin_notifications 
                             WHERE id = $notif_id AND user_type = 'caregiver'")
    );

    if ($notif_info) {
        if ($notif_info['type'] === 'new_caregiver') {
            header("Location: caregiver_account_request.php?id=" . $notif_info['reference_id']);
        } elseif ($notif_info['type'] === 'deleted_patient') {
            header("Location: managepatient.php");
        } else {
            header("Location: patients_request.php?id=" . $notif_info['reference_id']);
        }
    }
    exit();
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>ElderlyCare - User's Queries</title>
  <meta content="" name="description">
  <meta content="" name="keywords">


<!-- Favicons -->
<link href="/elderlycare/assets/img/logo.png" rel="icon">

<!-- Google Fonts -->
<link href="https://fonts.gstatic.com" rel="preconnect">
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

<!-- Vendor CSS Files -->
<link href="/elderlycare/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/quill/quill.snow.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/quill/quill.bubble.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/remixicon/remixicon.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/simple-datatables/style.css" rel="stylesheet">

<!-- Template Main CSS File -->
<link href="/elderlycare/assets/css/style.css" rel="stylesheet">
</head>
<style>
  
 
  .notification-item.unread {
    background-color: #f0f8ff;
  }
  .notification-item.unread p {
    font-weight: bold;
  }
 
.dropdown-menu.notifications {
  max-height: 300px;      
  overflow-y: auto;
  padding-right: 0;      
}


.dropdown-menu.notifications::-webkit-scrollbar {
  width: 6px;
}
.dropdown-menu.notifications::-webkit-scrollbar-track {
  background: transparent;
}
.dropdown-menu.notifications::-webkit-scrollbar-thumb {
  background-color: rgba(0,0,0,0.2);
  border-radius: 3px;
}
@media (max-width: 768px) {
  .table-responsive {
    width: 100%;
    overflow-x: auto;
    -webkit-overflow-scrolling: touch; /* smooth scrolling on mobile */
  }

  #patientTable th,
  #patientTable td {
    white-space: nowrap; /* prevent wrapping, force scroll */
  }
}

#patientTable {
  width: 100%;
  max-width: 100%;
  table-layout: auto;   /* let browser handle widths */
  border-collapse: collapse;
}
@media (max-width: 576px), (max-width: 780px) {
  .dropdown-menu.profile {
    position: fixed !important;
    top: 60px;
    left: 0 !important;
    right: 0 !important;
    border-radius: 0;
    z-index: 1050;
  }
}
.dropdown-menu.notifications {
  max-height: 400px;
  overflow-y: auto;
}

@media (max-width: 576px) {
  .dropdown-menu.notifications {
    position: fixed !important;
    top: 60px;
    left: 0 !important;
    right: 0 !important;
    width: 100vw !important;
    max-width: none !important;
    border-radius: 0;
    z-index: 1050;
  }
}
</style>
<body>

<header id="header" class="header fixed-top d-flex align-items-center">

<div class="d-flex align-items-center justify-content-between">
  <a href="AdminDashboard.php" class="logo d-flex align-items-center">
  <img src="/elderlycare/assets/img/logo.png" alt="Logo">
    <span class="d-none d-lg-block">ElderlyCare</span>
  </a>
  <i class="bi bi-list toggle-sidebar-btn"></i>
</div>

<nav class="header-nav ms-auto">
  <ul class="d-flex align-items-center">

  
 <!-- Notifications -->
<li class="nav-item dropdown">
  <a id="notificationBell" class="nav-link nav-icon" href="#" data-bs-toggle="dropdown">
    <i class="bi bi-bell"></i>
    <?php if ($unread_count > 0): ?>
      <span class="badge bg-primary badge-number"><?= $unread_count ?></span>
    <?php endif; ?>
  </a>

 <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow notifications"
    style="max-width: 350px; word-wrap: break-word;">
  <li class="dropdown-header">
    <span>
      You have <?= $unread_count ?> new notification<?= $unread_count !== 1 ? 's' : ''; ?>
    </span>
    <?php if ($unread_count > 0): ?>
      <div class="mt-1">
        <form method="POST" style="display:inline;">
          <button type="submit" name="markAllRead" class="btn" style="font-size: 13px; height: 35px;">
            Mark all as read
          </button>
        </form>
      </div>
    <?php endif; ?>
  </li>
  <li><hr class="dropdown-divider"></li>

  <?php foreach ($notifications as $notif):
    $url = "?notif_id=" . $notif['id'];
    $liClass = $notif['is_read'] == 0 ? 'notification-item unread' : 'notification-item';
  ?>
    <li class="<?= $liClass ?>">
      <a href="<?= $url ?>" class="d-flex align-items-start text-decoration-none">
        <i class="bi bi-info-circle text-info me-2"></i>
        <div>
          <p class="mb-1"><?= htmlspecialchars($notif['message']) ?></p>
          <small class="text-muted">
            <?= date("M d, Y h:i A", strtotime($notif['created_at'])) ?>
          </small>
        </div>
      </a>
    </li>
    <li><hr class="dropdown-divider"></li>
  <?php endforeach; ?>
</ul>

</li>
<!-- End Notifications -->

      <?php
  include('conn.php');

  $query = "SELECT fullname, position, admin_picture FROM admins WHERE id = 1";
  $stmt = $conn->prepare($query);
  $stmt->execute();
  $stmt->bind_result($fullname, $position, $adminPicture);
  $stmt->fetch();
  $stmt->close();
?>
<li class="nav-item dropdown pe-3">
  <a class="nav-link nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown">
    <?php if (!empty($adminPicture)): ?>
      <img src="uploads/admin/<?= htmlspecialchars($adminPicture) ?>"
           alt="Profile"
           class="rounded-circle"
           style="object-fit: cover; width: 40px; height: 40px;" />
    <?php else: ?>
      <div class="rounded-circle bg-secondary d-flex justify-content-center align-items-center"
           style="width: 40px; height: 40px;">
        <i class="bi bi-person text-white fs-5"></i>
      </div>
    <?php endif; ?>
    <span class="dropdown-toggle d-none d-md-inline-block text-truncate" style="max-width: 120px;">
      <?= htmlspecialchars($fullname) ?>
    </span>
  </a>

  <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow profile w-100" style="max-width: none; word-wrap: break-word;">
    <li class="dropdown-header">
      <h6><?= htmlspecialchars($fullname) ?></h6>
      <span><?= htmlspecialchars($position) ?></span>
    </li>

    <li><hr class="dropdown-divider"></li>

    <li>
      <a class="dropdown-item d-flex align-items-center" href="admin_profile.php">
        <i class="bi bi-person"></i>
        <span>My Profile</span>
      </a>
    </li>

    <li><hr class="dropdown-divider"></li>

    <li>
      <a class="dropdown-item d-flex align-items-center" href="/elderlycare/logout.php">
        <i class="bi bi-box-arrow-right"></i>
        <span>Sign Out</span>
      </a>
    </li>
  </ul>
</li>

  </nav>
    </header>

<aside id="admin-sidebar" class="sidebar">
  <h3 class="text-white text-center space-below">Admin Dashboard</h3>
  <ul class="sidebar-nav" id="admin-sidebar-nav">

    <li class="nav-item">
      <a class="nav-link collapsed" href="AdminDashboard.php">
        <i class="bi bi-house-door"></i>
        <span>Dashboard</span>
      </a>
    </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="manage_rooms.php">
          <i class="bi bi-door-open"></i>
          <span>Manage Patient Rooms </span>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link collapsed" href="caregiver_account_request.php">
          <i class="bi bi-check-circle"></i>
          <span>Caregiver Approvals </span>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link collapsed" href="patients_request.php">
          <i class="bi bi-person-check"></i>
          <span>Patient's Approvals </span>
        </a>
    </li>

    <li class="nav-item">
      <a class="nav-link " href="manage_patients.php">
        <i class="bi bi-file-earmark-person"></i>
        <span>Manage Patients</span>
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link collapsed" href="manage_caregivers.php">
        <i class="bi bi-person-bounding-box"></i>
        <span>Manage Caregivers</span>
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link collapsed" href="view_reports.php">
      <i class="bi bi-file-earmark-text"></i> 
        <span>View Reports</span>
      </a>
    </li>

  </ul>
</aside>
<?php
include 'conn.php'; 


  $query = "SELECT patients.id, 
                  patients.date_added,
                  CONCAT(patients.first_name, ' ', patients.middle_name, ' ', patients.last_name) AS patient_name, 
                  caregivers_info.full_name AS caregiver_name,
                  patients.emergency_contact_name,
                  patients.emergency_contact_number,
                  patients.email_address,
                  patients.relationship,
                  patients.dob, 
                  patients.health_status, 
                  patients.address, 
                  patients.medications, 
                  patients.profile_picture,
                  patients.status  
            FROM patients 
            LEFT JOIN caregivers ON patients.caregiver_id = caregivers.id
            LEFT JOIN caregivers_info ON caregivers.id = caregivers_info.caregiver_id";


  $result = $conn->query($query);


if (!$result) {
    die("Query failed: " . $conn->error);
}
?>

<main id="main" class="main">
  <div class="pagetitle">
    <h2>Manage Patients</h2>
    <nav>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="AdminDashboard.php">Home</a></li>
        <li class="breadcrumb-item">Patients</li>
        <li class="breadcrumb-item active">Manage Patients</li>
      </ol>
    </nav>
  </div>

  <section class="section">
    <div class="row">
      <div class="col-lg-12">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title">Manage Patients</h5>

            <!-- ✅ Added responsive wrapper -->
            <div class="table-responsive">
              <table class="table table-bordered" id="patientTable">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Date Patient Added</th>
                    <th>Patient Name</th>
                    <th>Caregiver Name</th>
                    <th>Person to Contact</th>
                    <th>Date of Birth</th>
                    <th>Health Status</th>
                    <th>Address</th>
                    <th>Medications</th>
                    <th>Profile Picture</th>
                    <th>Status</th>  
                  </tr>
                </thead>
                <tbody>
                  <?php
                  if ($result->num_rows > 0) {
                    $counter = 1; 
                    while ($patient = $result->fetch_assoc()) {
                        $caregiver_name = $patient['caregiver_name'] ? $patient['caregiver_name'] : "No caregiver assigned";

                        $imageFilename = $patient['profile_picture'] ? $patient['profile_picture'] : 'default-avatar.png';

                        $adminPath = "/ElderlyCare/templates/admin/uploads/patients/";
                        $caregiverPath = "/ElderlyCare/templates/caregiver/uploads/patients/";

                        $localAdminFile = $_SERVER['DOCUMENT_ROOT'] . "/ElderlyCare/templates/admin/uploads/patients/" . $imageFilename;
                        $localCaregiverFile = $_SERVER['DOCUMENT_ROOT'] . "/ElderlyCare/templates/caregiver/uploads/patients/" . $imageFilename;

                        if (file_exists($localAdminFile)) {
                            $imagePath = $adminPath . $imageFilename;
                        } elseif (file_exists($localCaregiverFile)) {
                            $imagePath = $caregiverPath . $imageFilename;
                        } else {
                            $imagePath = "http://localhost/ElderlyCare/assets/img/default-avatar.png";
                        }

                        $status_class = '';
                        $status_text = $patient['status'];
                        if ($status_text == 'approved') {
                            $status_class = 'bg-success text-white';
                        } elseif ($status_text == 'pending') {
                            $status_class = 'bg-warning text-dark';
                        } elseif ($status_text == 'rejected') {
                            $status_class = 'bg-danger text-white';
                        } else {
                            $status_class = 'bg-secondary text-white';
                        }

                        echo '<tr id="patient-' . $patient['id'] . '" data-patient="' . htmlspecialchars(json_encode($patient)) . '">
                                  <td>' . $counter++ . '</td>
                                  <td>' . $patient['date_added'] . '</td>
                                  <td>' . $patient['patient_name'] . '</td>
                                  <td>' . $caregiver_name . '</td>
                                  <td>' . $patient['emergency_contact_name'] . '<br>' . 
                                          $patient['emergency_contact_number'] . '<br>' . 
                                          '(' . $patient['relationship'] . ')<br>' .
                                          '<small class="text-muted">' . $patient['email_address'] . '</small>' . '</td>
                                  <td>' . $patient['dob'] . '</td>
                                  <td>' . $patient['health_status'] . '</td>
                                  <td>' . $patient['address'] . '</td>
                                  <td>' . $patient['medications'] . '</td>
                                  <td>
                                    <img src="' . $imagePath . '" 
                                        alt="Profile Picture" 
                                        class="img-thumbnail" 
                                        style="width: 100px; height: 100px; object-fit: cover; cursor: pointer;" 
                                        data-bs-toggle="modal" data-bs-target="#profilePictureModal-' . $patient['id'] . '">
                                  </td>
                                  <td class="' . $status_class . '">' . ucfirst($status_text) . '</td>
                              </tr>';

                        echo '<div class="modal fade" id="profilePictureModal-' . $patient['id'] . '" tabindex="-1" aria-labelledby="profilePictureModalLabel" aria-hidden="true">
                                <div class="modal-dialog modal-dialog-centered modal-lg">
                                  <div class="modal-content">
                                    <div class="modal-header">
                                      <h5 class="modal-title" id="profilePictureModalLabel">Profile Picture</h5>
                                      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body text-center">
                                      <img src="' . $imagePath . '" 
                                          alt="Profile Picture" 
                                          class="img-fluid" 
                                          style="object-fit: contain; max-width: 100%; max-height: 80vh;">
                                    </div>
                                  </div>
                                </div>
                              </div>';
                    }
                  } else {
                      echo '<tr><td colspan="11" class="text-center">No patients found</td></tr>';
                  }
                  ?>
                </tbody>
              </table>
            </div>


          </div>
        </div>
      </div>
    </div>
  </section>
</main>





<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>


  <footer id="footer" class="footer">
    <div class="copyright">
      &copy; Copyright <strong><span>ElderlyCare</span></strong>. All Rights Reserved
    </div>
  </footer>

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

 
<script src="/elderlycare/assets/js/main.js"></script>




</body>

</html>




