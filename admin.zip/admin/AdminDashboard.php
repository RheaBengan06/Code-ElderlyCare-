<?php
session_start();
include 'conn.php';


if (!isset($_SESSION['admin_id'])) {
    echo "<script>
        alert('Please log in first');
        window.location.href = 'adminLogin.php';
    </script>";
    exit;
}

header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

$notif_sql = "SELECT id, message, is_read, type, reference_id, created_at 
              FROM admin_notifications 
              WHERE type != 'medicine' AND user_type = 'caregiver'
              ORDER BY created_at DESC 
              LIMIT 7";

$notif_result = mysqli_query($conn, $notif_sql);
$notifications = mysqli_fetch_all($notif_result, MYSQLI_ASSOC);

$unread_count = 0;
foreach ($notifications as $n) {
    if ($n['is_read'] == 0) $unread_count++;
}

if (isset($_POST['markAllRead'])) {
    $sql = "UPDATE admin_notifications 
            SET is_read = 1 
            WHERE user_type = 'caregiver'";
    mysqli_query($conn, $sql);

    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}

if (isset($_GET['notif_id'])) {
    $notif_id = intval($_GET['notif_id']);

    // Mark as read only if created by caregiver
    mysqli_query($conn, "UPDATE admin_notifications 
                         SET is_read = 1 
                         WHERE id = $notif_id AND user_type = 'caregiver'");

    $notif_info = mysqli_fetch_assoc(
        mysqli_query($conn, "SELECT type, reference_id 
                             FROM admin_notifications 
                             WHERE id = $notif_id AND user_type = 'caregiver'")
    );

    if ($notif_info) {
        if ($notif_info['type'] === 'new_caregiver') {
            header("Location: caregiver_account_request.php?id=" . $notif_info['reference_id']);
        } elseif ($notif_info['type'] === 'deleted_patient') {
            header("Location: managepatient.php");
        } else {
            header("Location: patients_request.php?id=" . $notif_info['reference_id']);
        }
    }
    exit();
}


?>



<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>ElderlyCare - User's Queries</title>
  <meta content="" name="description">
  <meta content="" name="keywords">


<!-- Favicons -->
<link href="/elderlycare/assets/img/logo.png" rel="icon">

<!-- Google Fonts -->
<link href="https://fonts.gstatic.com" rel="preconnect">
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

<!-- Vendor CSS Files -->
<link href="/elderlycare/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/quill/quill.snow.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/quill/quill.bubble.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/remixicon/remixicon.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/simple-datatables/style.css" rel="stylesheet">

<!-- Template Main CSS File -->
<link href="/elderlycare/assets/css/style.css" rel="stylesheet">


  <style>
  
 
  .notification-item.unread {
    background-color: #f0f8ff;
  }
  .notification-item.unread p {
    font-weight: bold;
  }

.dropdown-menu.notifications {
  max-height: 300px;      
  overflow-y: auto;
  padding-right: 0;      
}


.dropdown-menu.notifications::-webkit-scrollbar {
  width: 6px;
}
.dropdown-menu.notifications::-webkit-scrollbar-track {
  background: transparent;
}
.dropdown-menu.notifications::-webkit-scrollbar-thumb {
  background-color: rgba(0,0,0,0.2);
  border-radius: 3px;
}
@media (max-width: 576px), (max-width: 780px) {
  .dropdown-menu.profile {
    position: fixed !important;
    top: 60px;
    left: 0 !important;
    right: 0 !important;
    border-radius: 0;
    z-index: 1050;
  }
}
.dropdown-menu.notifications {
  max-height: 400px;
  overflow-y: auto;
}

@media (max-width: 576px) {
  .dropdown-menu.notifications {
    position: fixed !important;
    top: 60px;
    left: 0 !important;
    right: 0 !important;
    width: 100vw !important;
    max-width: none !important;
    border-radius: 0;
    z-index: 1050;
  }
}

</style>
</head>



<header id="header" class="header fixed-top d-flex align-items-center">

<div class="d-flex align-items-center justify-content-between">
  <a href="AdminDashboard.php" class="logo d-flex align-items-center">
  <img src="/elderlycare/assets/img/logo.png" alt="Logo">
    <span class="d-none d-lg-block">ElderlyCare</span>
  </a>
  <i class="bi bi-list toggle-sidebar-btn"></i>
</div>

<nav class="header-nav ms-auto">
  <ul class="d-flex align-items-center">

  
 <!-- Notifications -->
<li class="nav-item dropdown">
  <a id="notificationBell" class="nav-link nav-icon" href="#" data-bs-toggle="dropdown">
    <i class="bi bi-bell"></i>
    <?php if ($unread_count > 0): ?>
      <span class="badge bg-primary badge-number"><?= $unread_count ?></span>
    <?php endif; ?>
  </a>

 <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow notifications"
    style="max-width: 350px; word-wrap: break-word;">
  <li class="dropdown-header">
    <span>
      You have <?= $unread_count ?> new notification<?= $unread_count !== 1 ? 's' : ''; ?>
    </span>
    <?php if ($unread_count > 0): ?>
      <div class="mt-1">
        <form method="POST" style="display:inline;">
          <button type="submit" name="markAllRead" class="btn" style="font-size: 13px; height: 35px;">
            Mark all as read
          </button>
        </form>
      </div>
    <?php endif; ?>
  </li>
  <li><hr class="dropdown-divider"></li>

  <?php foreach ($notifications as $notif):
    $url = "?notif_id=" . $notif['id'];
    $liClass = $notif['is_read'] == 0 ? 'notification-item unread' : 'notification-item';
  ?>
    <li class="<?= $liClass ?>">
      <a href="<?= $url ?>" class="d-flex align-items-start text-decoration-none">
        <i class="bi bi-info-circle text-info me-2"></i>
        <div>
          <p class="mb-1"><?= htmlspecialchars($notif['message']) ?></p>
          <small class="text-muted">
            <?= date("M d, Y h:i A", strtotime($notif['created_at'])) ?>
          </small>
        </div>
      </a>
    </li>
    <li><hr class="dropdown-divider"></li>
  <?php endforeach; ?>
</ul>

</li>
<!-- End Notifications -->

      <?php
  include('conn.php');

  $query = "SELECT fullname, position, admin_picture FROM admins WHERE id = 1";
  $stmt = $conn->prepare($query);
  $stmt->execute();
  $stmt->bind_result($fullname, $position, $adminPicture);
  $stmt->fetch();
  $stmt->close();
?>
<li class="nav-item dropdown pe-3">
  <a class="nav-link nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown">
    <?php if (!empty($adminPicture)): ?>
      <img src="uploads/admin/<?= htmlspecialchars($adminPicture) ?>"
           alt="Profile"
           class="rounded-circle"
           style="object-fit: cover; width: 40px; height: 40px;" />
    <?php else: ?>
      <div class="rounded-circle bg-secondary d-flex justify-content-center align-items-center"
           style="width: 40px; height: 40px;">
        <i class="bi bi-person text-white fs-5"></i>
      </div>
    <?php endif; ?>
    <span class="dropdown-toggle d-none d-md-inline-block text-truncate" style="max-width: 120px;">
      <?= htmlspecialchars($fullname) ?>
    </span>
  </a>

  <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow profile w-100" style="max-width: none; word-wrap: break-word;">
    <li class="dropdown-header">
      <h6><?= htmlspecialchars($fullname) ?></h6>
      <span><?= htmlspecialchars($position) ?></span>
    </li>

    <li><hr class="dropdown-divider"></li>

    <li>
      <a class="dropdown-item d-flex align-items-center" href="admin_profile.php">
        <i class="bi bi-person"></i>
        <span>My Profile</span>
      </a>
    </li>

    <li><hr class="dropdown-divider"></li>

    <li>
      <a class="dropdown-item d-flex align-items-center" href="/elderlycare/logout.php">
        <i class="bi bi-box-arrow-right"></i>
        <span>Sign Out</span>
      </a>
    </li>
  </ul>
</li>

  </nav>
    </header>


<aside id="admin-sidebar" class="sidebar">
  <h3 class="text-white text-center space-below">Admin Dashboard</h3>
  <ul class="sidebar-nav" id="admin-sidebar-nav">

    <li class="nav-item">
      <a class="nav-link" href="AdminDashboard.php">
        <i class="bi bi-house-door"></i>
        <span>Dashboard</span>
      </a>
    </li>
    <li class="nav-item">
        <a class="nav-link collapsed" href="manage_rooms.php">
          <i class="bi bi-door-open"></i>
          <span>Manage Patient Rooms </span>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link collapsed" href="caregiver_account_request.php">
          <i class="bi bi-check-circle"></i>
          <span>Caregiver Approvals </span>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link collapsed" href="patients_request.php">
          <i class="bi bi-person-check"></i>
          <span>Patient's Approvals </span>
        </a>
    </li>
    <li class="nav-item">
      <a class="nav-link collapsed" href="manage_patients.php">
        <i class="bi bi-file-earmark-person"></i>
        <span>Manage Patients</span>
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link collapsed" href="manage_caregivers.php">
        <i class="bi bi-person-bounding-box"></i>
        <span>Manage Caregivers</span>
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link collapsed" href="view_reports.php">
      <i class="bi bi-file-earmark-text"></i> 
        <span>View Reports</span>
      </a>
    </li>

  </ul>
</aside>

<main id="main" class="main">
  <?php if (isset($_SESSION['message'])): ?>
<div class="alert alert-success alert-dismissible fade show mt-5" 
     role="alert" 
     style="max-width: 500px; margin: 0 auto; text-align: center;">
    <?= $_SESSION['message']; ?>
</div>
<script>
    setTimeout(() => {
        const alertBox = document.querySelector('.alert');
        if(alertBox){
            alertBox.classList.remove('show');
            alertBox.classList.add('hide');
            setTimeout(() => alertBox.remove(), 300);
        }
    }, 3000);
</script>
<?php unset($_SESSION['message']); endif; ?>

    <div class="pagetitle">
        <h2>Dashboard</h2>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="AdminDashboard.php">Home</a></li>
                <li class="breadcrumb-item active">Dashboard</li>
            </ol>
        </nav>
    </div>

    <section class="section dashboard">
        <div class="row">
            <div class="col-12">
                <div class="row justify-content-start">

              <?php
              include "conn.php";
            
              $months = [];
              $monthlyCounts = [];

              $query = "SELECT DATE_FORMAT(date_added, '%b') AS month, COUNT(*) AS count 
                        FROM patients 
                        WHERE date_added >= CURDATE() - INTERVAL 6 MONTH 
                        GROUP BY YEAR(date_added), MONTH(date_added) 
                        ORDER BY date_added ASC";
              $result = $conn->query($query);

              while ($row = $result->fetch_assoc()) {
                  $months[] = $row['month'];
                  $monthlyCounts[] = $row['count'];
              }

             
              $statusQuery = "SELECT status, COUNT(*) AS count FROM patients GROUP BY status";
              $statusResult = $conn->query($statusQuery);

              $statuses = ['Pending', 'Approved', 'Rejected']; 
              $statusCounts = [0, 0, 0];

              while ($row = $statusResult->fetch_assoc()) {
                  $status = ucfirst($row['status']);
                  $count = $row['count'];
                  
                 
                  if ($status == 'Pending') {
                      $statusCounts[0] = $count;
                  } elseif ($status == 'Approved') {
                      $statusCounts[1] = $count;
                  } elseif ($status == 'Rejected') {
                      $statusCounts[2] = $count; 
                  }
              }


              $query = "
                  SELECT ci.full_name AS caregiver, COUNT(p.id) AS patient_count
                  FROM patients p
                  JOIN caregivers c ON p.caregiver_id = c.id
                  JOIN caregivers_info ci ON ci.caregiver_id = c.id
                  GROUP BY ci.full_name
              ";

              $caregiverResult = $conn->query($query);

              $caregiverNames = [];
              $caregiverPatientCounts = [];

              while ($row = $caregiverResult->fetch_assoc()) {
                  $caregiverNames[] = $row['caregiver'];
                  $caregiverPatientCounts[] = $row['patient_count'];
              }

            
              $caregiverStatusQuery = "SELECT status, COUNT(*) AS count FROM caregivers GROUP BY status";
              $caregiverStatusResult = $conn->query($caregiverStatusQuery);

              $caregiverStatusCounts = ['Pending' => 0, 'Approved' => 0, 'Rejected' => 0];

              while ($row = $caregiverStatusResult->fetch_assoc()) {
                  $status = ucfirst($row['status']);
                  $count = $row['count'];

                 
                  if (array_key_exists($status, $caregiverStatusCounts)) {
                      $caregiverStatusCounts[$status] = $count;
                  }
              }

              if ($conn) {
                  $caregiverResult = $conn->query("SELECT COUNT(*) AS total_caregivers FROM caregivers");
                  $totalCaregivers = ($caregiverResult && $caregiverResult->num_rows > 0) ? $caregiverResult->fetch_assoc()['total_caregivers'] : 0;

                  $patientResult = $conn->query("SELECT COUNT(*) AS total_patients FROM patients");
                  $totalPatients = ($patientResult && $patientResult->num_rows > 0) ? $patientResult->fetch_assoc()['total_patients'] : 0;

                  $pendingRequestsResult = $conn->query("SELECT COUNT(*) AS pending_requests FROM patients WHERE status = 'pending'");
                  $pendingRequests = ($pendingRequestsResult && $pendingRequestsResult->num_rows > 0) ? $pendingRequestsResult->fetch_assoc()['pending_requests'] : 0;

                  $newPatientsResult = $conn->query("SELECT COUNT(*) AS new_patients FROM patients WHERE DATE(date_added) > CURDATE() - INTERVAL 1 MONTH");
                  $newPatients = ($newPatientsResult && $newPatientsResult->num_rows > 0) ? $newPatientsResult->fetch_assoc()['new_patients'] : 0;
              } else {
                  $totalCaregivers = $totalPatients = $pendingRequests = $newPatients = 0;
              }
              ?>


<div class="row">
  <div class="col-xxl-3 col-md-4 col-sm-6 mb-4 d-flex">
    <div class="card info-card caregivers-card w-100 h-100">
      <div class="card-body d-flex flex-column align-items-center justify-content-center">
        <h5 class="card-title text-center mb-4">Total Caregivers</h5>
        <div class="d-flex align-items-center justify-content-center">
          <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
            <i class="bi bi-person-circle"></i>
          </div>
          <div class="ps-3">
            <h2 style="color:rgb(21, 63, 141) !important;"><?php echo htmlspecialchars($totalCaregivers); ?></h2>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="col-xxl-3 col-md-4 col-sm-6 mb-4 d-flex">
    <div class="card info-card patients-card w-100 h-100">
      <div class="card-body d-flex flex-column align-items-center justify-content-center">
        <h5 class="card-title text-center mb-4">Total Patients</h5>
        <div class="d-flex align-items-center justify-content-center">
          <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
            <i class="bi bi-person-lines-fill"></i>
          </div>
          <div class="ps-3">
            <h2 style="color:rgb(21, 63, 141) !important;"><?php echo htmlspecialchars($totalPatients); ?></h2>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="col-xxl-3 col-md-4 col-sm-6 mb-4 d-flex">
    <div class="card info-card new-patient-card w-100 h-100">
      <div class="card-body d-flex flex-column align-items-center justify-content-center">
        <h5 class="card-title text-center mb-4">New Patient Registrations</h5>
        <div class="d-flex align-items-center justify-content-center">
          <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
            <i class="bi bi-person-plus"></i>
          </div>
          <div class="ps-3">
            <h2 style="color:rgb(0, 123, 255) !important;"><?php echo $newPatients; ?></h2>
            <span class="text-muted">This month</span>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="col-xxl-3 col-md-4 col-sm-6 mb-4 d-flex">
    <div class="card info-card pending-requests-card w-100 h-100">
      <div class="card-body d-flex flex-column align-items-center justify-content-center">
        <h5 class="card-title text-center mb-4">Pending Patients</h5>
        <div class="d-flex align-items-center justify-content-center">
          <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
            <i class="bi bi-clock"></i>
          </div>
          <div class="ps-3">
            <h2 style="color:rgb(255, 99, 132) !important;"><?php echo $pendingRequests; ?></h2>
            <span class="text-muted">Awaiting approval</span>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Caregiver Status Cards (Centered) -->
<div class="row justify-content-center">
  <div class="col-xxl-3 col-md-4 col-sm-6 mb-4 d-flex">
    <div class="card info-card pending-caregivers-card w-100 h-100">
      <div class="card-body d-flex flex-column align-items-center justify-content-center">
        <h5 class="card-title text-center mb-4">Pending Caregivers</h5>
        <div class="d-flex align-items-center justify-content-center">
          <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
            <i class="bi bi-hourglass-split"></i>
          </div>
          <div class="ps-3">
            <h2 style="color:rgb(255, 159, 64) !important;"><?php echo htmlspecialchars($caregiverStatusCounts['Pending']); ?></h2>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="col-xxl-3 col-md-4 col-sm-6 mb-4 d-flex">
    <div class="card info-card approved-caregivers-card w-100 h-100">
      <div class="card-body d-flex flex-column align-items-center justify-content-center">
        <h5 class="card-title text-center mb-4">Approved Caregivers</h5>
        <div class="d-flex align-items-center justify-content-center">
          <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
            <i class="bi bi-person-check-fill"></i>
          </div>
          <div class="ps-3">
            <h2 style="color:rgb(8, 138, 43) !important;"><?php echo htmlspecialchars($caregiverStatusCounts['Approved']); ?></h2>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="col-xxl-3 col-md-4 col-sm-6 mb-4 d-flex">
    <div class="card info-card rejected-caregivers-card w-100 h-100">
      <div class="card-body d-flex flex-column align-items-center justify-content-center">
        <h5 class="card-title text-center mb-4">Rejected Caregivers</h5>
        <div class="d-flex align-items-center justify-content-center">
          <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
            <i class="bi bi-person-x-fill"></i>
          </div>
          <div class="ps-3">
            <h2 style="color:rgb(220, 53, 69) !important;"><?php echo htmlspecialchars($caregiverStatusCounts['Rejected']); ?></h2>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="row">
  <div class="col-xxl-6 col-md-6 mb-4 d-flex">
    <div class="card w-100 h-100">
      <div class="card-body d-flex flex-column align-items-center justify-content-center">
        <h5 class="card-title text-center mb-4">Patient Status Distribution</h5>
        <div class="flex-grow-1 d-flex justify-content-center align-items-center">
          <canvas id="statusChart" style="max-width: 100%; height: auto;"></canvas>
        </div>
      </div>
    </div>
  </div>

  <div class="col-xxl-6 col-md-6 mb-4 d-flex">
    <div class="card w-100 h-100">
      <div class="card-body d-flex flex-column align-items-center justify-content-center">
        <h5 class="card-title text-center mb-4">Patients per Caregiver</h5>
        <div class="flex-grow-1 d-flex justify-content-center align-items-center">
          <canvas id="caregiverChart" style="max-width: 100%; height: auto;"></canvas>
        </div>
      </div>
    </div>
  </div>
</div>


</div> 
</div>
</section>
</main>


<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>


const statusCtx = document.getElementById('statusChart').getContext('2d');
new Chart(statusCtx, {
    type: 'doughnut',
    data: {
        labels: <?php echo json_encode($statuses); ?>,
        datasets: [{
            label: 'Patient Status',
            data: <?php echo json_encode($statusCounts); ?>,
            backgroundColor: ['#f39c12', '#28a745', '#dc3545'],
            borderWidth: 1
        }]
    },
    options: {
        responsive: true,
        plugins: {
            legend: {
                position: 'bottom',
                labels: {
                    font: {
                        size: 12
                    }
                }
            },
            tooltip: {
                callbacks: {
                    label: function(tooltipItem) {
                        const label = tooltipItem.label;
                        const value = tooltipItem.raw;
                        return label + ': ' + value + ' patients';
                    }
                }
            }
        }
    }
});


const caregiverCtx = document.getElementById('caregiverChart').getContext('2d');
const caregiverChart = new Chart(caregiverCtx, {
    type: 'bar',
    data: {
        labels: <?php echo json_encode($caregiverNames); ?>,
        datasets: [{
            label: 'Patients per Caregiver',
            data: <?php echo json_encode($caregiverPatientCounts); ?>,
            backgroundColor: 'rgba(0, 123, 255, 0.5)',
            borderColor: 'rgba(0, 123, 255, 1)',
            borderWidth: 1
        }]
    },
    options: {
        responsive: true,
        plugins: {
            legend: {
                display: false
            }
        },
        scales: {
            y: {
                beginAtZero: true,
                ticks: {
                    stepSize: 1
                }
            }
        }
    }
});
</script>






  <footer id="footer" class="footer">
    <div class="copyright">
      &copy; Copyright <strong><span>ElderlyCare</span></strong>. All Rights Reserved
    </div>
  </footer

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>
    

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>


<script src="/elderlycare/assets/vendor/apexcharts/apexcharts.min.js"></script>
<script src="/elderlycare/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="/elderlycare/assets/vendor/chart.js/chart.umd.js"></script>
<script src="/elderlycare/assets/vendor/echarts/echarts.min.js"></script>
<script src="/elderlycare/assets/vendor/quill/quill.js"></script>
<script src="/elderlycare/assets/vendor/simple-datatables/simple-datatables.js"></script>
<script src="/elderlycare/assets/vendor/tinymce/tinymce.min.js"></script>
<script src="/elderlycare/assets/vendor/php-email-form/validate.js"></script>


<script src="/elderlycare/assets/js/main.js"></script>



</body>


</html>