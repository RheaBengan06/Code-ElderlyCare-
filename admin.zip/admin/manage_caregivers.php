<?php
include 'conn.php';
session_start();


if (!isset($_SESSION['admin_id'])) {
    echo "<script>
        alert('Please log in first');
        window.location.href = '/elderlycare/index.php';
    </script>";
    exit();
}

header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");


$notif_sql = "SELECT id, message, is_read, type, reference_id, created_at 
              FROM admin_notifications 
              WHERE type != 'medicine' AND user_type = 'caregiver'
              ORDER BY created_at DESC 
              LIMIT 7";

$notif_result = mysqli_query($conn, $notif_sql);
$notifications = mysqli_fetch_all($notif_result, MYSQLI_ASSOC);

$unread_count = 0;
foreach ($notifications as $n) {
    if ($n['is_read'] == 0) $unread_count++;
}

if (isset($_POST['markAllRead'])) {
    $sql = "UPDATE admin_notifications 
            SET is_read = 1 
            WHERE user_type = 'caregiver'";
    mysqli_query($conn, $sql);

    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}

if (isset($_GET['notif_id'])) {
    $notif_id = intval($_GET['notif_id']);

    // Mark as read only if created by caregiver
    mysqli_query($conn, "UPDATE admin_notifications 
                         SET is_read = 1 
                         WHERE id = $notif_id AND user_type = 'caregiver'");

    $notif_info = mysqli_fetch_assoc(
        mysqli_query($conn, "SELECT type, reference_id 
                             FROM admin_notifications 
                             WHERE id = $notif_id AND user_type = 'caregiver'")
    );

    if ($notif_info) {
        if ($notif_info['type'] === 'new_caregiver') {
            header("Location: caregiver_account_request.php?id=" . $notif_info['reference_id']);
        } elseif ($notif_info['type'] === 'deleted_patient') {
            header("Location: managepatient.php");
        } else {
            header("Location: patients_request.php?id=" . $notif_info['reference_id']);
        }
    }
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>ElderlyCare - User's Queries</title>
  <meta content="" name="description">
  <meta content="" name="keywords">


<!-- Favicons -->
<link href="/elderlycare/assets/img/logo.png" rel="icon">

<!-- Google Fonts -->
<link href="https://fonts.gstatic.com" rel="preconnect">
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

<!-- Vendor CSS Files -->
<link href="/elderlycare/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/quill/quill.snow.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/quill/quill.bubble.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/remixicon/remixicon.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/simple-datatables/style.css" rel="stylesheet">

<!-- Template Main CSS File -->
<link href="/elderlycare/assets/css/style.css" rel="stylesheet">

</head>
<style>
  

  .notification-item.unread {
    background-color: #f0f8ff;
  }
  .notification-item.unread p {
    font-weight: bold;
  }
 
.dropdown-menu.notifications {
  max-height: 300px;     
  overflow-y: auto;
  padding-right: 0;     
}


.dropdown-menu.notifications::-webkit-scrollbar {
  width: 6px;
}
.dropdown-menu.notifications::-webkit-scrollbar-track {
  background: transparent;
}
.dropdown-menu.notifications::-webkit-scrollbar-thumb {
  background-color: rgba(0,0,0,0.2);
  border-radius: 3px;
}
@media (max-width: 576px), (max-width: 780px) {
  .dropdown-menu.profile {
    position: fixed !important;
    top: 60px;
    left: 0 !important;
    right: 0 !important;
    border-radius: 0;
    z-index: 1050;
  }
}
.dropdown-menu.notifications {
  max-height: 400px;
  overflow-y: auto;
}

@media (max-width: 576px) {
  .dropdown-menu.notifications {
    position: fixed !important;
    top: 60px;
    left: 0 !important;
    right: 0 !important;
    width: 100vw !important;
    max-width: none !important;
    border-radius: 0;
    z-index: 1050;
  }
}
</style>
<body>
<header id="header" class="header fixed-top d-flex align-items-center">

<div class="d-flex align-items-center justify-content-between">
  <a href="AdminDashboard.php" class="logo d-flex align-items-center">
  <img src="/elderlycare/assets/img/logo.png" alt="Logo">
    <span class="d-none d-lg-block">ElderlyCare</span>
  </a>
  <i class="bi bi-list toggle-sidebar-btn"></i>
</div>

<nav class="header-nav ms-auto">
  <ul class="d-flex align-items-center">

  
 <!-- Notifications -->
<li class="nav-item dropdown">
  <a id="notificationBell" class="nav-link nav-icon" href="#" data-bs-toggle="dropdown">
    <i class="bi bi-bell"></i>
    <?php if ($unread_count > 0): ?>
      <span class="badge bg-primary badge-number"><?= $unread_count ?></span>
    <?php endif; ?>
  </a>

 <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow notifications"
    style="max-width: 350px; word-wrap: break-word;">
  <li class="dropdown-header">
    <span>
      You have <?= $unread_count ?> new notification<?= $unread_count !== 1 ? 's' : ''; ?>
    </span>
    <?php if ($unread_count > 0): ?>
      <div class="mt-1">
        <form method="POST" style="display:inline;">
          <button type="submit" name="markAllRead" class="btn" style="font-size: 13px; height: 35px;">
            Mark all as read
          </button>
        </form>
      </div>
    <?php endif; ?>
  </li>
  <li><hr class="dropdown-divider"></li>

  <?php foreach ($notifications as $notif):
    $url = "?notif_id=" . $notif['id'];
    $liClass = $notif['is_read'] == 0 ? 'notification-item unread' : 'notification-item';
  ?>
    <li class="<?= $liClass ?>">
      <a href="<?= $url ?>" class="d-flex align-items-start text-decoration-none">
        <i class="bi bi-info-circle text-info me-2"></i>
        <div>
          <p class="mb-1"><?= htmlspecialchars($notif['message']) ?></p>
          <small class="text-muted">
            <?= date("M d, Y h:i A", strtotime($notif['created_at'])) ?>
          </small>
        </div>
      </a>
    </li>
    <li><hr class="dropdown-divider"></li>
  <?php endforeach; ?>
</ul>

</li>
<!-- End Notifications -->

      <?php
  include('conn.php');

  $query = "SELECT fullname, position, admin_picture FROM admins WHERE id = 1";
  $stmt = $conn->prepare($query);
  $stmt->execute();
  $stmt->bind_result($fullname, $position, $adminPicture);
  $stmt->fetch();
  $stmt->close();
?>
<li class="nav-item dropdown pe-3">
  <a class="nav-link nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown">
    <?php if (!empty($adminPicture)): ?>
      <img src="uploads/admin/<?= htmlspecialchars($adminPicture) ?>"
           alt="Profile"
           class="rounded-circle"
           style="object-fit: cover; width: 40px; height: 40px;" />
    <?php else: ?>
      <div class="rounded-circle bg-secondary d-flex justify-content-center align-items-center"
           style="width: 40px; height: 40px;">
        <i class="bi bi-person text-white fs-5"></i>
      </div>
    <?php endif; ?>
    <span class="dropdown-toggle d-none d-md-inline-block text-truncate" style="max-width: 120px;">
      <?= htmlspecialchars($fullname) ?>
    </span>
  </a>

  <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow profile w-100" style="max-width: none; word-wrap: break-word;">
    <li class="dropdown-header">
      <h6><?= htmlspecialchars($fullname) ?></h6>
      <span><?= htmlspecialchars($position) ?></span>
    </li>

    <li><hr class="dropdown-divider"></li>

    <li>
      <a class="dropdown-item d-flex align-items-center" href="admin_profile.php">
        <i class="bi bi-person"></i>
        <span>My Profile</span>
      </a>
    </li>

    <li><hr class="dropdown-divider"></li>

    <li>
      <a class="dropdown-item d-flex align-items-center" href="/elderlycare/logout.php">
        <i class="bi bi-box-arrow-right"></i>
        <span>Sign Out</span>
      </a>
    </li>
  </ul>
</li>

  </nav>
    </header>

  <aside id="admin-sidebar" class="sidebar">
    <h3 class="text-white text-center space-below">Admin Dashboard</h3>
    <ul class="sidebar-nav" id="admin-sidebar-nav">
      <li class="nav-item">
        <a class="nav-link collapsed" href="AdminDashboard.php">
          <i class="bi bi-house-door"></i>
          <span>Dashboard</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="manage_rooms.php">
          <i class="bi bi-door-open"></i>
          <span>Manage Patient Rooms </span>
        </a>
    </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="caregiver_account_request.php">
          <i class="bi bi-check-circle"></i>
          <span>Caregiver Approvals </span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="patients_request.php">
          <i class="bi bi-person-check"></i>
          <span>Patient's Approvals </span>
        </a>
    </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="manage_patients.php">
          <i class="bi bi-file-earmark-person"></i>
          <span>Manage Patients</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="manage_caregivers.php">
          <i class="bi bi-person-bounding-box"></i>
          <span>Manage Caregivers</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="view_reports.php">
          <i class="bi bi-file-earmark-text"></i>
          <span>View Reports</span>
        </a>
      </li>
    </ul>
    </aside>

  <?php
  include 'conn.php'; 
$sql = "SELECT c.id, c.email, c.status, 
               ci.full_name, ci.pic, ci.dob, ci.gender, ci.contact_phone, 
               ci.address, ci.availability, ci.emergency_contact_name, 
               ci.emergency_contact_phone, ci.background_check, ci.health_check 
        FROM caregivers c
        JOIN caregivers_info ci ON c.id = ci.caregiver_id";

$result = $conn->query($sql);

?>

<main id="main" class="main">
  <div class="pagetitle">
    <h2>Manage Caregivers</h2>
    <nav>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="AdminDashboard.php">Home</a></li>
        <li class="breadcrumb-item">Caregivers</li>
        <li class="breadcrumb-item active">Management</li>
      </ol>
    </nav>
  </div>

  <section class="section">
    <div class="row">
      <div class="col-lg-12">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title">Manage Caregivers</h5>

            <!-- ✅ Responsive wrapper added -->
            <div class="table-responsive">
              <table class="table table-bordered" id="caregiverTable">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Profile Picture</th>
                    <th>Full Name</th>
                    <th>DOB</th>
                    <th>Gender</th>
                    <th>Contact</th>
                    <th>Address</th>
                    <th>Availability</th>
                    <th>Emergency Contact</th>
                    <th>Background Check</th>
                    <th>Health Check</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                  if ($result->num_rows > 0) {
                    $counter = 1;
                    while ($row = $result->fetch_assoc()) {
                      $imageFilename = $row['pic'] ? $row['pic'] : 'default-avatar.png';

                  $adminPath = "/ElderlyCare/templates/admin/uploads/caregivers/";
                  $caregiverPath = "/ElderlyCare/templates/caregiver/uploads/caregivers/";


                      $localAdminFile = $_SERVER['DOCUMENT_ROOT'] . "/ElderlyCare/templates/admin/uploads/caregivers/" . $imageFilename;
                      $localCaregiverFile = $_SERVER['DOCUMENT_ROOT'] . "/ElderlyCare/templates/caregiver/uploads/caregivers/" . $imageFilename;

                      if (file_exists($localAdminFile)) {
                          $imagePath = $adminPath . $imageFilename;
                      } elseif (file_exists($localCaregiverFile)) {
                          $imagePath = $caregiverPath . $imageFilename;
                      } else {
                          $imagePath = "http://localhost/ElderlyCare/assets/img/default-avatar.png";
                      }

                      $backgroundCheck = $row['background_check'] ? '✔️' : '❌';
                      $healthCheck = $row['health_check'] ? '✔️' : '❌';

                      echo '<tr>
                        <td>' . $counter++ . '</td>
                        <td>
                          <img src="' . $imagePath . '" 
                               alt="Profile Picture" 
                               class="img-thumbnail" 
                               style="width: 100px; height: 100px; object-fit: cover; cursor: pointer;" 
                               data-bs-toggle="modal" data-bs-target="#profilePictureModal-' . $row['id'] . '">
                        </td>
                        <td>' . $row['full_name'] . '</td>
                        <td>' . $row['dob'] . '</td>
                        <td>' . ucfirst($row['gender']) . '</td>
                        <td>' . $row['contact_phone'] . '</td>
                        <td>' . $row['address'] . '</td>
                        <td>' . ucfirst($row['availability']) . '</td>
                        <td>' . $row['emergency_contact_name'] . '<br><small class="text-muted">' . $row['emergency_contact_phone'] . '</small></td>
                        <td>' . $backgroundCheck . '</td>
                        <td>' . $healthCheck . '</td>
                        <td>
                          <button class="btn" data-bs-toggle="modal" data-bs-target="#deleteModal" data-id="' . $row['id'] . '">Remove Caregiver</button>
                        </td>
                      </tr>';

                      // Profile Picture Modal
                      echo '<div class="modal fade" id="profilePictureModal-' . $row['id'] . '" tabindex="-1" aria-labelledby="profilePictureModalLabel" aria-hidden="true">
                              <div class="modal-dialog modal-dialog-centered modal-lg">
                                <div class="modal-content">
                                  <div class="modal-header">
                                    <h5 class="modal-title">Profile Picture</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                  </div>
                                  <div class="modal-body text-center">
                                    <img src="' . $imagePath . '" class="img-fluid" style="max-height:80vh;">
                                  </div>
                                </div>
                              </div>
                            </div>';
                    }
                  } else {
                    echo '<tr><td colspan="12" class="text-center">No caregivers found</td></tr>';
                  }
                  ?>
                </tbody>
              </table>
            </div>
            <!-- ✅ End responsive wrapper -->

            <!-- Delete Modal -->
            <div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
              <div class="modal-dialog">
                <form method="POST" action="process.php">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title">Confirm Deletion</h5>
                      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                      <p>Are you sure you want to delete this caregiver?</p>
                      <input type="hidden" name="action" value="delete_caregiver">
                      <input type="hidden" id="caregiverIdToDelete" name="id" value="">
                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn " data-bs-dismiss="modal">Cancel</button>
                      <button type="submit" class="btn ">Delete</button>
                    </div>
                  </div>
                </form>
              </div>
            </div>

            <!-- Scripts -->
            <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
            <script>
              const deleteModal = document.getElementById('deleteModal');
              deleteModal.addEventListener('show.bs.modal', function (event) {
                const button = event.relatedTarget;
                const caregiverId = button.getAttribute('data-id');
                document.getElementById('caregiverIdToDelete').value = caregiverId;
              });
            </script>

          </div>
        </div>
      </div>
    </div>
  </section>
</main>

<footer id="footer" class="footer">
    <div class="copyright">
        &copy; Copyright <strong><span>ElderlyCare</span></strong>. All Rights Reserved
    </div>
</footer>
<a href="#" class="back-to-top d-flex align-items-center justify-content-center">
    <i class="bi bi-arrow-up-short"></i>
</a>


<script src="/elderlycare/assets/js/main.js"></script>

</body>

</html>
