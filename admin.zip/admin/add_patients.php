<?php
session_start();
include 'conn.php';

if (!isset($_SESSION['admin_id'])) {
    echo "<script>
        alert('Please log in first');
        window.location.href = '/elderlycare/index.php';
    </script>";
    exit();
}

header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

$admin_id = $_SESSION['admin_id'];

$notif_sql = "SELECT id, message, is_read, type, reference_id, created_at 
              FROM admin_notifications 
              WHERE type != 'medicine' AND user_type = 'caregiver'
              ORDER BY created_at DESC 
              LIMIT 7";

$notif_result = mysqli_query($conn, $notif_sql);
$notifications = mysqli_fetch_all($notif_result, MYSQLI_ASSOC);

$unread_count = 0;
foreach ($notifications as $n) {
    if ($n['is_read'] == 0) $unread_count++;
}

if (isset($_POST['markAllRead'])) {
    $sql = "UPDATE admin_notifications 
            SET is_read = 1 
            WHERE user_type = 'caregiver'";
    mysqli_query($conn, $sql);

    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}

if (isset($_GET['notif_id'])) {
    $notif_id = intval($_GET['notif_id']);

    // Mark as read only if created by caregiver
    mysqli_query($conn, "UPDATE admin_notifications 
                         SET is_read = 1 
                         WHERE id = $notif_id AND user_type = 'caregiver'");

    $notif_info = mysqli_fetch_assoc(
        mysqli_query($conn, "SELECT type, reference_id 
                             FROM admin_notifications 
                             WHERE id = $notif_id AND user_type = 'caregiver'")
    );

    if ($notif_info) {
        if ($notif_info['type'] === 'new_caregiver') {
            header("Location: caregiver_account_request.php?id=" . $notif_info['reference_id']);
        } elseif ($notif_info['type'] === 'deleted_patient') {
            header("Location: managepatient.php");
        } else {
            header("Location: patients_request.php?id=" . $notif_info['reference_id']);
        }
    }
    exit();
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Patients</title>


<link href="/elderlycare/assets/img/logo.png" rel="icon">



<link href="https://fonts.gstatic.com" rel="preconnect">
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">


<link href="/elderlycare/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/quill/quill.snow.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/quill/quill.bubble.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/remixicon/remixicon.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/simple-datatables/style.css" rel="stylesheet">


<link href="/elderlycare/assets/css/style.css" rel="stylesheet">
</head>
<style>
  

  .notification-item.unread {
    background-color: #f0f8ff;
  }
  .notification-item.unread p {
    font-weight: bold;
  }
 
.dropdown-menu.notifications {
  max-height: 300px;      
  overflow-y: auto;
  padding-right: 0;      
}


.dropdown-menu.notifications::-webkit-scrollbar {
  width: 6px;
}
.dropdown-menu.notifications::-webkit-scrollbar-track {
  background: transparent;
}
.dropdown-menu.notifications::-webkit-scrollbar-thumb {
  background-color: rgba(0,0,0,0.2);
  border-radius: 3px;
}

</style>
<body>

<header id="header" class="header fixed-top d-flex align-items-center">

<div class="d-flex align-items-center justify-content-between">
  <a href="AdminDashboard.php" class="logo d-flex align-items-center">
  <img src="/elderlycare/assets/img/logo.png" alt="Logo">
    <span class="d-none d-lg-block">ElderlyCare</span>
  </a>
  <i class="bi bi-list toggle-sidebar-btn"></i>
</div>

<nav class="header-nav ms-auto">
  <ul class="d-flex align-items-center">

  
   <!-- Notifications -->
<li class="nav-item dropdown">
  <a id="notificationBell" class="nav-link nav-icon" href="#" data-bs-toggle="dropdown">
    <i class="bi bi-bell"></i>
    <?php if ($unread_count > 0): ?>
      <span class="badge bg-primary badge-number"><?= $unread_count ?></span>
    <?php endif; ?>
  </a>

  <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow notifications">
    <li class="dropdown-header">
      <span>
        You have <?= $unread_count ?> new notification<?= $unread_count !== 1 ? 's' : ''; ?>
      </span>
      <?php if ($unread_count > 0): ?>
        <div class="mt-1">
          <form method="POST"style="display:inline;">
          <button type="submit" name="markAllRead" class="btn" style="font-size: 13px; height: 35px;">
            Mark all as read
          </button>

          </form>
        </div>
      <?php endif; ?>
    </li>

    <li><hr class="dropdown-divider"></li>

    <?php foreach ($notifications as $notif):
      $url = "?notif_id=" . $notif['id'];
      $liClass = $notif['is_read'] == 0 ? 'notification-item unread' : 'notification-item';
    ?>
      <li class="<?= $liClass ?>">
        <a href="<?= $url ?>" class="d-flex align-items-start text-decoration-none">
          <i class="bi bi-info-circle text-info me-2"></i>
          <div>
            <p class="mb-1"><?= htmlspecialchars($notif['message']) ?></p>
            <small class="text-muted">
              <?= date("M d, Y h:i A", strtotime($notif['created_at'])) ?>
            </small>
          </div>
        </a>
      </li>
      <li><hr class="dropdown-divider"></li>
    <?php endforeach; ?>
  </ul>
</li>
<!-- End Notifications -->

      <?php
  include('conn.php');

  $query = "SELECT fullname, position, admin_picture FROM admins WHERE id = 1";
  $stmt = $conn->prepare($query);
  $stmt->execute();
  $stmt->bind_result($fullname, $position, $adminPicture);
  $stmt->fetch();
  $stmt->close();
?>
<li class="nav-item dropdown pe-3">
  <a class="nav-link nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown">
    <?php if (!empty($adminPicture)): ?>
      <img src="uploads/admin/<?= htmlspecialchars($adminPicture) ?>"
           alt="Profile"
           class="rounded-circle"
           style="object-fit: cover; width: 40px; height: 40px;" />
    <?php else: ?>
      <div class="rounded-circle bg-secondary d-flex justify-content-center align-items-center"
           style="width: 40px; height: 40px;">
        <i class="bi bi-person text-white fs-5"></i>
      </div>
    <?php endif; ?>
    <span class="d-none d-md-block dropdown-toggle ps-2"><?= htmlspecialchars($fullname) ?></span>
  </a>

  <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow profile">
    <li class="dropdown-header">
      <h6><?= htmlspecialchars($fullname) ?></h6>
      <span><?= htmlspecialchars($position) ?></span>
    </li>

    <li><hr class="dropdown-divider"></li>

    <li>
      <a class="dropdown-item d-flex align-items-center" href="admin_profile.php">
        <i class="bi bi-person"></i>
        <span>My Profile</span>
      </a>
    </li>

    <li><hr class="dropdown-divider"></li>

    <li>
      <a class="dropdown-item d-flex align-items-center" href="/elderlycare/logout.php">
        <i class="bi bi-box-arrow-right"></i>
        <span>Sign Out</span>
      </a>
    </li>
  </ul>
</li>

  </nav>
    </header>


 
  <aside id="admin-sidebar" class="sidebar">
  <h3 class="text-white text-center space-below">Admin Dashboard</h3>
  <ul class="sidebar-nav" id="admin-sidebar-nav">

    <li class="nav-item ">
      <a class="nav-link collapsed" href="AdminDashboard.php">
        <i class="bi bi-house-door"></i>
        <span>Dashboard</span>
      </a>
    </li>
    
    <li class="nav-item">
      <a class="nav-link" href="add_patients.php">
        <i class="bi bi-person-plus"></i>
        <span>Add Patient</span>
      </a>
    </li>
    <li class="nav-item">
        <a class="nav-link collapsed" href="caregiver_account_request.php">
          <i class="bi bi-check-circle"></i>
          <span>Caregiver Approvals </span>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link collapsed" href="patients_request.php">
          <i class="bi bi-person-check"></i>
          <span>Patient's Approvals </span>
        </a>
    </li>
    <li class="nav-item">
      <a class="nav-link collapsed" href="manage_patients.php">
      <i class="bi bi-file-earmark-person"></i> 
        <span>Manage Patients</span>
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link collapsed" href="manage_caregivers.php">
        <i class="bi bi-person-bounding-box"></i>
        <span>Manage Caregivers</span>
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link collapsed" href="view_reports.php">
      <i class="bi bi-file-earmark-text"></i> 
        <span>View Reports</span>
      </a>
    </li>

  </ul>
</aside>

<main id="main" class="main">
  <div class="pagetitle">
    <h2>Add New Patient</h2>
    <nav>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="/dashboard">Home</a></li>
        <li class="breadcrumb-item"><a href="CaregiverDashboard.php">Caregiver Dashboard</a></li>
        <li class="breadcrumb-item active">Add Patient</li>
      </ol>
    </nav>
  </div>

  <section class="section">
    <div class="row">
      <div class="col-lg-12">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title">Patient Details</h5>
         
          <form action="process.php" method="POST" enctype="multipart/form-data">
          <input type="hidden" name="action" value="add_patient">
                   
                    <div class="row mb-3">
                        <label for="caregiver" class="col-sm-2 col-form-label">Assign Caregiver</label>
                        <div class="col-sm-10">

                            <select name="caregiver_id" class="form-control" required>
                                <option value="">-- Select Caregiver --</option>
                                <?php
                                include 'conn.php';
                                $sql = "SELECT c.id, ci.full_name FROM caregivers c
                                        JOIN caregivers_info ci ON c.id = ci.caregiver_id"; 
                                $result = mysqli_query($conn, $sql);

                                while ($row = mysqli_fetch_assoc($result)) {
                                    echo "<option value='{$row['id']}'>{$row['full_name']}</option>";
                                }
                                ?>
                            </select>
                        </div>
                    </div>

              
                <div class="row mb-3">
                    <label for="firstName" class="col-sm-2 col-form-label">First Name</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="firstName" name="first_name" placeholder="Enter First Name" required>
                    </div>
                </div>

                <div class="row mb-3">
                    <label for="middleName" class="col-sm-2 col-form-label">Middle Name</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="middleName" name="middle_name" placeholder="Enter Middle Name">
                    </div>
                </div>

                <div class="row mb-3">
                    <label for="lastName" class="col-sm-2 col-form-label">Last Name</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="lastName" name="last_name" placeholder="Enter Last Name" required>
                    </div>
                </div>

                <div class="row mb-3">
                    <label for="dob" class="col-sm-2 col-form-label">Date of Birth</label>
                    <div class="col-sm-10">
                        <input type="date" class="form-control" id="dob" name="dob" required>
                    </div>
                </div>

            
                <div class="row mb-3">
                    <label for="healthStatus" class="col-sm-2 col-form-label">Health Status</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="healthStatus" name="health_status" placeholder="Enter Health Status" required>
                    </div>
                </div>

               
                <div class="row mb-3">
                    <label for="emergencyContactName" class="col-sm-2 col-form-label">Emergency Contact Name</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="emergencyContactName" name="emergency_contact_name" placeholder="Enter Emergency Contact Name" required>
                    </div>
                </div>

                <div class="row mb-3">
                    <label for="emergencyContactNumber" class="col-sm-2 col-form-label">Emergency Contact Number</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="emergencyContactNumber" name="emergency_contact_number" placeholder="Enter Emergency Contact Number" required>
                    </div>
                </div>
                <div class="row mb-3">
                <label for="contact" class="col-sm-2 col-form-label">Email Address </label>
                <div class="col-sm-10">
                  <input type="int" class="form-control" id="emailAddress" name="email_address" placeholder="Enter Email Address" required>
                </div>
              </div>
                <div class="row mb-3">
                    <label for="relationship" class="col-sm-2 col-form-label">Relationship</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="relationship" name="relationship" placeholder="Enter Relationship" required>
                    </div>
                </div>

              
                <div class="row mb-3">
                    <label for="address" class="col-sm-2 col-form-label">Address</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="address" name="address" placeholder="Enter Address" required>
                    </div>
                </div>

                
                <div class="row mb-3">
                    <label for="medications" class="col-sm-2 col-form-label">Medications</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="medications" name="medications" placeholder="Enter Medications" required>
                    </div>
                </div>

                
                <div class="row mb-3">
                    <label for="notes" class="col-sm-2 col-form-label">Notes</label>
                    <div class="col-sm-10">
                        <textarea class="form-control" id="notes" name="notes" rows="3" placeholder="Enter Notes"></textarea>
                    </div>
                </div>

               
                <div class="row mb-3">
                    <label for="patientImage" class="col-sm-2 col-form-label">Profile Picture</label>
                    <div class="col-sm-10">
                        <input type="file" name="patient_image" accept="image/*">
                    </div>
                </div>

               
                <div class="d-flex justify-content-center">
                    <button type="submit" class="btn" style="height: 50px;">Add Patient</button>
                </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </section>
</main>

<footer id="footer" class="footer">
  <div class="copyright">
    &copy; Copyright <strong><span>ElderlyCare</span></strong>. All Rights Reserved
  </div>
</footer>


<script src="/elderlycare/assets/js/main.js"></script>
<script src="/elderlycare/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>
