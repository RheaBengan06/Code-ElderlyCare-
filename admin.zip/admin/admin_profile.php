<?php
session_start();
include 'conn.php';

if (!isset($_SESSION['admin_id'])) {
    echo "<script>
        alert('Please log in first');
        window.location.href = '/elderlycare/index.php';
    </script>";
    exit();
}

header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");




$adminId = 1;

$admin = [];

if ($adminId) {
    $query = "SELECT * FROM admins WHERE id = $adminId LIMIT 1";
    $result = mysqli_query($conn, $query);

    if ($result && mysqli_num_rows($result) > 0) {
        $admin = mysqli_fetch_assoc($result);
    }
}

$notif_sql = "SELECT id, message, is_read, type, reference_id, created_at 
              FROM admin_notifications 
              WHERE type != 'medicine' AND user_type = 'caregiver'
              ORDER BY created_at DESC 
              LIMIT 7";

$notif_result = mysqli_query($conn, $notif_sql);
$notifications = mysqli_fetch_all($notif_result, MYSQLI_ASSOC);

$unread_count = 0;
foreach ($notifications as $n) {
    if ($n['is_read'] == 0) $unread_count++;
}

if (isset($_POST['markAllRead'])) {
    $sql = "UPDATE admin_notifications 
            SET is_read = 1 
            WHERE user_type = 'caregiver'";
    mysqli_query($conn, $sql);

    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}

if (isset($_GET['notif_id'])) {
    $notif_id = intval($_GET['notif_id']);

    // Mark as read only if created by caregiver
    mysqli_query($conn, "UPDATE admin_notifications 
                         SET is_read = 1 
                         WHERE id = $notif_id AND user_type = 'caregiver'");

    $notif_info = mysqli_fetch_assoc(
        mysqli_query($conn, "SELECT type, reference_id 
                             FROM admin_notifications 
                             WHERE id = $notif_id AND user_type = 'caregiver'")
    );

    if ($notif_info) {
        if ($notif_info['type'] === 'new_caregiver') {
            header("Location: caregiver_account_request.php?id=" . $notif_info['reference_id']);
        } elseif ($notif_info['type'] === 'deleted_patient') {
            header("Location: managepatient.php");
        } else {
            header("Location: patients_request.php?id=" . $notif_info['reference_id']);
        }
    }
    exit();
}


?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Patients</title>

<!-- Favicons -->
<link href="/elderlycare/assets/img/logo.png" rel="icon">

<!-- Google Fonts -->
<link href="https://fonts.gstatic.com" rel="preconnect">
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

<!-- Vendor CSS Files -->
<link href="/elderlycare/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/quill/quill.snow.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/quill/quill.bubble.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/remixicon/remixicon.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/simple-datatables/style.css" rel="stylesheet">

<!-- Template Main CSS File -->
<link href="/elderlycare/assets/css/style.css" rel="stylesheet">
</head>
<style>
  
 
  .notification-item.unread {
    background-color: #f0f8ff;
  }
  .notification-item.unread p {
    font-weight: bold;
  }

.dropdown-menu.notifications {
  max-height: 300px;      
  overflow-y: auto;
  padding-right: 0;       
}


.dropdown-menu.notifications::-webkit-scrollbar {
  width: 6px;
}
.dropdown-menu.notifications::-webkit-scrollbar-track {
  background: transparent;
}
.dropdown-menu.notifications::-webkit-scrollbar-thumb {
  background-color: rgba(0,0,0,0.2);
  border-radius: 3px;
}
@media (max-width: 576px), (max-width: 780px) {
  .dropdown-menu.profile {
    position: fixed !important;
    top: 60px;
    left: 0 !important;
    right: 0 !important;
    border-radius: 0;
    z-index: 1050;
  }
}
.dropdown-menu.notifications {
  max-height: 400px;
  overflow-y: auto;
}

@media (max-width: 576px) {
  .dropdown-menu.notifications {
    position: fixed !important;
    top: 60px;
    left: 0 !important;
    right: 0 !important;
    width: 100vw !important;
    max-width: none !important;
    border-radius: 0;
    z-index: 1050;
  }
}
</style>
<body>



<header id="header" class="header fixed-top d-flex align-items-center">

<div class="d-flex align-items-center justify-content-between">
  <a href="AdminDashboard.php" class="logo d-flex align-items-center">
  <img src="/elderlycare/assets/img/logo.png" alt="Logo">
    <span class="d-none d-lg-block">ElderlyCare</span>
  </a>
  <i class="bi bi-list toggle-sidebar-btn"></i>
</div>

<nav class="header-nav ms-auto">
  <ul class="d-flex align-items-center">

  
 <!-- Notifications -->
<li class="nav-item dropdown">
  <a id="notificationBell" class="nav-link nav-icon" href="#" data-bs-toggle="dropdown">
    <i class="bi bi-bell"></i>
    <?php if ($unread_count > 0): ?>
      <span class="badge bg-primary badge-number"><?= $unread_count ?></span>
    <?php endif; ?>
  </a>

 <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow notifications"
    style="max-width: 350px; word-wrap: break-word;">
  <li class="dropdown-header">
    <span>
      You have <?= $unread_count ?> new notification<?= $unread_count !== 1 ? 's' : ''; ?>
    </span>
    <?php if ($unread_count > 0): ?>
      <div class="mt-1">
        <form method="POST" style="display:inline;">
          <button type="submit" name="markAllRead" class="btn" style="font-size: 13px; height: 35px;">
            Mark all as read
          </button>
        </form>
      </div>
    <?php endif; ?>
  </li>
  <li><hr class="dropdown-divider"></li>

  <?php foreach ($notifications as $notif):
    $url = "?notif_id=" . $notif['id'];
    $liClass = $notif['is_read'] == 0 ? 'notification-item unread' : 'notification-item';
  ?>
    <li class="<?= $liClass ?>">
      <a href="<?= $url ?>" class="d-flex align-items-start text-decoration-none">
        <i class="bi bi-info-circle text-info me-2"></i>
        <div>
          <p class="mb-1"><?= htmlspecialchars($notif['message']) ?></p>
          <small class="text-muted">
            <?= date("M d, Y h:i A", strtotime($notif['created_at'])) ?>
          </small>
        </div>
      </a>
    </li>
    <li><hr class="dropdown-divider"></li>
  <?php endforeach; ?>
</ul>

</li>
<!-- End Notifications -->

      <?php
  include('conn.php');

  $query = "SELECT fullname, position, admin_picture FROM admins WHERE id = 1";
  $stmt = $conn->prepare($query);
  $stmt->execute();
  $stmt->bind_result($fullname, $position, $adminPicture);
  $stmt->fetch();
  $stmt->close();
?>
<li class="nav-item dropdown pe-3">
  <a class="nav-link nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown">
    <?php if (!empty($adminPicture)): ?>
      <img src="uploads/admin/<?= htmlspecialchars($adminPicture) ?>"
           alt="Profile"
           class="rounded-circle"
           style="object-fit: cover; width: 40px; height: 40px;" />
    <?php else: ?>
      <div class="rounded-circle bg-secondary d-flex justify-content-center align-items-center"
           style="width: 40px; height: 40px;">
        <i class="bi bi-person text-white fs-5"></i>
      </div>
    <?php endif; ?>
    <span class="dropdown-toggle d-none d-md-inline-block text-truncate" style="max-width: 120px;">
      <?= htmlspecialchars($fullname) ?>
    </span>
  </a>

  <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow profile w-100" style="max-width: none; word-wrap: break-word;">
    <li class="dropdown-header">
      <h6><?= htmlspecialchars($fullname) ?></h6>
      <span><?= htmlspecialchars($position) ?></span>
    </li>

    <li><hr class="dropdown-divider"></li>

    <li>
      <a class="dropdown-item d-flex align-items-center" href="admin_profile.php">
        <i class="bi bi-person"></i>
        <span>My Profile</span>
      </a>
    </li>

    <li><hr class="dropdown-divider"></li>

    <li>
      <a class="dropdown-item d-flex align-items-center" href="/elderlycare/logout.php">
        <i class="bi bi-box-arrow-right"></i>
        <span>Sign Out</span>
      </a>
    </li>
  </ul>
</li>

  </nav>
    </header>


<aside id="sidebar" class="sidebar">

    <ul class="sidebar-nav" id="sidebar-nav">

        <li class="nav-item">
            <a class="nav-link collapsed" href="AdminDashboard.php">
                <i class="bi bi-house-door"></i>
                <span>Dashboard</span>
            </a>
        </li>

        <li class="nav-item">
            <a class="nav-link " href="admin_profile.php">
                <i class="bi bi-person"></i>
                <span>Profile</span>
            </a>
        </li>

    </ul>

</aside>

<main id="main" class="main">
  <div class="pagetitle">
    <h2>Admin Profile</h2>
    <nav>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="AdminDashboard.php">Home</a></li>
        <li class="breadcrumb-item">Admin</li>
        <li class="breadcrumb-item active">Profile</li>
      </ol>
    </nav>
  </div>

  <section class="section profile">
    <div class="row justify-content-center">
      <div class="row">
        <div class="card">
          <div class="card-body pt-3">
           
            <ul class="nav nav-tabs nav-tabs-bordered">
              <li class="nav-item">
                <button class="nav-link active" data-bs-toggle="tab" data-bs-target="#profile-overview">Overview</button>
              </li>
              <li class="nav-item">
                <button class="nav-link" data-bs-toggle="tab" data-bs-target="#add-admin-profile">Add Admin's Profile</button>
              </li>
              <li class="nav-item">
                <button class="nav-link" data-bs-toggle="tab" data-bs-target="#profile-change-password">Change Password</button>
              </li>
            </ul>
            <div class="tab-content pt-2">


              <div class="tab-pane fade show active profile-overview" id="profile-overview">
                <h5 class="card-title mb-4">Profile Details</h5>

                <div class="row mb-3">
                  <div class="col-lg-3 col-md-4 label">Profile Picture</div>
                  <div class="col-lg-6 col-md-8 text-center">
                      <img src="<?= !empty($admin['admin_picture']) ? 'uploads/admin/' . $admin['admin_picture'] : 'static/img/profile-img.jpg' ?>" alt="Profile Picture" class="img-fluid" style="max-width: 150px; border-radius: 20%;">
                  </div>
                </div>

                <div class="row mb-3">
                  <div class="col-lg-3 col-md-4 label">Full Name</div>
                  <div class="col-lg-9 col-md-8"><?= isset($admin['fullname']) ? $admin['fullname'] : 'N/A'; ?></div>
                </div>

                <div class="row mb-3">
                  <div class="col-lg-3 col-md-4 label">Position</div>
                  <div class="col-lg-9 col-md-8"><?= isset($admin['position']) ? $admin['position'] : 'N/A'; ?></div>
                </div>

                <div class="row mb-3">
                  <div class="col-lg-3 col-md-4 label">Address</div>
                  <div class="col-lg-9 col-md-8"><?= isset($admin['address']) ? $admin['address'] : 'N/A'; ?></div>
                </div>

                <div class="row mb-3">
                  <div class="col-lg-3 col-md-4 label">Phone</div>
                  <div class="col-lg-9 col-md-8"><?= isset($admin['phone_num']) ? $admin['phone_num'] : 'N/A'; ?></div>
                </div>

                <div class="row mb-3">
                  <div class="col-lg-3 col-md-4 label">Email</div>
                  <div class="col-lg-9 col-md-8"><?= isset($admin['email']) ? $admin['email'] : 'N/A'; ?></div>
                </div>
              </div>

          
              <div class="tab-pane fade" id="add-admin-profile">
                <form action="process.php" method="POST" enctype="multipart/form-data">
                  <input type="hidden" name="admin_id" value="<?= $admin['id'] ?>">
                  <input type="hidden" name="remove_image" id="removeImageFlag" value="0">

                  <div class="row mb-3">
                    <label for="profileImage" class="col-md-7 col-lg-5 col-form-label">Profile Image</label>
                    <div class="col-lg-2 col-md-8 text-center">
                      <img src="<?= !empty($admin['admin_picture']) ? 'uploads/admin/' . $admin['admin_picture'] : 'static/img/profile-img.jpg' ?>" 
                           alt="Profile" 
                           class="img-fluid mb-3 rounded-circle" 
                           style="max-width: 150px;" 
                           id="profileImagePreview">

                      <input type="file" name="admin_picture" class="form-control" id="profileImageInput" style="display: none;" onchange="previewImage(event)">

                      <div class="d-flex justify-content-center gap-2">
                        <a href="javascript:void(0);" class="btn btn-secondary" title="Upload new profile image" onclick="document.getElementById('profileImageInput').click();">
                          <i class="bi bi-upload"></i> Upload
                        </a>
                        <a href="#" class="btn btn-danger" title="Remove my profile image" onclick="removeProfileImage(); return false;">
                          <i class="bi bi-trash"></i> Remove
                        </a>
                      </div>
                    </div>
                  </div>

                  <div class="row mb-3">
                    <label for="fullName" class="col-md-4 col-lg-3 col-form-label">Full Name</label>
                    <div class="col-md-8 col-lg-9">
                      <input name="fullName" type="text" class="form-control" id="fullName" value="<?= isset($admin['fullname']) ? $admin['fullname'] : ''; ?>">
                    </div>
                  </div>

                  <div class="row mb-3">
                    <label for="position" class="col-md-4 col-lg-3 col-form-label">Position</label>
                    <div class="col-md-8 col-lg-9">
                      <input name="position" type="text" class="form-control" id="position" value="<?= isset($admin['position']) ? $admin['position'] : ''; ?>">
                    </div>
                  </div>

                  <div class="row mb-3">
                    <label for="address" class="col-md-4 col-lg-3 col-form-label">Address</label>
                    <div class="col-md-8 col-lg-9">
                      <input name="address" type="text" class="form-control" id="address" value="<?= isset($admin['address']) ? $admin['address'] : ''; ?>">
                    </div>
                  </div>

                  <div class="row mb-3">
                    <label for="phone" class="col-md-4 col-lg-3 col-form-label">Phone</label>
                    <div class="col-md-8 col-lg-9">
                      <input name="phone" type="text" class="form-control" id="phone" value="<?= isset($admin['phone_num']) ? $admin['phone_num'] : ''; ?>">
                    </div>
                  </div>

                  <div class="row mb-3">
                    <label for="email" class="col-md-4 col-lg-3 col-form-label">Email</label>
                    <div class="col-md-8 col-lg-9">
                      <input name="email" type="email" class="form-control" id="email" value="<?= isset($admin['email']) ? $admin['email'] : ''; ?>">
                    </div>
                  </div>

                  <div class="text-center">
                    <button type="submit" name="addAdmin" class="btn btn-primary">Save Changes</button>
                  </div>
                </form>
              </div>

       <div class="tab-pane fade pt-3" id="profile-change-password">
             <form action="process.php" method="POST">
                  <!-- Current Password -->
                  <div class="row mb-3">
                    <label for="currentPassword" class="col-md-4 col-lg-3 col-form-label">Current Password</label>
                    <div class="col-md-8 col-lg-9">
                      <div class="input-group">
                        <input name="password" type="password" class="form-control" id="currentPassword" placeholder="Enter Current Password">
                        <span class="input-group-text" onclick="togglePassword('currentPassword', this)">
                          <i class="bi bi-eye"></i>
                        </span>
                      </div>
                    </div>
                  </div>

                  <!-- New Password -->
                  <div class="row mb-3">
                    <label for="newPassword" class="col-md-4 col-lg-3 col-form-label">New Password</label>
                    <div class="col-md-8 col-lg-9">
                      <div class="input-group">
                        <input name="newpassword" type="password" class="form-control" id="newPassword" placeholder="Enter New Password">
                        <span class="input-group-text" onclick="togglePassword('newPassword', this)">
                          <i class="bi bi-eye"></i>
                        </span>
                      </div>
                    </div>
                  </div>

                  <!-- Re-enter New Password -->
                  <div class="row mb-3">
                    <label for="renewPassword" class="col-md-4 col-lg-3 col-form-label">Re-enter New Password</label>
                    <div class="col-md-8 col-lg-9">
                      <div class="input-group">
                        <input name="renewpassword" type="password" class="form-control" id="renewPassword" placeholder="Re-enter New Password">
                        <span class="input-group-text" onclick="togglePassword('renewPassword', this)">
                          <i class="bi bi-eye"></i>
                        </span>
                      </div>
                    </div>
                  </div>

                  <!-- Submit Button -->
                  <div class="text-center">
                    <button type="submit" name="changePass" class="btn btn-primary">Change Password</button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
       </div>
      </div>
    </div>
  </section>
</main>
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

<script>
function previewImage(event) {
  const reader = new FileReader();
  reader.onload = function () {
    const output = document.getElementById('profileImagePreview');
    if (output.tagName === 'IMG') {
      output.src = reader.result;
    } else {
      output.outerHTML = `<img src="${reader.result}" class="img-fluid mb-3 rounded-circle" style="max-width: 150px;" id="profileImagePreview">`;
    }
  };
  reader.readAsDataURL(event.target.files[0]);
}

function removeProfileImage() {
  document.getElementById('removeImageFlag').value = '1';
  const preview = document.getElementById('profileImagePreview');
  if (preview) preview.style.display = 'none';
}
</script>






<footer id="footer" class="footer">
    <div class="copyright">
        &copy; Copyright <strong><span>FilSha</span></strong>. All Rights Reserved
    </div>
    <div class="credits">
       
    </div>
</footer>

<a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>


<script src="/elderlycare/assets/js/main.js"></script>
<script src="/elderlycare/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>


</body>

</html>
