
<?php

include 'conn.php';
session_start();
if (!isset($_SESSION['admin_id'])) {

    header("Location: /elderlycare/index.php");
    exit();
}

$admin_id = $_SESSION['admin_id'];

header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");


$notif_sql = "SELECT id, message, is_read, type, reference_id, created_at 
              FROM admin_notifications 
              WHERE type != 'medicine' AND user_type = 'caregiver'
              ORDER BY created_at DESC 
              LIMIT 7";

$notif_result = mysqli_query($conn, $notif_sql);
$notifications = mysqli_fetch_all($notif_result, MYSQLI_ASSOC);

$unread_count = 0;
foreach ($notifications as $n) {
    if ($n['is_read'] == 0) $unread_count++;
}

if (isset($_POST['markAllRead'])) {
    $sql = "UPDATE admin_notifications 
            SET is_read = 1 
            WHERE user_type = 'caregiver'";
    mysqli_query($conn, $sql);

    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}

if (isset($_GET['notif_id'])) {
    $notif_id = intval($_GET['notif_id']);

    // Mark as read only if created by caregiver
    mysqli_query($conn, "UPDATE admin_notifications 
                         SET is_read = 1 
                         WHERE id = $notif_id AND user_type = 'caregiver'");

    $notif_info = mysqli_fetch_assoc(
        mysqli_query($conn, "SELECT type, reference_id 
                             FROM admin_notifications 
                             WHERE id = $notif_id AND user_type = 'caregiver'")
    );

    if ($notif_info) {
        if ($notif_info['type'] === 'new_caregiver') {
            header("Location: caregiver_account_request.php?id=" . $notif_info['reference_id']);
        } elseif ($notif_info['type'] === 'deleted_patient') {
            header("Location: managepatient.php");
        } else {
            header("Location: patients_request.php?id=" . $notif_info['reference_id']);
        }
    }
    exit();
}


$rooms = [];

$sql = "
  SELECT 
    r.id,
    r.room_number,
    r.room_price,
    r.status,
    c.full_name AS caregiver_name,
    CONCAT(p.first_name, ' ', IFNULL(p.middle_name, ''), ' ', p.last_name) AS patient_name,
    r.patient_id
  FROM rooms r
  LEFT JOIN caregivers_info c ON r.caregiver_id = c.caregiver_id
  LEFT JOIN patients p ON r.patient_id = p.id
  ORDER BY CAST(SUBSTRING(r.room_number, 6) AS UNSIGNED) ASC
";


$result = $conn->query($sql);

$rooms = [];
if ($result) {
    $rooms = $result->fetch_all(MYSQLI_ASSOC);
}


?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>ElderlyCare - Manage Rooms</title>

  <!-- Favicons -->
  <link href="/elderlycare/assets/img/logo.png" rel="icon">

  <!-- Google Fonts -->
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="/elderlycare/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="/elderlycare/assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="/elderlycare/assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="/elderlycare/assets/vendor/quill/quill.snow.css" rel="stylesheet">
  <link href="/elderlycare/assets/vendor/quill/quill.bubble.css" rel="stylesheet">
  <link href="/elderlycare/assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="/elderlycare/assets/vendor/simple-datatables/style.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="/elderlycare/assets/css/style.css" rel="stylesheet">

  <style>
    input.form-control, select.form-select {
      border: 2px solid hsl(211, 47%, 46%);
      border-radius: 5px;
    }
    input.form-control:focus, select.form-select:focus {
      border-color:hsl(211, 47%, 46%);
      box-shadow: 0 0 5px hsl(211, 47%, 46%);
    }
    .submit-button {
      color: #e9eceb;
      background-color:hsl(211, 47%, 46%);
      font-family: 'Times New Roman', Times, serif;
      font-size: 18px;
      border-radius: 10px;
      padding: 10px 15px;
      border:1px solid white;
      transition: background-color 0.3s ease, transform 0.2s ease;
    }
    .submit-button:hover {
      color:black;
      background-color:hsl(211, 35%, 59%);
      transform: translateY(-2px);
    }
    .row.mb-3 {
      font-family: 'Times New Roman', Times, serif;
      color:#11431b;
      font-weight: bold;
    }
  

  .notification-item.unread {
    background-color: #f0f8ff;
  }
  .notification-item.unread p {
    font-weight: bold;
  }
 
.dropdown-menu.notifications {
  max-height: 300px;     
  overflow-y: auto;
  padding-right: 0;     
}


.dropdown-menu.notifications::-webkit-scrollbar {
  width: 6px;
}
.dropdown-menu.notifications::-webkit-scrollbar-track {
  background: transparent;
}
.dropdown-menu.notifications::-webkit-scrollbar-thumb {
  background-color: rgba(0,0,0,0.2);
  border-radius: 3px;
}
.table{
      text-align: center;
  vertical-align: middle;
}
@media (max-width: 576px), (max-width: 780px) {
  .dropdown-menu.profile {
    position: fixed !important;
    top: 60px;
    left: 0 !important;
    right: 0 !important;
    border-radius: 0;
    z-index: 1050;
  }
}
.dropdown-menu.notifications {
  max-height: 400px;
  overflow-y: auto;
}

@media (max-width: 576px) {
  .dropdown-menu.notifications {
    position: fixed !important;
    top: 60px;
    left: 0 !important;
    right: 0 !important;
    width: 100vw !important;
    max-width: none !important;
    border-radius: 0;
    z-index: 1050;
  }
}

</style>
 
</head>

<body>

<header id="header" class="header fixed-top d-flex align-items-center">

  <div class="d-flex align-items-center justify-content-between">
    <a href="AdminDashboard.php" class="logo d-flex align-items-center">
      <img src="/elderlycare/assets/img/logo.png" alt="Logo">
      <span class="d-none d-lg-block">ElderlyCare</span>
    </a>
    <i class="bi bi-list toggle-sidebar-btn"></i>
  </div>

<nav class="header-nav ms-auto">
  <ul class="d-flex align-items-center">

  
 <!-- Notifications -->
<li class="nav-item dropdown">
  <a id="notificationBell" class="nav-link nav-icon" href="#" data-bs-toggle="dropdown">
    <i class="bi bi-bell"></i>
    <?php if ($unread_count > 0): ?>
      <span class="badge bg-primary badge-number"><?= $unread_count ?></span>
    <?php endif; ?>
  </a>

 <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow notifications"
    style="max-width: 350px; word-wrap: break-word;">
  <li class="dropdown-header">
    <span>
      You have <?= $unread_count ?> new notification<?= $unread_count !== 1 ? 's' : ''; ?>
    </span>
    <?php if ($unread_count > 0): ?>
      <div class="mt-1">
        <form method="POST" style="display:inline;">
          <button type="submit" name="markAllRead" class="btn" style="font-size: 13px; height: 35px;">
            Mark all as read
          </button>
        </form>
      </div>
    <?php endif; ?>
  </li>
  <li><hr class="dropdown-divider"></li>

  <?php foreach ($notifications as $notif):
    $url = "?notif_id=" . $notif['id'];
    $liClass = $notif['is_read'] == 0 ? 'notification-item unread' : 'notification-item';
  ?>
    <li class="<?= $liClass ?>">
      <a href="<?= $url ?>" class="d-flex align-items-start text-decoration-none">
        <i class="bi bi-info-circle text-info me-2"></i>
        <div>
          <p class="mb-1"><?= htmlspecialchars($notif['message']) ?></p>
          <small class="text-muted">
            <?= date("M d, Y h:i A", strtotime($notif['created_at'])) ?>
          </small>
        </div>
      </a>
    </li>
    <li><hr class="dropdown-divider"></li>
  <?php endforeach; ?>
</ul>

</li>
<!-- End Notifications -->

      <?php
  include('conn.php');

  $query = "SELECT fullname, position, admin_picture FROM admins WHERE id = 1";
  $stmt = $conn->prepare($query);
  $stmt->execute();
  $stmt->bind_result($fullname, $position, $adminPicture);
  $stmt->fetch();
  $stmt->close();
?>
<li class="nav-item dropdown pe-3">
  <a class="nav-link nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown">
    <?php if (!empty($adminPicture)): ?>
      <img src="uploads/admin/<?= htmlspecialchars($adminPicture) ?>"
           alt="Profile"
           class="rounded-circle"
           style="object-fit: cover; width: 40px; height: 40px;" />
    <?php else: ?>
      <div class="rounded-circle bg-secondary d-flex justify-content-center align-items-center"
           style="width: 40px; height: 40px;">
        <i class="bi bi-person text-white fs-5"></i>
      </div>
    <?php endif; ?>
    <span class="dropdown-toggle d-none d-md-inline-block text-truncate" style="max-width: 120px;">
      <?= htmlspecialchars($fullname) ?>
    </span>
  </a>

  <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow profile w-100" style="max-width: none; word-wrap: break-word;">
    <li class="dropdown-header">
      <h6><?= htmlspecialchars($fullname) ?></h6>
      <span><?= htmlspecialchars($position) ?></span>
    </li>

    <li><hr class="dropdown-divider"></li>

    <li>
      <a class="dropdown-item d-flex align-items-center" href="admin_profile.php">
        <i class="bi bi-person"></i>
        <span>My Profile</span>
      </a>
    </li>

    <li><hr class="dropdown-divider"></li>

    <li>
      <a class="dropdown-item d-flex align-items-center" href="/elderlycare/logout.php">
        <i class="bi bi-box-arrow-right"></i>
        <span>Sign Out</span>
      </a>
    </li>
  </ul>
</li>

  </nav>
</header>

<aside id="admin-sidebar" class="sidebar">
  <h3 class="text-white text-center space-below">Admin Dashboard</h3>
  <ul class="sidebar-nav" id="admin-sidebar-nav">
    <li class="nav-item"><a class="nav-link collapsed" href="AdminDashboard.php"><i class="bi bi-house-door"></i><span>Dashboard</span></a></li>
    <li class="nav-item"><a class="nav-link active" href="manage_rooms.php"><i class="bi bi-door-open"></i><span>Manage Patient Rooms</span></a></li>
    <li class="nav-item"><a class="nav-link collapsed" href="caregiver_account_request.php"><i class="bi bi-check-circle"></i><span>Caregiver Approvals</span></a></li>
    <li class="nav-item"><a class="nav-link collapsed" href="patients_request.php"><i class="bi bi-person-check"></i><span>Patient's Approvals</span></a></li>
    <li class="nav-item"><a class="nav-link collapsed" href="manage_patients.php"><i class="bi bi-file-earmark-person"></i><span>Manage Patients</span></a></li>
    <li class="nav-item"><a class="nav-link collapsed" href="manage_caregivers.php"><i class="bi bi-person-bounding-box"></i><span>Manage Caregivers</span></a></li>
    <li class="nav-item"><a class="nav-link collapsed" href="view_reports.php"><i class="bi bi-file-earmark-text"></i><span>View Reports</span></a></li>
  </ul>
</aside>

<main id="main" class="main">
<?php if (isset($_SESSION['message'])): ?>
<div id="alert-box" class="alert alert-success text-center" 
     style="max-width: 500px; margin: 20px auto; transition: opacity 0.5s, transform 0.5s;" 
     role="alert">
    <?= $_SESSION['message']; ?>
</div>
<?php unset($_SESSION['message']); endif; ?>

<script>
setTimeout(() => {
    const alertBox = document.getElementById('alert-box');
    if (alertBox) {
        alertBox.style.opacity = '0';    
        alertBox.style.transform = 'translateY(-20px)'; 
        setTimeout(() => alertBox.remove(), 300); 
    }
}, 5000); 
</script>

<div class="pagetitle">
  <h2>Manage Rooms - ElderlyCare</h2>
  <nav>
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="admin_dashboard.php">Home</a></li>
      <li class="breadcrumb-item active">Manage Rooms</li>
    </ol>
  </nav>
</div>

<section class="section">
  <div class="row">
    <div class="col-lg-12">

      <div class="d-flex justify-content-between align-items-center flex-wrap mb-3">
  <h5 class="card-title text-center mb-0">Rooms List</h5>
  <form action="process.php" method="POST">
    <button type="submit" name="submitRoom" class="btn btn-sm ">Add Room</button>
  </form>
</div>

<!-- ✅ Responsive wrapper added -->
<div class="table-responsive">
  <table class="table table-bordered table-hover">
    <thead>
      <tr>
        <th>#</th>
        <th>Room Number</th>
        <th>Caregiver</th>
        <th>Patient Name</th>
        <th>Room Price (₱)</th>
        <th>Status</th>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody>
      <?php if (count($rooms) > 0): ?>
        <?php foreach ($rooms as $index => $room): ?>
          <tr>
            <td><?= $index + 1 ?></td>
            <td><?= htmlspecialchars($room['room_number']) ?></td>
            <td><?= htmlspecialchars($room['caregiver_name'] ?? '-') ?></td>
            <td><?= htmlspecialchars($room['patient_name'] ?? '-') ?></td>
            <td><?= isset($room['room_price']) ? number_format($room['room_price'], 2) : '5000.00' ?></td>
            <td><?= htmlspecialchars($room['status']) ?></td>
            <td>
              <!-- ✅ Mobile-friendly button wrapper -->
              <div class="d-flex flex-column flex-sm-row gap-1">
                <button type="button" class="btn btn-sm "
                        data-bs-toggle="modal"
                        data-bs-target="#editRoomModal<?= $room['id'] ?>">
                  Edit
                </button>

                <button type="button" class="btn btn-sm"
                        data-bs-toggle="modal" 
                        data-bs-target="#deleteRoomModal<?= $room['id'] ?>">
                  Delete
                </button>
              </div>

              <!-- Delete Confirmation Modal -->
              <div class="modal fade" id="deleteRoomModal<?= $room['id'] ?>" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title">Confirm Deletion</h5>
                      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                      Are you sure you want to delete <?= htmlspecialchars($room['room_number']); ?>?
                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-sm" data-bs-dismiss="modal">Cancel</button>
                      <form method="POST" action="process.php">
                        <input type="hidden" name="deleteRoom" value="<?= $room['id']; ?>">
                        <button type="submit" class="btn btn-sm ">Delete</button>
                      </form>
                    </div>
                  </div>
                </div>
              </div>

            </td>
          </tr>
        <?php endforeach; ?>
      <?php else: ?>
        <tr><td colspan="7" class="text-center">No rooms found.</td></tr>
      <?php endif; ?>
    </tbody>
  </table>
</div>

      <!-- ✅ End responsive wrapper -->

      <!-- Edit Room Modals -->
      <?php foreach ($rooms as $room): ?>
      <div class="modal fade" id="editRoomModal<?= $room['id'] ?>" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
          <form action="process.php" method="POST" class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">Edit Room <?= htmlspecialchars($room['room_number']) ?></h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
              <input type="hidden" name="id" value="<?= $room['id'] ?>">

              <div class="mb-3">
                <label class="form-label">Room Price (₱)</label>
                <input type="number" step="0.01" name="room_price" class="form-control" 
                       value="<?= htmlspecialchars($room['room_price']) ?>" required>
              </div>

              <div class="mb-3">
                <label class="form-label">Room Status</label>
                <?php if ($room['status'] === 'Occupied'): ?>
                  <input type="text" class="form-control" value="Occupied" disabled>
                  <input type="hidden" name="status" value="Occupied">
                <?php else: ?>
                  <select name="status" class="form-control">
                    <option value="Available" <?= $room['status'] === 'Available' ? 'selected' : '' ?>>Available</option>
                    <option value="Under Maintenance" <?= $room['status'] === 'Under Maintenance' ? 'selected' : '' ?>>Under Maintenance</option>
                  </select>
                <?php endif; ?>
              </div>

            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancel</button>
              <button type="submit" name="updateRoom" class="btn btn-primary btn-sm">Save changes</button>
            </div>
          </form>
        </div>
      </div>
      <?php endforeach; ?>

    </div>
  </div>
</section>

<script>
  document.getElementById('toggleAddRoomBtn')?.addEventListener('click', function() {
    const form = document.getElementById('addRoomForm');
    if (form) {
      form.style.display = (form.style.display === 'none' || form.style.display === '') ? 'block' : 'none';
    }
  });
</script>

</main>


<footer id="footer" class="footer">
  <div class="copyright">
    &copy; Copyright <strong><span>ElderlyCare</span></strong>. All Rights Reserved
  </div>
</footer>

<a href="#" class="back-to-top d-flex align-items-center justify-content-center">
  <i class="bi bi-arrow-up-short"></i>
</a>

<script src="/elderlycare/assets/js/main.js"></script>
<script src="/elderlycare/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>

