<?php 
session_start();
include 'conn.php';


if (isset($_POST['login'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];  

    // Check if the email exists
    $query = "SELECT id, password, fullname FROM admins WHERE email = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "s", $email);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_bind_result($stmt, $admin_id, $stored_password, $full_name);
    
    if (mysqli_stmt_fetch($stmt)) {
        mysqli_stmt_close($stmt);
        // Email exists, check password
        if ($password === $stored_password) {
            $_SESSION['admin_id'] = $admin_id;
            $_SESSION['message'] = "Logged in successfully! Welcome back, Admin " . $full_name . "!";
            header("Location: /elderlycare/templates/admin/AdminDashboard.php");
            exit;
        } else {
            $_SESSION['message'] = "Incorrect password. Please try again!";
            header("Location: /elderlycare/templates/admin/adminLogin.php");
            exit;
        }
    } else {
        mysqli_stmt_close($stmt);
        // Email not found
        $_SESSION['message'] = "No account found with that email.";
        header("Location: /elderlycare/templates/admin/adminLogin.php");
        exit;
    }
}




if (isset($_POST['addAdmin'])) {
  
    $adminId = isset($_POST['admin_id']) ? (int)$_POST['admin_id'] : 0;
    $fullname = mysqli_real_escape_string($conn, $_POST['fullName']);
    $position = mysqli_real_escape_string($conn, $_POST['position']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    $address = mysqli_real_escape_string($conn, $_POST['address']);
    $email = mysqli_real_escape_string($conn, $_POST['email']); 


    $imageName = ''; 
    if (!empty($_FILES['admin_picture']['name'])) {
        $imageName = time() . "_" . basename($_FILES['admin_picture']['name']);
        $targetDir = "uploads/admin/"; 
        $targetFile = $targetDir . $imageName;

       
        if ($_FILES['admin_picture']['error'] === UPLOAD_ERR_OK) {
           
            if (!is_dir($targetDir)) {
                mkdir($targetDir, 0777, true);
            }

         
            if (!move_uploaded_file($_FILES['admin_picture']['tmp_name'], $targetFile)) {
                echo "Error: Could not move the uploaded file.";
                exit;
            }
        } else {
            echo "File upload error: " . $_FILES['admin_picture']['error'];
            exit;
        }
    } else {
       
        $result = mysqli_query($conn, "SELECT admin_picture FROM admins WHERE id = $adminId LIMIT 1");
        if ($result) {
            $row = mysqli_fetch_assoc($result);
            $imageName = $row ? $row['admin_picture'] : ''; 
        }
    }


    $sql = "UPDATE admins 
            SET admin_picture = ?, 
                fullname = ?, 
                position = ?, 
                phone_num = ?, 
                email = ?,
                address = ? 
            WHERE id = ?";

  
    $stmt = mysqli_prepare($conn, $sql);
    if ($stmt) {
        mysqli_stmt_bind_param($stmt, 'ssssssi', $imageName, $fullname, $position, $phone, $email, $address, $adminId); 
        if (mysqli_stmt_execute($stmt)) {
            header("Location: admin_profile.php?updated=1");
            exit();
        } else {
            echo "Error updating database: " . mysqli_error($conn);
        }

        mysqli_stmt_close($stmt); 
    } else {
        echo "Error preparing statement: " . mysqli_error($conn);
    }
}






if (isset($_POST['changePass']) && isset($_SESSION['admin_id'])) {
    $admin_id = $_SESSION['admin_id'];

    $currentPassword = $_POST['password'];
    $newPassword = $_POST['newpassword'];
    $renewPassword = $_POST['renewpassword'];

    if ($newPassword !== $renewPassword) {
        echo "<script>alert('New passwords do not match.'); history.back();</script>";
        exit;
    }

    $stmt = $conn->prepare("SELECT password FROM admins WHERE id = ?");
    $stmt->bind_param("i", $admin_id);
    $stmt->execute();
    $stmt->bind_result($dbPassword);
    $stmt->fetch();
    $stmt->close();

    $validPassword = password_verify($currentPassword, $dbPassword) || $currentPassword === $dbPassword;

    if ($validPassword) {
       
        $hashedNewPassword = password_hash($newPassword, PASSWORD_DEFAULT);

        $update = $conn->prepare("UPDATE admins SET password = ? WHERE id = ?");
        $update->bind_param("si", $hashedNewPassword, $admin_id);

        if ($update->execute()) {
            echo "<script>alert('Password updated successfully.'); window.location.href = 'admin_profile.php';</script>";
        } else {
            echo "<script>alert('Error updating password.'); history.back();</script>";
        }

        $update->close();
    } else {
        echo "<script>alert('Current password is incorrect.'); history.back();</script>";
    }

    $conn->close();
}



if (isset($_POST['action'], $_POST['request_id'])) {
    $action = $_POST['action'];
    $request_id = intval($_POST['request_id']);

    if ($action === 'approve' || $action === 'reject') {
        $status = ($action === 'approve') ? 'Approved' : 'Rejected';

        $stmt = $conn->prepare("UPDATE caregivers SET status = ? WHERE id = ?");
        if ($stmt) {
            $stmt->bind_param("si", $status, $request_id);
            if ($stmt->execute()) {
                echo "<script>
                        alert('Caregiver successfully {$status}!');
                        window.location.href = 'manage_caregivers.php';
                      </script>";
            } else {
                echo "<script>
                        alert('Failed to update caregiver: {$stmt->error}');
                        window.location.href = 'manage_caregivers.php';
                      </script>";
            }
            $stmt->close();
        } else {
            echo "<script>
                    alert('Statement preparation failed: {$conn->error}');
                    window.location.href = 'manage_caregivers.php';
                  </script>";
        }
    } else {
        echo "<script>
                alert('Invalid action provided!');
                window.location.href = 'manage_caregivers.php';
              </script>";
    }
}


//to remove the caregiver 
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action']) && $_POST['action'] === 'delete_caregiver' && isset($_POST['id'])) {
        $caregiver_id = $_POST['id']; 

        // 1. Delete all patients under this caregiver
        $deletePatientsSQL = "DELETE FROM patients WHERE caregiver_id = ?";
        $stmtPatients = $conn->prepare($deletePatientsSQL);
        if ($stmtPatients) {
            $stmtPatients->bind_param("i", $caregiver_id);
            $stmtPatients->execute();
            $stmtPatients->close();
        }

        // 2. Delete the caregiver
        $deleteCaregiverSQL = "DELETE FROM caregivers WHERE id = ?";
        $stmtCaregiver = $conn->prepare($deleteCaregiverSQL);
        if ($stmtCaregiver) {
            $stmtCaregiver->bind_param("i", $caregiver_id);
            if ($stmtCaregiver->execute()) {
                $stmtCaregiver->close();
                header("Location: manage_caregivers.php?delete=success");
                exit();
            } else {
                $stmtCaregiver->close();
                header("Location: manage_caregivers.php?delete=error");
                exit();
            }
        } else {
            echo "Error preparing the SQL statement.";
            exit();
        }
    }
}






function getCaregiverIdByPatientId($patientId) {
    global $conn;
    $query = "SELECT caregiver_id FROM patients WHERE id = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, 'i', $patientId);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_bind_result($stmt, $caregiverId);
    mysqli_stmt_fetch($stmt);
    mysqli_stmt_close($stmt);
    return $caregiverId;
}

function getPatientNameById($patientId) {
    global $conn;
    $query = "SELECT first_name, middle_name, last_name FROM patients WHERE id = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, 'i', $patientId);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_bind_result($stmt, $firstName, $middleName, $lastName);
    mysqli_stmt_fetch($stmt);
    mysqli_stmt_close($stmt);

   
    $fullName = $firstName;
    if (!empty($middleName)) {
        $fullName .= ' ' . $middleName;
    }
    $fullName .= ' ' . $lastName;

    return $fullName;
}

require __DIR__ . '/../../vendor/autoload.php';
$dotenv = Dotenv\Dotenv::createImmutable(__DIR__ . '/../../');
$dotenv->load();

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];

    if ($action === 'approve' || $action === 'reject') {
        $request_patient = isset($_POST['request_patient']) ? intval($_POST['request_patient']) : 0;

        if ($request_patient > 0) {
            $status = ($action === 'approve') ? 'approved' : 'rejected';

            
            $stmt = mysqli_prepare($conn, "UPDATE patients SET status = ? WHERE id = ?");
            if ($stmt) {
                mysqli_stmt_bind_param($stmt, 'si', $status, $request_patient);
                if (mysqli_stmt_execute($stmt)) {

                    if ($action === 'approve') {
                        
                        $patientInfoQuery = "SELECT room_id, caregiver_id FROM patients WHERE id = ?";
                        $patientInfoStmt = mysqli_prepare($conn, $patientInfoQuery);
                        mysqli_stmt_bind_param($patientInfoStmt, 'i', $request_patient);
                        mysqli_stmt_execute($patientInfoStmt);
                        $resultInfo = mysqli_stmt_get_result($patientInfoStmt);
                        $patientInfo = mysqli_fetch_assoc($resultInfo);
                        mysqli_stmt_close($patientInfoStmt);

                        if ($patientInfo && !empty($patientInfo['room_id'])) {
                            $room_id = $patientInfo['room_id'];
                            $caregiver_id = $patientInfo['caregiver_id'];

                            $patientName = getPatientNameById($request_patient);

                            $cg_q = mysqli_query($conn, "SELECT full_name FROM caregivers_info WHERE caregiver_id = $caregiver_id");
                            $cg_data = mysqli_fetch_assoc($cg_q);
                            $caregiver_name = $cg_data['full_name'] ?? '';

                            $updateRoomSql = "UPDATE rooms SET status = 'Occupied', patient_id = ?, patient_name = ?, caregiver_id = ?, caregivers_name = ? WHERE id = ?";
                            $updateRoomStmt = mysqli_prepare($conn, $updateRoomSql);
                            if (!$updateRoomStmt) {
                                error_log("Failed to prepare room update query: " . mysqli_error($conn));
                            } else {
                                mysqli_stmt_bind_param($updateRoomStmt, 'isisi', $request_patient, $patientName, $caregiver_id, $caregiver_name, $room_id);
                                if (!mysqli_stmt_execute($updateRoomStmt)) {
                                    error_log("Failed to execute room update: " . mysqli_stmt_error($updateRoomStmt));
                                }
                                mysqli_stmt_close($updateRoomStmt);
                            }
                        }
                    }

                    $caregiverId = getCaregiverIdByPatientId($request_patient);
                    $patientName = getPatientNameById($request_patient);
                    $message = ($action === 'approve')
                        ? "Your request to add patient {$patientName} has been approved."
                        : "Your request to add patient {$patientName} has been rejected.";

                    $notifQuery = "INSERT INTO admin_notifications (type, reference_id, message, is_read, created_at, user_type, user_id)
                                   VALUES ('new_patient', ?, ?, 0, NOW(), 'admin', ?)";
                    $notifStmt = mysqli_prepare($conn, $notifQuery);
                    mysqli_stmt_bind_param($notifStmt, 'isi', $request_patient, $message, $caregiverId);
                    mysqli_stmt_execute($notifStmt);
                    mysqli_stmt_close($notifStmt);

                    $infoQuery = "SELECT emergency_contact_name, email_address FROM patients WHERE id = ?";
                    $infoStmt = mysqli_prepare($conn, $infoQuery);
                    mysqli_stmt_bind_param($infoStmt, 'i', $request_patient);
                    mysqli_stmt_execute($infoStmt);
                    $result = mysqli_stmt_get_result($infoStmt);
                    $patientData = mysqli_fetch_assoc($result);
                    mysqli_stmt_close($infoStmt);

                    if ($patientData) {
                        $relative_name = $patientData['emergency_contact_name'];
                        $relative_email = $patientData['email_address'];

                        if (empty($relative_email)) {
                            error_log("⚠️ Relative email is empty for patient ID: $request_patient");
                            echo "<script>alert('Error: Relative email is empty.');</script>";
                        } else {
                            $mail = new PHPMailer(true);
                            try {
                                $mail->isSMTP();
                                $mail->Host = 'smtp.gmail.com';
                                $mail->SMTPAuth = true;
                                $mail->Username = $_ENV['EMAIL_USER'];
                                $mail->Password = $_ENV['EMAIL_PASS'];
                                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                                $mail->Port = 587;

                                $mail->setFrom($_ENV['EMAIL_USER'], 'ElderlyCare System');
                                $mail->addAddress($relative_email, $relative_name);
                                $mail->isHTML(true);

                                if ($action === 'approve') {
                                    $base_username = preg_replace('/[^a-z0-9]/', '', strtolower($relative_name));
                                    $generated_username = $base_username . rand(100, 999);
                                    $generated_password = bin2hex(random_bytes(4));
                                    $hashed_password = password_hash($generated_password, PASSWORD_DEFAULT);

                                    $insertRel = mysqli_prepare($conn, "INSERT INTO relatives (username, password, name, email, patient_id, caregiver_id)
                                                                        VALUES (?, ?, ?, ?, ?, ?)");
                                    mysqli_stmt_bind_param($insertRel, 'ssssii', $generated_username, $hashed_password, $relative_name, $relative_email, $request_patient, $caregiverId);
                                    mysqli_stmt_execute($insertRel);
                                    mysqli_stmt_close($insertRel);

                                    $mail->Subject = 'Account Created for Patient Access';
                                    $mail->Body = "
                                        <p>Dear $relative_name,</p>
                                        <p>Your patient request has been approved. Here are your login credentials:</p>
                                        <ul>
                                            <li><strong>Username:</strong> $generated_username</li>
                                            <li><strong>Password:</strong> $generated_password</li>
                                        </ul>
                                        <p>Please log in and change your password immediately.</p>
                                        <p>— ElderlyCare System</p>
                                    ";
                                } else {
                                    $mail->Subject = 'Patient Request Rejected';
                                    $mail->Body = "
                                        <p>Dear $relative_name,</p>
                                        <p>We're sorry to inform you that the request to add your patient to the ElderlyCare system has been <strong>rejected</strong>.</p>
                                        <p>If you believe this was a mistake, please contact your caregiver or try resubmitting the request with complete details.</p>
                                        <p>— ElderlyCare System</p>
                                    ";
                                }

                                $mail->send();
                                error_log("✅ Email successfully sent to: $relative_email");

                                if ($action === 'approve') {
                                    echo "<script>
                                        alert('Patient successfully approved and email sent to $relative_email.');
                                        window.location.href = 'manage_patients.php';
                                    </script>";
                                } else {
                                    echo "<script>
                                        alert('Patient request has been rejected and email sent to $relative_email.');
                                        window.location.href = 'manage_patients.php';
                                    </script>";
                                }
                                exit;

                            } catch (Exception $e) {
                                error_log("❌ Mailer Error: {$mail->ErrorInfo}");
                                echo "<script>alert('Mailer Error: " . addslashes($mail->ErrorInfo) . "');</script>";
                            }
                        }
                    } else {
                        error_log("❌ No patient data found for ID: $request_patient");
                        echo "<script>alert('Error: No patient data found.');</script>";
                    }

                } else {
                    echo "Error executing patient status update: " . mysqli_error($conn);
                }
                mysqli_stmt_close($stmt);
            } else {
                echo "Error preparing patient status update query: " . mysqli_error($conn);
            }
        }
    }
}

if (isset($_POST['submitRoom'])) {
    // Fetch all room numbers in ascending order
    $result = $conn->query("SELECT room_number FROM rooms ORDER BY id ASC");

    $usedNumbers = [];
    while ($row = $result->fetch_assoc()) {
        $usedNumbers[] = (int) str_replace('Room ', '', $row['room_number']);
    }

    // Find the smallest available number
    $newNum = 1;
    while (in_array($newNum, $usedNumbers)) {
        $newNum++;
    }

    $room_number = "Room " . $newNum;

    $caregiver_id = $_SESSION['user_id'];
    $patient_name = '';
    $room_price = 5000.00;
    $status = 'Available';

    $query = "INSERT INTO rooms (room_number, caregiver_id, patient_name, room_price, status) VALUES (?, ?, ?, ?, ?)";
    $stmt = mysqli_prepare($conn, $query);
    if (!$stmt) {
        $_SESSION['message'] = 'Prepare failed: ' . mysqli_error($conn);
        header("Location: manage_rooms.php");
        exit;
    }

    mysqli_stmt_bind_param($stmt, 'sisss', $room_number, $caregiver_id, $patient_name, $room_price, $status);

    if (mysqli_stmt_execute($stmt)) {
        $_SESSION['message'] = 'New room added successfully!';
        header("Location: manage_rooms.php");
        exit;
    } else {
        $_SESSION['message'] = 'Failed to add room.';
        header("Location: manage_rooms.php");
        exit;
    }
}

if (isset($_POST['deleteRoom'])) {
    $roomId = $_POST['deleteRoom'];

    $check = $conn->prepare("SELECT status FROM rooms WHERE id = ?");
    $check->bind_param("i", $roomId);
    $check->execute();
    $result = $check->get_result();
    $room = $result->fetch_assoc();

    if ($room && $room['status'] === 'Available') {
        $stmt = $conn->prepare("DELETE FROM rooms WHERE id = ?");
        $stmt->bind_param("i", $roomId);
        $stmt->execute();

        $_SESSION['message'] = "Room deleted successfully.";
        header("Location: manage_rooms.php");
        exit;
    } else {
        // Room cannot be deleted if Occupied or Under Maintenance
        $_SESSION['message'] = "Cannot delete room. It is currently {$room['status']}.";
        header("Location: manage_rooms.php");
        exit;
    }
}

if (isset($_POST['updateRoom'])) {
    $room_id = $_POST['id'];
    $room_price = $_POST['room_price'];
    $status = $_POST['status'] ?? null;

    if (!is_numeric($room_price) || $room_price < 0) {
        $_SESSION['message'] = "Invalid room price.";
        header("Location: manage_rooms.php");
        exit;
    }

    // Fetch current room number for the message
    $roomQuery = $conn->prepare("SELECT room_number FROM rooms WHERE id = ?");
    $roomQuery->bind_param("i", $room_id);
    $roomQuery->execute();
    $roomResult = $roomQuery->get_result();
    $room = $roomResult->fetch_assoc();
    $room_number = $room['room_number'] ?? 'Room';

    if ($status === 'Occupied') {
        $query = "UPDATE rooms SET room_price = ? WHERE id = ?";
        $stmt = mysqli_prepare($conn, $query);
        mysqli_stmt_bind_param($stmt, "di", $room_price, $room_id);
    } else {
        $query = "UPDATE rooms SET room_price = ?, status = ? WHERE id = ?";
        $stmt = mysqli_prepare($conn, $query);
        mysqli_stmt_bind_param($stmt, "dsi", $room_price, $status, $room_id);
    }

    if ($stmt->execute()) {
        mysqli_stmt_close($stmt);

        $message = "Room {$room_number} updated successfully. Price: ₱" . number_format($room_price, 2);
    if ($status === 'Available' || $status === 'Under Maintenance' || $status === 'Occupied') {
        $message .= "<br>Status: {$status}.";
    }


        $_SESSION['message'] = $message;
        header("Location: manage_rooms.php");
        exit;
    } else {
        mysqli_stmt_close($stmt);
        $_SESSION['message'] = "Failed to update room.";
        header("Location: manage_rooms.php");
        exit;
    }
}









mysqli_close($conn);

?>