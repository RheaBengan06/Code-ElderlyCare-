<?php
session_start();
include 'conn.php';


if (!isset($_SESSION['admin_id'])) {
    echo "<script>
        alert('Please log in first');
        window.location.href = '/elderlycare/index.php';
    </script>";
    exit();
}

header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

$notif_sql = "SELECT id, message, is_read, type, reference_id, created_at 
              FROM admin_notifications 
              WHERE type != 'medicine' AND user_type = 'caregiver'
              ORDER BY created_at DESC 
              LIMIT 7";

$notif_result = mysqli_query($conn, $notif_sql);
$notifications = mysqli_fetch_all($notif_result, MYSQLI_ASSOC);

$unread_count = 0;
foreach ($notifications as $n) {
    if ($n['is_read'] == 0) $unread_count++;
}

if (isset($_POST['markAllRead'])) {
    $sql = "UPDATE admin_notifications 
            SET is_read = 1 
            WHERE user_type = 'caregiver'";
    mysqli_query($conn, $sql);

    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}

if (isset($_GET['notif_id'])) {
    $notif_id = intval($_GET['notif_id']);

    // Mark as read only if created by caregiver
    mysqli_query($conn, "UPDATE admin_notifications 
                         SET is_read = 1 
                         WHERE id = $notif_id AND user_type = 'caregiver'");

    $notif_info = mysqli_fetch_assoc(
        mysqli_query($conn, "SELECT type, reference_id 
                             FROM admin_notifications 
                             WHERE id = $notif_id AND user_type = 'caregiver'")
    );

    if ($notif_info) {
        if ($notif_info['type'] === 'new_caregiver') {
            header("Location: caregiver_account_request.php?id=" . $notif_info['reference_id']);
        } elseif ($notif_info['type'] === 'deleted_patient') {
            header("Location: managepatient.php");
        } else {
            header("Location: patients_request.php?id=" . $notif_info['reference_id']);
        }
    }
    exit();
}

$activity_sql = "
    SELECT an.message, an.created_at, ci.full_name
    FROM admin_notifications an
    LEFT JOIN caregivers_info ci ON an.user_id = ci.caregiver_id
    WHERE an.type != 'medicine'
    ORDER BY an.created_at DESC
    LIMIT 10
";
$activity_result = mysqli_query($conn, $activity_sql);
if (!$activity_result) {
    die("Activity query error: " . mysqli_error($conn));
}

$medicine_activity_sql = "
    SELECT pm.medicine_name, CONCAT(p.first_name, ' ', p.last_name) AS patient_name, pm.time_to_take AS administered_at
    FROM patient_medicines pm
    JOIN patients p ON pm.patient_id = p.id
    ORDER BY pm.time_to_take DESC
    LIMIT 10
";
$medicine_activity_result = mysqli_query($conn, $medicine_activity_sql);
if (!$medicine_activity_result) {
    die("Medicine activity query error: " . mysqli_error($conn));
}

$sql = "
  SELECT 
  c.id AS caregiver_id, 
  ci.full_name AS caregiver_name,
  p.id AS patient_id,
  p.first_name,
  p.last_name
FROM caregivers c
JOIN caregivers_info ci ON c.id = ci.caregiver_id
LEFT JOIN patients p ON p.caregiver_id = c.id
WHERE p.status = 'approved'
ORDER BY ci.full_name, p.first_name, p.last_name;

";

$result = mysqli_query($conn, $sql);

$caregivers = [];

while ($row = mysqli_fetch_assoc($result)) {
    $cid = $row['caregiver_id'];
    if (!isset($caregivers[$cid])) {
        $caregivers[$cid] = [
            'name' => $row['caregiver_name'],
            'patients' => []
        ];
    }
    if ($row['patient_id']) {
        $caregivers[$cid]['patients'][] = $row['first_name'] . ' ' . $row['last_name'];
    }
}


?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
 
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <title>ElderlyCare - User's Profile</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

 <!-- Favicons -->
 <link href="/elderlycare/assets/img/logo.png" rel="icon">

<!-- Google Fonts -->
<link href="https://fonts.gstatic.com" rel="preconnect">
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

<!-- Vendor CSS Files -->
<link href="/elderlycare/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/quill/quill.snow.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/quill/quill.bubble.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/remixicon/remixicon.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/simple-datatables/style.css" rel="stylesheet">

<!-- Template Main CSS File -->
<link href="/elderlycare/assets/css/style.css" rel="stylesheet">

  

</head>
<style>

input.form-control, select.form-select {
  border: 2px solid hsl(211, 47%, 46%);
  border-radius: 5px;
}

input.form-control:focus, select.form-select:focus {
  border-color:hsl(211, 47%, 46%);
  box-shadow: 0 0 5px hsl(211, 47%, 46%);
}
.submit-button{
  color: #e9eceb;
  background-color:hsl(211, 47%, 46%);
  font-family: 'Times New Roman', Times, serif;
  font-size: 18px;
  border-radius: 10px;
  padding: 10px 15px;
  border:1px solid white;
  transition: background-color 0.3s ease, transform 0.2s ease;

}
.submit-button:hover{
  color:black;
  background-color:hsl(211, 35%, 59%);
  transform: translateY(-2px); 
}
.row.mb-3{
  font-family: 'Times New Roman', Times, serif;
  color:#11431b;
  font-weight: bold;
}
  
  .notification-item.unread {
    background-color: #f0f8ff;
  }
  .notification-item.unread p {
    font-weight: bold;
  }
 
.dropdown-menu.notifications {
  max-height: 300px;      
  overflow-y: auto;
  padding-right: 0;       
}


.dropdown-menu.notifications::-webkit-scrollbar {
  width: 6px;
}
.dropdown-menu.notifications::-webkit-scrollbar-track {
  background: transparent;
}
.dropdown-menu.notifications::-webkit-scrollbar-thumb {
  background-color: rgba(0,0,0,0.2);
  border-radius: 3px;
}
@media (max-width: 576px), (max-width: 780px) {
  .dropdown-menu.profile {
    position: fixed !important;
    top: 60px;
    left: 0 !important;
    right: 0 !important;
    border-radius: 0;
    z-index: 1050;
  }
}
.dropdown-menu.notifications {
  max-height: 400px;
  overflow-y: auto;
}

@media (max-width: 576px) {
  .dropdown-menu.notifications {
    position: fixed !important;
    top: 60px;
    left: 0 !important;
    right: 0 !important;
    width: 100vw !important;
    max-width: none !important;
    border-radius: 0;
    z-index: 1050;
  }
}
</style>


<body>

<header id="header" class="header fixed-top d-flex align-items-center">

<div class="d-flex align-items-center justify-content-between">
  <a href="AdminDashboard.php" class="logo d-flex align-items-center">
  <img src="/elderlycare/assets/img/logo.png" alt="Logo">
    <span class="d-none d-lg-block">ElderlyCare</span>
  </a>
  <i class="bi bi-list toggle-sidebar-btn"></i>
</div>

<nav class="header-nav ms-auto">
  <ul class="d-flex align-items-center">

  
 <!-- Notifications -->
<li class="nav-item dropdown">
  <a id="notificationBell" class="nav-link nav-icon" href="#" data-bs-toggle="dropdown">
    <i class="bi bi-bell"></i>
    <?php if ($unread_count > 0): ?>
      <span class="badge bg-primary badge-number"><?= $unread_count ?></span>
    <?php endif; ?>
  </a>

 <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow notifications"
    style="max-width: 350px; word-wrap: break-word;">
  <li class="dropdown-header">
    <span>
      You have <?= $unread_count ?> new notification<?= $unread_count !== 1 ? 's' : ''; ?>
    </span>
    <?php if ($unread_count > 0): ?>
      <div class="mt-1">
        <form method="POST" style="display:inline;">
          <button type="submit" name="markAllRead" class="btn" style="font-size: 13px; height: 35px;">
            Mark all as read
          </button>
        </form>
      </div>
    <?php endif; ?>
  </li>
  <li><hr class="dropdown-divider"></li>

  <?php foreach ($notifications as $notif):
    $url = "?notif_id=" . $notif['id'];
    $liClass = $notif['is_read'] == 0 ? 'notification-item unread' : 'notification-item';
  ?>
    <li class="<?= $liClass ?>">
      <a href="<?= $url ?>" class="d-flex align-items-start text-decoration-none">
        <i class="bi bi-info-circle text-info me-2"></i>
        <div>
          <p class="mb-1"><?= htmlspecialchars($notif['message']) ?></p>
          <small class="text-muted">
            <?= date("M d, Y h:i A", strtotime($notif['created_at'])) ?>
          </small>
        </div>
      </a>
    </li>
    <li><hr class="dropdown-divider"></li>
  <?php endforeach; ?>
</ul>

</li>
<!-- End Notifications -->

      <?php
  include('conn.php');

  $query = "SELECT fullname, position, admin_picture FROM admins WHERE id = 1";
  $stmt = $conn->prepare($query);
  $stmt->execute();
  $stmt->bind_result($fullname, $position, $adminPicture);
  $stmt->fetch();
  $stmt->close();
?>
<li class="nav-item dropdown pe-3">
  <a class="nav-link nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown">
    <?php if (!empty($adminPicture)): ?>
      <img src="uploads/admin/<?= htmlspecialchars($adminPicture) ?>"
           alt="Profile"
           class="rounded-circle"
           style="object-fit: cover; width: 40px; height: 40px;" />
    <?php else: ?>
      <div class="rounded-circle bg-secondary d-flex justify-content-center align-items-center"
           style="width: 40px; height: 40px;">
        <i class="bi bi-person text-white fs-5"></i>
      </div>
    <?php endif; ?>
    <span class="dropdown-toggle d-none d-md-inline-block text-truncate" style="max-width: 120px;">
      <?= htmlspecialchars($fullname) ?>
    </span>
  </a>

  <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow profile w-100" style="max-width: none; word-wrap: break-word;">
    <li class="dropdown-header">
      <h6><?= htmlspecialchars($fullname) ?></h6>
      <span><?= htmlspecialchars($position) ?></span>
    </li>

    <li><hr class="dropdown-divider"></li>

    <li>
      <a class="dropdown-item d-flex align-items-center" href="admin_profile.php">
        <i class="bi bi-person"></i>
        <span>My Profile</span>
      </a>
    </li>

    <li><hr class="dropdown-divider"></li>

    <li>
      <a class="dropdown-item d-flex align-items-center" href="/elderlycare/logout.php">
        <i class="bi bi-box-arrow-right"></i>
        <span>Sign Out</span>
      </a>
    </li>
  </ul>
</li>

  </nav>
    </header>

 
  <aside id="admin-sidebar" class="sidebar">
  <h3 class="text-white text-center space-below">Admin Dashboard</h3>
  <ul class="sidebar-nav" id="admin-sidebar-nav">

    <li class="nav-item">
      <a class="nav-link collapsed" href="AdminDashboard.php">
        <i class="bi bi-house-door"></i>
        <span>Dashboard</span>
      </a>
    </li>
    <li class="nav-item">
        <a class="nav-link collapsed" href="manage_rooms.php">
          <i class="bi bi-door-open"></i>
          <span>Manage Patient Rooms </span>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link collapsed" href="caregiver_account_request.php">
          <i class="bi bi-check-circle"></i>
          <span>Caregiver Approvals </span>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link collapsed" href="patients_request.php">
          <i class="bi bi-person-check"></i>
          <span>Patient's Approvals </span>
        </a>
    </li>
    <li class="nav-item">
      <a class="nav-link collapsed" href="manage_patients.php">
        <i class="bi bi-file-earmark-person"></i>
        <span>Manage Patients</span>
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link collapsed" href="manage_caregivers.php">
        <i class="bi bi-person-bounding-box"></i>
        <span>Manage Caregivers</span>
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="view_reports.php">
      <i class="bi bi-file-earmark-text"></i> 
        <span>View Reports</span>
      </a>
    </li>

  </ul>
</aside>
<main id="main" class="main">
  <div class="pagetitle">
    <h2>Monthly Registration Reports</h2>
    <nav>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="admin_dashboard.php">Home</a></li>
        <li class="breadcrumb-item active">View Reports</li>
      </ol>
    </nav>
  </div>

  <section class="section">
    <div class="row g-4 justify-content-center mb-4">

    <hr class="my-4">

    <h3 class="mb-3">Recent System Notifications</h3>
    <ul class="list-group mb-5">
      <?php if (mysqli_num_rows($activity_result) > 0): ?>
        <?php while($row = mysqli_fetch_assoc($activity_result)): ?>
          <li class="list-group-item d-flex justify-content-between align-items-start">
            <div>
              <strong><?= htmlspecialchars($row['full_name'] ?? 'System') ?></strong>: 
              <?= htmlspecialchars($row['message']) ?>
            </div>
            <small class="text-muted"><?= date('M d, Y h:i A', strtotime($row['created_at'])) ?></small>
          </li>
        <?php endwhile; ?>
      <?php else: ?>
        <li class="list-group-item text-muted">No recent notifications found.</li>
      <?php endif; ?>
    </ul>

    <h3 class="mb-3">Recent Medicine Administrations</h3>
    <ul class="list-group mb-5">
      <?php if (mysqli_num_rows($medicine_activity_result) > 0): ?>
        <?php while($row = mysqli_fetch_assoc($medicine_activity_result)): ?>
          <li class="list-group-item d-flex justify-content-between align-items-start">
            <div>
              Medicine <strong><?= htmlspecialchars($row['medicine_name']) ?></strong> given to patient <strong><?= htmlspecialchars($row['patient_name']) ?></strong>
            </div>
            <small class="text-muted"><?= date('M d, Y h:i A', strtotime($row['administered_at'])) ?></small>
          </li>
        <?php endwhile; ?>
      <?php else: ?>
        <li class="list-group-item text-muted">No recent medicine administrations found.</li>
      <?php endif; ?>
    </ul>
    
<h3 class="mb-3">Caregivers & Their Patients</h3>
<div class="row gy-4">
  <?php foreach ($caregivers as $caregiver): ?>
    <div class="col-lg-6 col-md-12">
      <h3 class="mb-1"><?= htmlspecialchars($caregiver['name']) ?></h3>
      <p class="mb-2"><strong>Number of Patients:</strong> <?= count($caregiver['patients']) ?></p>
      <?php if (count($caregiver['patients']) > 0): ?>
        <ul class="list-unstyled mb-4">
          <?php foreach ($caregiver['patients'] as $patientName): ?>
            <li style="padding-left: 0; border: none;"><?= htmlspecialchars($patientName) ?></li>
          <?php endforeach; ?>
        </ul>
      <?php else: ?>
        <p class="text-muted fst-italic mb-4">No assigned patients</p>
      <?php endif; ?>
    </div>
  <?php endforeach; ?>
</div>


  </section>
</main>




    
    <footer id="footer" class="footer">
      <div class="copyright">
        &copy; Copyright <strong><span>ElderlyCare</span></strong>. All Rights Reserved
      </div>
    </footer>
    
   
    <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>
    

<script src="/elderlycare/assets/js/main.js"></script>
<script src="/elderlycare/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    </body>
    </html>
    