<?php
session_start();


// ✅ Prevent accessing cached login page after login
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

include 'caregiver_dbconnection.php'; 
include 'medication_notification.php';

// Check if the caregiver is logged in
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id']; // Caregiver's ID
    $email = $_SESSION['email']; // Caregiver's email

  if (isset($_GET['notif_id'])) {
    $notif_id = (int)$_GET['notif_id'];

    // Only mark admin notifications as read
    $updateQuery = "UPDATE admin_notifications SET is_read = 1 WHERE id = ? AND user_type = 'admin'";
    $stmt = mysqli_prepare($conn, $updateQuery);
    mysqli_stmt_bind_param($stmt, 'i', $notif_id);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    $typeQuery = "SELECT type, reference_id FROM admin_notifications WHERE id = ?";
    $stmtType = mysqli_prepare($conn, $typeQuery);
    mysqli_stmt_bind_param($stmtType, 'i', $notif_id);
    mysqli_stmt_execute($stmtType);
    mysqli_stmt_bind_result($stmtType, $type, $reference_id);

    if (mysqli_stmt_fetch($stmtType)) {
        mysqli_stmt_close($stmtType);

        if ($type === 'medicine') {
            header("Location: task_and_notes.php?id=" . urlencode($reference_id));
            exit;
        } else {
            header("Location: password_verify.php");
            exit;
        }
    } else {
        mysqli_stmt_close($stmtType);
        header("Location: password_verify.php");
        exit;
    }
}


$notifQuery = "SELECT * FROM admin_notifications 
               WHERE user_id = ? AND user_type = 'admin' 
               ORDER BY created_at DESC";
$stmt = mysqli_prepare($conn, $notifQuery);
mysqli_stmt_bind_param($stmt, 'i', $user_id);
mysqli_stmt_execute($stmt);
$notifResult = mysqli_stmt_get_result($stmt);

$notifications = [];
while ($row = mysqli_fetch_assoc($notifResult)) {
    $notifications[] = $row;
}

    if (isset($_POST['markAllRead'])) {
        $updateQuery = "UPDATE admin_notifications SET is_read = 1 WHERE user_id = ? AND user_type = 'admin'";
        $stmt = mysqli_prepare($conn, $updateQuery);
        mysqli_stmt_bind_param($stmt, 'i', $user_id);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        // Refresh the page to update notification badge
        header("Location: " . $_SERVER['PHP_SELF']);
        exit;
    }


   $patients = [];
$patientQuery = "SELECT id, first_name, middle_name, last_name FROM patients WHERE caregiver_id = ? AND status = 'approved'";
$stmt = $conn->prepare($patientQuery);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$patientResult = $stmt->get_result();

while ($row = $patientResult->fetch_assoc()) {
    $patients[] = $row;
}

} else {
    echo "<script>
        alert('Please log in first');
        window.location.href = '/elderlycare/index.php';
    </script>";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Patients</title>

<!-- Favicons -->
<link href="/elderlycare/assets/img/logo.png" rel="icon">

<!-- Google Fonts -->
<link href="https://fonts.gstatic.com" rel="preconnect">
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

<!-- Vendor CSS Files -->
<link href="/elderlycare/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/quill/quill.snow.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/quill/quill.bubble.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/remixicon/remixicon.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/simple-datatables/style.css" rel="stylesheet">

<!-- Template Main CSS File -->
<link href="/elderlycare/assets/css/style.css" rel="stylesheet">

</head>
<style>
  .notification-item.unread {
  background-color: #f0f8ff;
}
.notification-item.unread p {
  font-weight: bold;
}
.notifications {
  max-height: 300px; 
  overflow-y: auto;  
}
@media (max-width: 576px), (max-width: 780px) {
  .dropdown-menu.profile {
    position: fixed !important;
    top: 60px;
    left: 0 !important;
    right: 0 !important;
    border-radius: 0;
    z-index: 1050;
  }
}

@media (max-width: 576px) {
  .dropdown-menu.notifications {
    position: fixed !important;
    top: 60px;
    left: 0 !important;
    right: 0 !important;
    width: 100vw !important;
    max-width: none !important;
    border-radius: 0;
    z-index: 1050;
  }
}

</style>
<body>


<header id="header" class="header fixed-top d-flex align-items-center">

<div class="d-flex align-items-center justify-content-between">
  <a href="CaregiverDashboard.php" class="logo d-flex align-items-center">
  <img src="/elderlycare/assets/img/logo.png" alt="Logo">
    <span class="d-none d-lg-block">ElderlyCare</span>
  </a>
  <i class="bi bi-list toggle-sidebar-btn"></i>
</div>


<nav class="header-nav ms-auto">
  <ul class="d-flex align-items-center">

  <li class="nav-item dropdown">
        <a class="nav-link nav-icon" href="#" data-bs-toggle="dropdown">
          <i class="bi bi-bell"></i>
          <?php
          $unreadQuery = "SELECT COUNT(*) AS unread_count FROM admin_notifications WHERE user_id = ? AND user_type = 'admin' AND is_read = 0";
          $stmt = mysqli_prepare($conn, $unreadQuery);
          mysqli_stmt_bind_param($stmt, 'i', $user_id);
          mysqli_stmt_execute($stmt);
          $result = mysqli_stmt_get_result($stmt);
          $unread_count = mysqli_fetch_assoc($result)['unread_count'];
          ?>
          <?php if ($unread_count > 0): ?>
            <span class="badge bg-primary badge-number"><?= $unread_count; ?></span>
          <?php endif; ?>
        </a><!-- End Notification Icon -->

        <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow notifications">
         <li class="dropdown-header">
          <span>
            You have <?= $unread_count; ?> new notification<?= $unread_count !== 1 ? 's' : ''; ?>
          </span>
          <?php if ($unread_count > 0): ?>
            <div class="mt-2">
              <form method="POST">
                <button type="submit" name="markAllRead"  class="btn" style="font-size: 13px; height: 35px;">
                  Mark all as read
                </button>
              </form>
            </div>
          <?php endif; ?>
        </li>

          <li><hr class="dropdown-divider"></li>

          <?php if (count($notifications) > 0): ?>
            <?php foreach ($notifications as $note):
              $liClass = $note['is_read'] == 0 ? 'notification-item unread' : 'notification-item';
            ?>
              <li class="<?= $liClass ?>">
                <a href="?notif_id=<?= $note['id']; ?>" class="d-flex align-items-start text-decoration-none">
                  <i class="bi bi-info-circle text-info me-2"></i>
                  <div>
                    <p class="mb-1"><?= htmlspecialchars($note['message']); ?></p>
                    <small class="text-muted"><?= date("M d, Y H:i", strtotime($note['created_at'])); ?></small>
                  </div>
                </a>
              </li>
              <li><hr class="dropdown-divider"></li>
            <?php endforeach; ?>
          <?php else: ?>
            <li class="notification-item text-center">
              <p>No new notifications</p>
            </li>
          <?php endif; ?>
        </ul>
      </li><!-- End Notification Nav -->

   
    <?php
    include 'caregiver_dbconnection.php'; 
    // Fetch caregiver info including profile picture
    $caregiverInfoQuery = "SELECT pic, full_name FROM caregivers_info WHERE caregiver_id = ?";
    $stmt = mysqli_prepare($conn, $caregiverInfoQuery);
    mysqli_stmt_bind_param($stmt, 'i', $user_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $caregiverInfo = mysqli_fetch_assoc($result);

    $caregiverPic = !empty($caregiverInfo['pic']) 
        ? 'templates/caregiver/uploads/caregivers/' . $caregiverInfo['pic'] 
        : 'assets/img/default-profile.png';


    $caregiverName = $caregiverInfo['full_name'] ?? 'Caregiver';

    ?>
          <li class="nav-item dropdown pe-3">
  <a class="nav-link nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown">
    <?php if (!empty($caregiverPic) && file_exists(__DIR__ . "/../../$caregiverPic")): ?>
      <img src="/elderlycare/<?= htmlspecialchars($caregiverPic); ?>" 
           alt="Profile" 
           class="rounded-circle" 
           style="width: 40px; height: 40px; object-fit: cover;" />
    <?php else: ?>
      <div class="rounded-circle bg-secondary d-flex justify-content-center align-items-center"
           style="width: 40px; height: 40px;">
        <i class="bi bi-person text-white fs-5"></i>
      </div>
    <?php endif; ?>
    <span class="d-none d-md-block dropdown-toggle ps-2"><?= htmlspecialchars($caregiverName) ?></span>
  </a>

  <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow profile">
    <li class="dropdown-header">
      <h6><?= htmlspecialchars($caregiverName) ?></h6>
      <span>Caregiver</span>
    </li>

    <li><hr class="dropdown-divider" /></li>

    <li>
      <a class="dropdown-item d-flex align-items-center" href="caregiver_profile.php">
        <i class="bi bi-person"></i>
        <span>My Profile</span>
      </a>
    </li>

    <li><hr class="dropdown-divider" /></li>

    <li>
      <a class="dropdown-item d-flex align-items-center" href="/elderlycare/logout.php">
    <i class="bi bi-box-arrow-right"></i>
    <span>Sign Out</span>
  </a>
    </li>
  </ul>
</li>
  </nav>
</header>


<aside id="sidebar" class="sidebar">
  <h3 class="text-white text-center space-below">Caregiver Dashboard</h3>
  <ul class="sidebar-nav" id="sidebar-nav">
    <ul class="sidebar-nav" id="sidebar-nav">
      <li class="nav-item">
        <a class="nav-link collapsed" href="CaregiverDashboard.php">
        <i class="bi bi-house-door"></i>
        <span>Dashboard</span>
      </a>

        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="password_verify.php">
          <i class="bi bi-people"></i>
          <span>My Patients</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="add_patient.php">
          <i class="bi bi-person-plus"></i>
          <span>Add Patient</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="vital_signs.php">
        <i class="bi bi-heart-pulse"></i>
          <span>Vital Signs</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="appointments.php">
        <i class="bi bi-calendar-check"></i>
        <span>Appointments</span>
      </a>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="task_and_notes.php">
          <i class="bi bi-list-check"></i>
          <span>Tasks & Routines</span>
        </a>
      </li>
    
  </aside>

  <main id="main" class="main">
  <div class="pagetitle">
    <h2>Manage Appointments</h2>
    <nav>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="/dashboard">Home</a></li>
        <li class="breadcrumb-item"><a href="CaregiverDashboard.php">Caregiver Dashboard</a></li>
        <li class="breadcrumb-item active">Appointments</li>
      </ol>
    </nav>
  </div>

  <section class="section">
    <div class="row">
      <div class="col-lg-12">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title">Appointment Details</h5>
            <form action="caregiver_process.php" method="POST">
    <div class="row mb-3">
        <label for="patient" class="col-sm-2 col-form-label">Patient</label>
        <div class="col-sm-10">
           <select class="form-select" id="patient" name="patient_id" required>
              <option value="" selected>Select Patient</option>
              <?php foreach ($patients as $patient): ?>
                  <option value="<?php echo $patient['id']; ?>">
                      <?php echo $patient['first_name'] . ' ' . $patient['middle_name'] . ' ' . $patient['last_name']; ?>
                  </option>
              <?php endforeach; ?>
          </select>


        </div>
    </div>
    <div class="row mb-3">
        <label for="appointmentDate" class="col-sm-2 col-form-label">Appointment Date</label>
        <div class="col-sm-10">
            <input type="date" class="form-control" id="appointmentDate" name="appointment_date" required>
        </div>
    </div>
    <div class="row mb-3">
        <label for="appointmentTime" class="col-sm-2 col-form-label">Appointment Time</label>
        <div class="col-sm-10">
            <input type="time" class="form-control" id="appointmentTime" name="appointment_time" required>
        </div>
    </div>
    <div class="row mb-3">
        <label for="appointmentPurpose" class="col-sm-2 col-form-label">Appointment Purpose</label>
        <div class="col-sm-10">
            <select class="form-select" id="appointmentPurpose" name="appointment_purpose" required>
                <option value="" selected>Select Purpose</option>
                <option value="checkup">Routine Check-up</option>
                <option value="consultation">Consultation</option>
                <option value="followup">Follow-up</option>
                <option value="laboratorytest">Laboratory Test</option>
            </select>
        </div>
    </div>

    <div class="d-flex justify-content-center">
        <button type="submit" name="add_appointment" class="btn" style="height: 50px;">Add Appointment</button>
    </div>
</form>

          </div>
        </div>
      </div>
    </div>
  </section>
</main>


<footer id="footer" class="footer">
  <div class="copyright">
    &copy; Copyright <strong><span>ElderlyCare</span></strong>. All Rights Reserved
  </div>
</footer>
<script>
  let residentId = null;

  function showUpdateModal(id) {
    residentId = id;
    const updateModal = new bootstrap.Modal(document.getElementById('updateModal'));
    updateModal.show();
  }

  document.getElementById('confirmUpdateButton').addEventListener('click', function () {
    if (residentId !== null) {
      
    }
  });
</script>



<script src="/elderlycare/assets/js/main.js"></script>
<script src="/elderlycare/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>
