<?php
date_default_timezone_set('Asia/Manila');
session_start();



header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

include 'caregiver_dbconnection.php';
include 'medication_notification.php';

if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id']; 
    $email = $_SESSION['email'];

   if (isset($_GET['notif_id'])) {
    $notif_id = (int)$_GET['notif_id'];

    // Only mark admin notifications as read
    $updateQuery = "UPDATE admin_notifications SET is_read = 1 WHERE id = ? AND user_type = 'admin'";
    $stmt = mysqli_prepare($conn, $updateQuery);
    mysqli_stmt_bind_param($stmt, 'i', $notif_id);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    $typeQuery = "SELECT type, reference_id FROM admin_notifications WHERE id = ?";
    $stmtType = mysqli_prepare($conn, $typeQuery);
    mysqli_stmt_bind_param($stmtType, 'i', $notif_id);
    mysqli_stmt_execute($stmtType);
    mysqli_stmt_bind_result($stmtType, $type, $reference_id);

    if (mysqli_stmt_fetch($stmtType)) {
        mysqli_stmt_close($stmtType);

        if ($type === 'medicine') {
            header("Location: task_and_notes.php?id=" . urlencode($reference_id));
            exit;
        } else {
            header("Location: password_verify.php");
            exit;
        }
    } else {
        mysqli_stmt_close($stmtType);
        header("Location: password_verify.php");
        exit;
    }
}


$notifQuery = "SELECT * FROM admin_notifications 
               WHERE user_id = ? AND user_type = 'admin' 
               ORDER BY created_at DESC";
$stmt = mysqli_prepare($conn, $notifQuery);
mysqli_stmt_bind_param($stmt, 'i', $user_id);
mysqli_stmt_execute($stmt);
$notifResult = mysqli_stmt_get_result($stmt);

$notifications = [];
while ($row = mysqli_fetch_assoc($notifResult)) {
    $notifications[] = $row;
}
    if (isset($_POST['markAllRead'])) {
        $updateQuery = "UPDATE admin_notifications SET is_read = 1 WHERE user_id = ? AND user_type = 'admin'";
        $stmt = mysqli_prepare($conn, $updateQuery);
        mysqli_stmt_bind_param($stmt, 'i', $user_id);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        // Refresh the page to update notification badge
        header("Location: " . $_SERVER['PHP_SELF']);
        exit;
    }


    $sql = "SELECT id, CONCAT(first_name, ' ', IFNULL(middle_name, ''), ' ', last_name) AS full_name 
        FROM patients 
        WHERE caregiver_id = ? AND status = 'Approved'";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $caregiver_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$patients = [];
if ($result) {
    while ($row = mysqli_fetch_assoc($result)) {
        $row['full_name'] = trim(preg_replace('/\s+/', ' ', $row['full_name']));
        $patients[] = $row;
    }
}
  

} else {
    echo "<script>
        alert('Please log in first');
        window.location.href = '/elderlycare/index.php';
    </script>";
    exit;
    
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tasks & Notes</title>

    <!-- Favicons -->
    <link href="/elderlycare/assets/img/logo.png" rel="icon">

    <!-- Google Fonts -->
    <link href="https://fonts.gstatic.com" rel="preconnect">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans|Nunito|Poppins" rel="stylesheet">

    <!-- Vendor CSS Files -->
    <link href="/elderlycare/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="/elderlycare/assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">

    <!-- Template Main CSS File -->
    <link href="/elderlycare/assets/css/style.css" rel="stylesheet">
</head>

<style>
  .notification-item.unread {
  background-color: #f0f8ff;
}
.notification-item.unread p {
  font-weight: bold;
}
.notifications {
  max-height: 300px; 
  overflow-y: auto;  
}

/* Buttons alignment fix */
.table .action-buttons {
  display: flex;
  flex-wrap: wrap;
  gap: 5px;
}

@media (max-width: 576px) {
  .table .action-buttons {
    flex-direction: column;
    align-items: stretch;
  }
  .table .action-buttons .btn {
    width: 100%;
  }
}
@media (max-width: 576px), (max-width: 780px) {
  .dropdown-menu.profile {
    position: fixed !important;
    top: 60px;
    left: 0 !important;
    right: 0 !important;
    border-radius: 0;
    z-index: 1050;
  }
}

@media (max-width: 576px) {
  .dropdown-menu.notifications {
    position: fixed !important;
    top: 60px;
    left: 0 !important;
    right: 0 !important;
    width: 100vw !important;
    max-width: none !important;
    border-radius: 0;
    z-index: 1050;
  }
}

</style>
<body>

<header id="header" class="header fixed-top d-flex align-items-center">

<div class="d-flex align-items-center justify-content-between">
  <a href="CaregiverDashboard.php" class="logo d-flex align-items-center">
  <img src="/elderlycare/assets/img/logo.png" alt="Logo">
    <span class="d-none d-lg-block">ElderlyCare</span>
  </a>
  <i class="bi bi-list toggle-sidebar-btn"></i>
</div>

<div class="search-bar">
  <form class="search-form d-flex align-items-center" method="POST" action="#">
    <input type="text" name="query" placeholder="Search" title="Enter search keyword">
    <button type="submit" title="Search"><i class="bi bi-search"></i></button>
  </form>
</div>

<nav class="header-nav ms-auto">
  <ul class="d-flex align-items-center">
<li class="nav-item dropdown">
        <a class="nav-link nav-icon" href="#" data-bs-toggle="dropdown">
          <i class="bi bi-bell"></i>
          <?php
          $unreadQuery = "SELECT COUNT(*) AS unread_count FROM admin_notifications WHERE user_id = ? AND user_type = 'admin' AND is_read = 0";
          $stmt = mysqli_prepare($conn, $unreadQuery);
          mysqli_stmt_bind_param($stmt, 'i', $user_id);
          mysqli_stmt_execute($stmt);
          $result = mysqli_stmt_get_result($stmt);
          $unread_count = mysqli_fetch_assoc($result)['unread_count'];
          ?>
          <?php if ($unread_count > 0): ?>
            <span class="badge bg-primary badge-number"><?= $unread_count; ?></span>
          <?php endif; ?>
        </a><!-- End Notification Icon -->

        <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow notifications">
         <li class="dropdown-header">
          <span>
            You have <?= $unread_count; ?> new notification<?= $unread_count !== 1 ? 's' : ''; ?>
          </span>
          <?php if ($unread_count > 0): ?>
            <div class="mt-2">
              <form method="POST">
                <button type="submit" name="markAllRead"  class="btn" style="font-size: 13px; height: 35px;">
                  Mark all as read
                </button>
              </form>
            </div>
          <?php endif; ?>
        </li>

          <li><hr class="dropdown-divider"></li>

          <?php if (count($notifications) > 0): ?>
            <?php foreach ($notifications as $note):
              $liClass = $note['is_read'] == 0 ? 'notification-item unread' : 'notification-item';
            ?>
              <li class="<?= $liClass ?>">
                <a href="?notif_id=<?= $note['id']; ?>" class="d-flex align-items-start text-decoration-none">
                  <i class="bi bi-info-circle text-info me-2"></i>
                  <div>
                    <p class="mb-1"><?= htmlspecialchars($note['message']); ?></p>
                    <small class="text-muted"><?= date("M d, Y H:i", strtotime($note['created_at'])); ?></small>
                  </div>
                </a>
              </li>
              <li><hr class="dropdown-divider"></li>
            <?php endforeach; ?>
          <?php else: ?>
            <li class="notification-item text-center">
              <p>No new notifications</p>
            </li>
          <?php endif; ?>
        </ul>
      </li><!-- End Notification Nav -->

      
  
    <?php
    include 'caregiver_dbconnection.php'; 
    
    $caregiverInfoQuery = "SELECT pic, full_name FROM caregivers_info WHERE caregiver_id = ?";
    $stmt = mysqli_prepare($conn, $caregiverInfoQuery);
    mysqli_stmt_bind_param($stmt, 'i', $user_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $caregiverInfo = mysqli_fetch_assoc($result);

    $caregiverPic = !empty($caregiverInfo['pic']) 
        ? 'templates/caregiver/uploads/caregivers/' . $caregiverInfo['pic'] 
        : 'assets/img/default-profile.png';


    $caregiverName = $caregiverInfo['full_name'] ?? 'Caregiver';

    ?>
          <li class="nav-item dropdown pe-3">
  <a class="nav-link nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown">
    <?php if (!empty($caregiverPic) && file_exists(__DIR__ . "/../../$caregiverPic")): ?>
      <img src="/elderlycare/<?= htmlspecialchars($caregiverPic); ?>" 
           alt="Profile" 
           class="rounded-circle" 
           style="width: 40px; height: 40px; object-fit: cover;" />
    <?php else: ?>
      <div class="rounded-circle bg-secondary d-flex justify-content-center align-items-center"
           style="width: 40px; height: 40px;">
        <i class="bi bi-person text-white fs-5"></i>
      </div>
    <?php endif; ?>
    <span class="d-none d-md-block dropdown-toggle ps-2"><?= htmlspecialchars($caregiverName) ?></span>
  </a>

  <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow profile">
    <li class="dropdown-header">
      <h6><?= htmlspecialchars($caregiverName) ?></h6>
      <span>Caregiver</span>
    </li>

    <li><hr class="dropdown-divider" /></li>

    <li>
      <a class="dropdown-item d-flex align-items-center" href="caregiver_profile.php">
        <i class="bi bi-person"></i>
        <span>My Profile</span>
      </a>
    </li>

    <li><hr class="dropdown-divider" /></li>

    <li>
         <a class="dropdown-item d-flex align-items-center" href="/elderlycare/logout.php">
    <i class="bi bi-box-arrow-right"></i>
    <span>Sign Out</span>
  </a>
    </li>
</li>
  </nav>
</header>

<aside id="sidebar" class="sidebar">
  <h3 class="text-white text-center space-below">Caregiver Dashboard</h3>
  <ul class="sidebar-nav" id="sidebar-nav">
    <ul class="sidebar-nav" id="sidebar-nav">
      <li class="nav-item">
        <a class="nav-link collapsed" href="CaregiverDashboard.php">
        <i class="bi bi-house-door"></i>
        <span>Dashboard</span>
      </a>

        </a>
      </li>
        <li class="nav-item">
          <a class="nav-link collapsed" href="password_verify.php">
            <i class="bi bi-people"></i>
            <span>My Patients</span>
          </a>
        </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="add_patient.php">
          <i class="bi bi-person-plus"></i>
          <span>Add Patient</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="vital_signs.php">
        <i class="bi bi-heart-pulse"></i>
          <span>Vital Signs</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="appointments.php">
        <i class="bi bi-calendar-check"></i>
        <span>Appointments</span>
      </a>
      </li>
      <li class="nav-item">
        <a class="nav-link " href="task_and_notes.php">
          <i class="bi bi-list-check"></i>
          <span>Tasks & Routines</span>
        </a>
      </li>
    
  </aside>

   <main id="main" class="main">
  <div class="pagetitle">
    <h2>Tasks & Notes</h2>
    <nav>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="CaregiverDashboard.php">Home</a></li>
        <li class="breadcrumb-item active">Tasks & Notes</li>
      </ol>
    </nav>
  </div>

  <section class="section">
    <div class="row">
      <div class="col-lg-12">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title">Manage Patient Tasks, Routines & Medicines</h5>

            <!-- Assign Task/Routine -->
            <h4>Assign New Task</h4>
            <form method="POST" action="caregiver_process.php">
              <div class="row mb-3">
                <div class="col-md-4">
                  <label for="patient_id">Select Patient</label>
                  <select class="form-select" name="patient_id" required>
                    <option value="">-- Select Patient --</option>
                    <?php foreach (($patients ?? []) as $patient): ?>
                      <option value="<?= $patient['id'] ?>"><?= htmlspecialchars($patient['full_name']) ?></option>
                    <?php endforeach; ?>
                  </select>
                </div>
                <div class="col-md-4">
                  <label for="task_description">Task</label>
                  <input type="text" class="form-control" name="task_description" required>
                </div>
                <div class="col-md-2">
                  <label for="routine_time">Time</label>
                  <input type="time" class="form-control" name="routine_time">
                </div>
                <div class="col-md-2">
                  <label for="frequency">Frequency</label>
                  <select class="form-select" name="frequency">
                    <option value="Daily">Daily</option>
                    <option value="Weekly">Weekly</option>
                    <option value="Monthly">Monthly</option>
                  </select>
                </div>
              </div>
              <button type="submit" name="submitTask" class="btn ">Add Task</button>
            </form>

            <hr class="my-4">

            <!-- Assign Medicine -->
            <h4>Assign Medicine</h4>
            <form method="POST" action="caregiver_process.php">
              <div class="row mb-3">
                <div class="col-md-3">
                  <label for="patient_id">Select Patient</label>
                  <select class="form-select" name="patient_id" required>
                    <option value="">-- Select Patient --</option>
                    <?php foreach (($patients ?? []) as $patient): ?>
                      <option value="<?= $patient['id'] ?>"><?= htmlspecialchars($patient['full_name']) ?></option>
                    <?php endforeach; ?>
                  </select>
                </div>
                <div class="col-md-3">
                  <label for="medicine_name">Medicine</label>
                  <input type="text" class="form-control" name="medicine_name" required>
                </div>
                <div class="col-md-2">
                  <label for="dosage">Dosage</label>
                  <input type="text" class="form-control" name="dosage" required>
                </div>
                <div class="col-md-2">
                  <label for="time_to_take">Time</label>
                  <input type="time" class="form-control" name="time_to_take">
                </div>
                <div class="col-md-2">
                  <label for="notes">Notes</label>
                  <input type="text" class="form-control" name="notes">
                </div>
              </div>
              <button type="submit" name="submitMedicine"class="btn ">Add Medicine</button>
            </form>

            <hr class="my-4">

            <!-- Task List -->
            
  <?php
  include 'caregiver_dbconnection.php';


  
  $caregiver_id = $user_id;
if (isset($_POST['mark_done'], $_POST['task_id'])) {
    $task_id = intval($_POST['task_id']);
    $today = date('Y-m-d');            
    $now = date('Y-m-d H:i:s');        

   
    $checkQuery = "SELECT 1 FROM task_completion_log WHERE task_id = ? AND caregiver_id = ? AND DATE(completed_at) = ?";
    $stmtCheck = mysqli_prepare($conn, $checkQuery);
    mysqli_stmt_bind_param($stmtCheck, 'iis', $task_id, $caregiver_id, $today);
    mysqli_stmt_execute($stmtCheck);
    mysqli_stmt_store_result($stmtCheck);

    if (mysqli_stmt_num_rows($stmtCheck) === 0) {
       
        $insertQuery = "INSERT INTO task_completion_log (task_id, caregiver_id, completed_at) VALUES (?, ?, ?)";
        $stmtInsert = mysqli_prepare($conn, $insertQuery);
        mysqli_stmt_bind_param($stmtInsert, 'iis', $task_id, $caregiver_id, $now);

        if (!mysqli_stmt_execute($stmtInsert)) {
            die("Task insert failed: " . mysqli_error($conn));
        }
    }

    echo "<script>
        alert('Task marked as done successfully.');
        window.location.href = 'task_and_notes.php';
    </script>";
    exit;
}

  if (isset($_POST['mark_medicine_done'], $_POST['medicine_id'])) {
      $medicine_id = intval($_POST['medicine_id']);
      $caregiver_id = intval($user_id);  
      $today_date = date('Y-m-d');       
      $now = date('Y-m-d H:i:s');       

      
      $checkMedQuery = "SELECT 1 FROM medicine_log WHERE medicine_id = ? AND caregiver_id = ? AND DATE(administered_at) = ?";
      $stmtCheckMed = mysqli_prepare($conn, $checkMedQuery);
      mysqli_stmt_bind_param($stmtCheckMed, 'iis', $medicine_id, $caregiver_id, $today_date);
      mysqli_stmt_execute($stmtCheckMed);
      mysqli_stmt_store_result($stmtCheckMed);

      if (mysqli_stmt_num_rows($stmtCheckMed) === 0) {
          
          $insertMedQuery = "INSERT INTO medicine_log (medicine_id, caregiver_id, administered_at) VALUES (?, ?, ?)";
          $stmtInsertMed = mysqli_prepare($conn, $insertMedQuery);
          mysqli_stmt_bind_param($stmtInsertMed, 'iis', $medicine_id, $caregiver_id, $now);
          mysqli_stmt_execute($stmtInsertMed);
      }

      echo "<script>
      alert('Medicine marked as done successfully.');
      window.location.href = 'task_and_notes.php';
      </script>";
      exit;
  }
  

$pendingTasksQuery = "
    SELECT pt.id AS task_id,
          pt.task_description,
          pt.routine_time,
          pt.frequency,
          CONCAT(p.first_name, ' ', IFNULL(p.middle_name,''), ' ', p.last_name) AS full_name
    FROM patient_tasks pt
    JOIN patients p ON p.id = pt.patient_id
    WHERE p.caregiver_id = ?
      AND NOT EXISTS (
          SELECT 1 FROM task_completion_log tcl
          WHERE tcl.task_id = pt.id
            AND DATE(tcl.completed_at) = CURDATE()
            AND tcl.caregiver_id = ?
      )
    ORDER BY pt.routine_time
";


  $stmtPending = mysqli_prepare($conn, $pendingTasksQuery);
  mysqli_stmt_bind_param($stmtPending, "ii", $caregiver_id, $caregiver_id);
  mysqli_stmt_execute($stmtPending);
  $pendingTasksResult = mysqli_stmt_get_result($stmtPending);

  
  $pendingMedsQuery = "
      SELECT p.id AS patient_id, 
            CONCAT(p.first_name, ' ', IFNULL(p.middle_name,''), ' ', p.last_name) AS full_name,
            pm.medicine_name,
            pm.dosage,
            pm.time_to_take,
            ml.administered_at,
            pm.id AS medicine_id
      FROM patient_medicines pm
      JOIN patients p ON pm.patient_id = p.id
      LEFT JOIN medicine_log ml ON ml.medicine_id = pm.id AND DATE(ml.administered_at) = CURDATE() AND ml.caregiver_id = ?
      WHERE pm.caregiver_id = ? AND ml.id IS NULL 
      ORDER BY p.id, pm.time_to_take
  ";

  $stmtPendingMeds = mysqli_prepare($conn, $pendingMedsQuery);
  mysqli_stmt_bind_param($stmtPendingMeds, "ii", $caregiver_id, $caregiver_id);
  mysqli_stmt_execute($stmtPendingMeds);
  $pendingMedsResult = mysqli_stmt_get_result($stmtPendingMeds);


 
$completedTasksQuery = "
    SELECT pt.id AS task_id,
          pt.task_description,
          tcl.completed_at,
          CONCAT(p.first_name, ' ', IFNULL(p.middle_name,''), ' ', p.last_name) AS full_name,
          p.id AS patient_id
    FROM task_completion_log tcl
    JOIN patient_tasks pt ON pt.id = tcl.task_id
    JOIN patients p ON pt.patient_id = p.id
    WHERE tcl.caregiver_id = ? AND DATE(tcl.completed_at) = CURDATE()
    ORDER BY tcl.completed_at DESC
";


  $stmtCompletedTasks = mysqli_prepare($conn, $completedTasksQuery);
  mysqli_stmt_bind_param($stmtCompletedTasks, "i", $caregiver_id);
  mysqli_stmt_execute($stmtCompletedTasks);
  $completedTasksResult = mysqli_stmt_get_result($stmtCompletedTasks);

  $completedTasksByPatient = [];
  while ($row = mysqli_fetch_assoc($completedTasksResult)) {
      $pid = $row['patient_id'];
      if (!isset($completedTasksByPatient[$pid])) {
          $completedTasksByPatient[$pid] = [
              'full_name' => $row['full_name'],
              'tasks' => []
          ];
      }
      $completedTasksByPatient[$pid]['tasks'][] = [
          'name' => $row['task_description'],
          'completed_at' => $row['completed_at']
      ];
  }

$completedMedsQuery = "
    SELECT p.id AS patient_id, 
          CONCAT(p.first_name, ' ', IFNULL(p.middle_name,''), ' ', p.last_name) AS full_name,
          pm.medicine_name,
          pm.time_to_take,        -- add this line
          ml.administered_at
    FROM medicine_log ml
    JOIN patient_medicines pm ON ml.medicine_id = pm.id
    JOIN patients p ON pm.patient_id = p.id
    WHERE ml.caregiver_id = ? AND DATE(ml.administered_at) = CURDATE()
    ORDER BY p.id, ml.administered_at DESC
";

$stmtMed = mysqli_prepare($conn, $completedMedsQuery);
mysqli_stmt_bind_param($stmtMed, "i", $caregiver_id);
mysqli_stmt_execute($stmtMed);
$completedMedsResult = mysqli_stmt_get_result($stmtMed);

$completedMedsByPatient = [];
while ($row = mysqli_fetch_assoc($completedMedsResult)) {
    $pid = $row['patient_id'];
    if (!isset($completedMedsByPatient[$pid])) {
        $completedMedsByPatient[$pid] = [
            'full_name' => $row['full_name'],
            'medicines' => []
        ];
    }
    $completedMedsByPatient[$pid]['medicines'][] = [
        'name' => $row['medicine_name'],
        'time_to_take' => $row['time_to_take'],       
        'administered_at' => $row['administered_at']
    ];
}
?>

<div class="card-body mt-4">
  <h5 class="card-title">Pending Tasks</h5>
  <div class="table-responsive">
    <table class="table table-bordered">
      <thead>
        <tr>
          <th>No.</th>
          <th>Patient</th>
          <th>Task Description</th>
          <th>Routine Time</th>
          <th>Frequency</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php 
        $taskNo = 1;
        while ($task = mysqli_fetch_assoc($pendingTasksResult)): 
          $taskId = intval($task['task_id']);
        ?>
          <tr>
            <td><?= $taskNo++ ?></td>
            <td><?= htmlspecialchars($task['full_name']) ?></td>
            <td><?= htmlspecialchars($task['task_description']) ?></td>
            <td><?= !empty($task['routine_time']) ? date("h:i A", strtotime($task['routine_time'])) : '-' ?></td>
            <td><?= htmlspecialchars($task['frequency']) ?></td>
            <td class="text-center">
              <div class="action-buttons d-flex justify-content-center gap-2">
                <form method="post" action="">
                  <input type="hidden" name="task_id" value="<?= $taskId ?>">
                  <button type="submit" name="mark_done" class="btn btn-sm">Mark Done</button>
                </form>
                <button type="button" class="btn btn-sm " data-bs-toggle="modal" data-bs-target="#editModal<?= $taskId ?>">
                  Edit
                </button>
                <form method="post" action="caregiver_process.php" onsubmit="return confirm('Are you sure you want to delete this task?');">
                  <input type="hidden" name="task_id" value="<?= $taskId ?>">
                  <button type="submit" name="deleteTask" class="btn btn-sm ">Delete</button>
                </form>
              </div>
            </td>


          <!-- Edit Modal -->
          <div class="modal fade" id="editModal<?= $taskId ?>" tabindex="-1" aria-labelledby="editModalLabel<?= $taskId ?>" aria-hidden="true">
            <div class="modal-dialog">
              <div class="modal-content">
                <form method="post" action="caregiver_process.php">
                  <div class="modal-header">
                    <h5 class="modal-title" id="editModalLabel<?= $taskId ?>">Edit Task</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                  </div>
                  <div class="modal-body">
                    <input type="hidden" name="task_id" value="<?= intval($task['task_id']) ?>">
                    <div class="mb-3">
                      <label for="taskName<?= $taskId ?>" class="form-label">Task Description</label>
                      <input type="text" class="form-control" id="taskName<?= $taskId ?>" name="task_description" value="<?= htmlspecialchars($task['task_description']) ?>">
                    </div>
                    <div class="mb-3">
                      <label for="routineTime<?= $taskId ?>" class="form-label">Routine Time</label>
                      <input type="time" class="form-control" id="routineTime<?= $taskId ?>" name="routine_time" value="<?= !empty($task['routine_time']) ? date('H:i', strtotime($task['routine_time'])) : '' ?>">
                    </div>
                    <div class="mb-3">
                      <label for="frequency<?= $taskId ?>" class="form-label">Frequency</label>
                      <select class="form-select" id="frequency<?= $taskId ?>" name="frequency">
                        <option value="Daily" <?= ($task['frequency'] === 'Daily') ? 'selected' : '' ?>>Daily</option>
                        <option value="Weekly" <?= ($task['frequency'] === 'Weekly') ? 'selected' : '' ?>>Weekly</option>
                        <option value="Monthly" <?= ($task['frequency'] === 'Monthly') ? 'selected' : '' ?>>Monthly</option>
                      </select>
                    </div>
                  </div>
                  <div class="modal-footer">
                    <button type="submit" name="updateTask" class="btn ">Save Changes</button>
                    <button type="button" class="btn" data-bs-dismiss="modal">Cancel</button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        <?php endwhile; ?>
        <?php if ($taskNo === 1): ?>
          <tr><td colspan="6" class="text-center">No pending tasks.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>


<div class="card-body mt-4">
  <h5 class="card-title">Pending Medicines</h5>
  <div class="table-responsive">
    <table class="table table-bordered">
      <thead>
        <tr>
          <th>No.</th>
          <th>Patient</th>
          <th>Medicine</th>
          <th>Dosage</th>
          <th>Time</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php 
        $medNo = 1;
        while ($med = mysqli_fetch_assoc($pendingMedsResult)): ?>
          <tr>
            <td><?= $medNo++ ?></td>
            <td><?= htmlspecialchars($med['full_name']) ?></td>
            <td><?= htmlspecialchars($med['medicine_name']) ?></td>
            <td><?= htmlspecialchars($med['dosage']) ?></td>
            <td><?= htmlspecialchars(date("h:i A", strtotime($med['time_to_take']))) ?></td>
            <td class="text-center">
              <div class="action-buttons d-flex justify-content-center gap-2">
                <form method="post" action="">
                  <input type="hidden" name="medicine_id" value="<?= intval($med['medicine_id']) ?>">
                  <button type="submit" name="mark_medicine_done" class="btn btn-sm">Mark Done</button>
                </form>
                <button type="button" class="btn btn-sm " data-bs-toggle="modal" data-bs-target="#editMedicineModal<?= intval($med['medicine_id']) ?>">
                  Edit
                </button>
                <form method="post" action="caregiver_process.php" onsubmit="return confirm('Are you sure you want to delete this medicine?');">
                  <input type="hidden" name="medicine_id" value="<?= intval($med['medicine_id']) ?>">
                  <button type="submit" name="delete_medicine" class="btn btn-sm ">Delete</button>
                </form>
              </div>
            </td>

          </tr>

          <!-- Edit Medicine Modal -->
          <div class="modal fade" id="editMedicineModal<?= intval($med['medicine_id']) ?>" tabindex="-1" aria-labelledby="editMedicineModalLabel<?= intval($med['medicine_id']) ?>" aria-hidden="true">
            <div class="modal-dialog">
              <div class="modal-content">
                <form method="post" action="caregiver_process.php">
                  <div class="modal-header">
                    <h5 class="modal-title" id="editMedicineModalLabel<?= intval($med['medicine_id']) ?>">Edit Medicine</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                  </div>
                  <div class="modal-body">
                    <input type="hidden" name="id" value="<?= intval($med['medicine_id']) ?>">
                    <div class="mb-3">
                      <label for="medicineName<?= intval($med['medicine_id']) ?>" class="form-label">Medicine Name</label>
                      <input type="text" class="form-control" id="medicineName<?= intval($med['medicine_id']) ?>" name="medicine_name" value="<?= htmlspecialchars($med['medicine_name']) ?>" required>
                    </div>
                    <div class="mb-3">
                      <label for="dosage<?= intval($med['medicine_id']) ?>" class="form-label">Dosage</label>
                      <input type="text" class="form-control" id="dosage<?= intval($med['medicine_id']) ?>" name="dosage" value="<?= htmlspecialchars($med['dosage']) ?>">
                    </div>
                    <div class="mb-3">
                      <label for="timeToTake<?= intval($med['medicine_id']) ?>" class="form-label">Time to Take</label>
                      <input type="time" class="form-control" id="timeToTake<?= intval($med['medicine_id']) ?>" name="time_to_take" value="<?= htmlspecialchars($med['time_to_take']) ?>">
                    </div>
                  </div>
                  <div class="modal-footer">
                    <button type="submit" name="update_medicine" class="btn ">Save Changes</button>
                    <button type="button" class="btn " data-bs-dismiss="modal">Cancel</button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        <?php endwhile; ?>
        <?php if ($medNo === 1): ?>
          <tr><td colspan="6" class="text-center">No pending medicines.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<div class="card-body mt-4">
  <h5 class="card-title">Completed Tasks and Medicines Today</h5>
  <div class="table-responsive">
    <table class="table table-bordered">
      <thead>
        <tr>
          <th>No.</th>
          <th>Patient ID</th>
          <th>Patient's Full Name</th>
          <th>Completed Tasks</th>
          <th>Completed Medicines</th>
        </tr>
      </thead>
      <tbody>
        <?php
        $allPatientIds = array_unique(array_merge(
            array_keys($completedTasksByPatient ?? []),
            array_keys($completedMedsByPatient ?? [])
        ));

        if (empty($allPatientIds)) {
            echo '<tr><td colspan="5" class="text-center">No completed tasks or medicines today.</td></tr>';
        } else {
            $counter = 1; 
            foreach ($allPatientIds as $pid) {
                $fullName = $completedTasksByPatient[$pid]['full_name'] ?? $completedMedsByPatient[$pid]['full_name'] ?? 'N/A';

                echo "<tr>";
                echo "<td>" . $counter++ . "</td>"; 
                echo "<td>" . htmlspecialchars($pid) . "</td>";
                echo "<td>" . htmlspecialchars($fullName) . "</td>";

                echo "<td>";
                if (!empty($completedTasksByPatient[$pid]['tasks'])) {
                    echo "<ul>";
                    foreach ($completedTasksByPatient[$pid]['tasks'] as $task) {
                        $date = date('M d, Y h:i A', strtotime($task['completed_at']));
                        echo "<li>" . htmlspecialchars($task['name']) . " <small>($date)</small></li>";
                    }
                    echo "</ul>";
                } else {
                    echo "None";
                }
                echo "</td>";

                echo "<td>";
                if (!empty($completedMedsByPatient[$pid]['medicines'])) {
                    echo "<ul>";
                    foreach ($completedMedsByPatient[$pid]['medicines'] as $med) {
                        $administeredDate = date('M d, Y h:i A', strtotime($med['administered_at']));
                        $scheduledDate = date('M d, Y h:i A', strtotime($med['time_to_take']));
                        echo "<li>" . htmlspecialchars($med['name']) . " <small>(Scheduled: $scheduledDate | Given: $administeredDate)</small></li>";
                    }
                    echo "</ul>";
                } else {
                    echo "None";
                }
                echo "</td>";

                echo "</tr>";
            }
        }
        ?>
      </tbody>
    </table>
  </div>
</div>

        </div>
      </div>
    </div>
  </section>
</main>


    <footer id="footer" class="footer">
        <div class="copyright">
            &copy; Copyright <strong><span>ElderlyCare</span></strong>. All Rights Reserved
        </div>
    </footer>

   
    <script src="/elderlycare/assets/js/main.js"></script>
    <script src="/elderlycare/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
</body>

</html>
