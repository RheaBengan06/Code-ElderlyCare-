<?php
session_start();

header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

include 'caregiver_dbconnection.php'; 
include 'medication_notification.php';

if (!isset($_SESSION['user_id'])) {
    echo "<script>
        alert('Please log in first');
        window.location.href = '/elderlycare/index.php';
    </script>";
    exit;
}

$user_id = $_SESSION['user_id'];
$email = $_SESSION['email']; 
$caregiver_id = $_SESSION['user_id'];


if (isset($_GET['notif_id'])) {
    $notif_id = (int)$_GET['notif_id'];

    // Only mark admin notifications as read
    $updateQuery = "UPDATE admin_notifications SET is_read = 1 WHERE id = ? AND user_type = 'admin'";
    $stmt = mysqli_prepare($conn, $updateQuery);
    mysqli_stmt_bind_param($stmt, 'i', $notif_id);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    $typeQuery = "SELECT type, reference_id FROM admin_notifications WHERE id = ?";
    $stmtType = mysqli_prepare($conn, $typeQuery);
    mysqli_stmt_bind_param($stmtType, 'i', $notif_id);
    mysqli_stmt_execute($stmtType);
    mysqli_stmt_bind_result($stmtType, $type, $reference_id);

    if (mysqli_stmt_fetch($stmtType)) {
        mysqli_stmt_close($stmtType);

        if ($type === 'medicine') {
            header("Location: task_and_notes.php?id=" . urlencode($reference_id));
            exit;
        } else {
            header("Location: password_verify.php");
            exit;
        }
    } else {
        mysqli_stmt_close($stmtType);
        header("Location: password_verify.php");
        exit;
    }
}


$notifQuery = "SELECT * FROM admin_notifications 
               WHERE user_id = ? AND user_type = 'admin' 
               ORDER BY created_at DESC";
$stmt = mysqli_prepare($conn, $notifQuery);
mysqli_stmt_bind_param($stmt, 'i', $user_id);
mysqli_stmt_execute($stmt);
$notifResult = mysqli_stmt_get_result($stmt);

$notifications = [];
while ($row = mysqli_fetch_assoc($notifResult)) {
    $notifications[] = $row;
}
    // Handle "Mark all as read" button
    if (isset($_POST['markAllRead'])) {
        $updateQuery = "UPDATE admin_notifications SET is_read = 1 WHERE user_id = ? AND user_type = 'admin'";
        $stmt = mysqli_prepare($conn, $updateQuery);
        mysqli_stmt_bind_param($stmt, 'i', $user_id);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        // Refresh the page to update notification badge
        header("Location: " . $_SERVER['PHP_SELF']);
        exit;
    }

// Fetch available rooms
$availableRooms = [];
$roomQuery = "SELECT id, room_number, status 
              FROM rooms 
              WHERE status != 'Occupied' 
              ORDER BY room_number ASC";
if ($result = $conn->query($roomQuery)) {
    $availableRooms = $result->fetch_all(MYSQLI_ASSOC);
}

?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Patients</title>

<!-- Favicons -->
<link href="/elderlycare/assets/img/logo.png" rel="icon">


<!-- Google Fonts -->
<link href="https://fonts.gstatic.com" rel="preconnect">
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

<!-- Vendor CSS Files -->
<link href="/elderlycare/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/quill/quill.snow.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/quill/quill.bubble.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/remixicon/remixicon.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/simple-datatables/style.css" rel="stylesheet">

<!-- Template Main CSS File -->
<link href="/elderlycare/assets/css/style.css" rel="stylesheet">

</head>
<style>
  .notification-item.unread {
  background-color: #f0f8ff;
}
.notification-item.unread p {
  font-weight: bold;
}
.notifications {
  max-height: 300px; 
  overflow-y: auto;  
}
@media (max-width: 576px), (max-width: 780px) {
  .dropdown-menu.profile {
    position: fixed !important;
    top: 60px;
    left: 0 !important;
    right: 0 !important;
    border-radius: 0;
    z-index: 1050;
  }
}

@media (max-width: 576px) {
  .dropdown-menu.notifications {
    position: fixed !important;
    top: 60px;
    left: 0 !important;
    right: 0 !important;
    width: 100vw !important;
    max-width: none !important;
    border-radius: 0;
    z-index: 1050;
  }
}
@media (max-width: 576px) {
    .table.table-bordered .col-3,
    .table.table-bordered .col-9 {
        padding: 5px !important;
    }

    .btn {
        width: 100%;
        margin-top: 10px;
    }
}
</style>
<body>

 <!-- ======= Header ======= -->
<!-- ======= Header ======= -->
<header id="header" class="header fixed-top d-flex align-items-center">

<div class="d-flex align-items-center justify-content-between">
  <a href="CaregiverDashboard.php" class="logo d-flex align-items-center">
  <img src="/elderlycare/assets/img/logo.png" alt="Logo">
    <span class="d-none d-lg-block">ElderlyCare</span>
  </a>
  <i class="bi bi-list toggle-sidebar-btn"></i>
</div><!-- End Logo -->

<nav class="header-nav ms-auto">
  <ul class="d-flex align-items-center">

    <li class="nav-item dropdown">
        <a class="nav-link nav-icon" href="#" data-bs-toggle="dropdown">
          <i class="bi bi-bell"></i>
          <?php
          $unreadQuery = "SELECT COUNT(*) AS unread_count FROM admin_notifications WHERE user_id = ? AND user_type = 'admin' AND is_read = 0";
          $stmt = mysqli_prepare($conn, $unreadQuery);
          mysqli_stmt_bind_param($stmt, 'i', $user_id);
          mysqli_stmt_execute($stmt);
          $result = mysqli_stmt_get_result($stmt);
          $unread_count = mysqli_fetch_assoc($result)['unread_count'];
          ?>
          <?php if ($unread_count > 0): ?>
            <span class="badge bg-primary badge-number"><?= $unread_count; ?></span>
          <?php endif; ?>
        </a><!-- End Notification Icon -->

        <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow notifications">
         <li class="dropdown-header">
          <span>
            You have <?= $unread_count; ?> new notification<?= $unread_count !== 1 ? 's' : ''; ?>
          </span>
          <?php if ($unread_count > 0): ?>
            <div class="mt-2">
              <form method="POST">
                <button type="submit" name="markAllRead"  class="btn" style="font-size: 13px; height: 35px;">
                  Mark all as read
                </button>
              </form>
            </div>
          <?php endif; ?>
        </li>

          <li><hr class="dropdown-divider"></li>

          <?php if (count($notifications) > 0): ?>
            <?php foreach ($notifications as $note):
              $liClass = $note['is_read'] == 0 ? 'notification-item unread' : 'notification-item';
            ?>
              <li class="<?= $liClass ?>">
                <a href="?notif_id=<?= $note['id']; ?>" class="d-flex align-items-start text-decoration-none">
                  <i class="bi bi-info-circle text-info me-2"></i>
                  <div>
                    <p class="mb-1"><?= htmlspecialchars($note['message']); ?></p>
                    <small class="text-muted"><?= date("M d, Y H:i", strtotime($note['created_at'])); ?></small>
                  </div>
                </a>
              </li>
              <li><hr class="dropdown-divider"></li>
            <?php endforeach; ?>
          <?php else: ?>
            <li class="notification-item text-center">
              <p>No new notifications</p>
            </li>
          <?php endif; ?>
        </ul>
      </li><!-- End Notification Nav -->




      <!-- Profile Menu -->
    
    <?php
    include 'caregiver_dbconnection.php'; 

    $caregiverInfoQuery = "SELECT pic, full_name FROM caregivers_info WHERE caregiver_id = ?";
    $stmt = mysqli_prepare($conn, $caregiverInfoQuery);
    mysqli_stmt_bind_param($stmt, 'i', $user_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $caregiverInfo = mysqli_fetch_assoc($result);

    $caregiverPic = !empty($caregiverInfo['pic']) 
        ? 'templates/caregiver/uploads/caregivers/' . $caregiverInfo['pic'] 
        : 'assets/img/default-profile.png';


    $caregiverName = $caregiverInfo['full_name'] ?? 'Caregiver';

    ?>
          <li class="nav-item dropdown pe-3">
  <a class="nav-link nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown">
    <?php if (!empty($caregiverPic) && file_exists(__DIR__ . "/../../$caregiverPic")): ?>
      <img src="/elderlycare/<?= htmlspecialchars($caregiverPic); ?>" 
           alt="Profile" 
           class="rounded-circle" 
           style="width: 40px; height: 40px; object-fit: cover;" />
    <?php else: ?>
      <div class="rounded-circle bg-secondary d-flex justify-content-center align-items-center"
           style="width: 40px; height: 40px;">
        <i class="bi bi-person text-white fs-5"></i>
      </div>
    <?php endif; ?>
    <span class="d-none d-md-block dropdown-toggle ps-2"><?= htmlspecialchars($caregiverName) ?></span>
  </a>

  <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow profile">
    <li class="dropdown-header">
      <h6><?= htmlspecialchars($caregiverName) ?></h6>
      <span>Caregiver</span>
    </li>

    <li><hr class="dropdown-divider" /></li>

    <li>
      <a class="dropdown-item d-flex align-items-center" href="caregiver_profile.php">
        <i class="bi bi-person"></i>
        <span>My Profile</span>
      </a>
    </li>

    <li><hr class="dropdown-divider" /></li>

    <li>
      <a class="dropdown-item d-flex align-items-center" href="/elderlycare/logout.php">
    <i class="bi bi-box-arrow-right"></i>
    <span>Sign Out</span>
  </a>
    </li>
  </ul>
</li>

  </nav><!-- End Navbar -->
</header><!-- End Header -->

<aside id="sidebar" class="sidebar">
  <h3 class="text-white text-center space-below">Caregiver Dashboard</h3>
  <ul class="sidebar-nav" id="sidebar-nav">
    <ul class="sidebar-nav" id="sidebar-nav">
      <li class="nav-item">
        <a class="nav-link collapsed" href="CaregiverDashboard.php">
        <i class="bi bi-house-door"></i>
        <span>Dashboard</span>
      </a>

        </a>
      </li>
        <li class="nav-item">
          <a class="nav-link collapsed" href="password_verify.php">
            <i class="bi bi-people"></i>
            <span>My Patients</span>
          </a>
        </li>
      <li class="nav-item">
        <a class="nav-link " href="add_patient.php">
          <i class="bi bi-person-plus"></i>
          <span>Add Patient</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="vital_signs.php">
        <i class="bi bi-heart-pulse"></i>
          <span>Vital Signs</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="appointments.php">
        <i class="bi bi-calendar-check"></i>
        <span>Appointments</span>
      </a>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="task_and_notes.php">
          <i class="bi bi-list-check"></i>
          <span>Tasks & Routines</span>
        </a>
      </li>
    
  </aside><!-- End Sidebar-->
 <!-- Main Content -->
<main id="main" class="main">
  <div class="pagetitle">
    <h2>Add New Patient</h2>
    <nav>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="/dashboard">Home</a></li>
        <li class="breadcrumb-item"><a href="CaregiverDashboard.php">Caregiver Dashboard</a></li>
        <li class="breadcrumb-item active">Add Patient</li>
      </ol>
    </nav>
  </div>

  <section class="section">
    <div class="row">
      <div class="col-12">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title">Patient Details</h5>

            <form action="caregiver_process.php" method="POST" enctype="multipart/form-data">
              <input type="hidden" name="caregiver_id" value="<?= $caregiver_id ?>">

              <!-- Personal Details -->
              <h6 class="mb-3">Personal Details</h6>
              <div class="table table-bordered p-3 mb-4">
                <div class="mb-3 row">
                  <label class="col-12 col-sm-4 col-form-label fw-bold">Room Number:</label>
                  <div class="col-12 col-sm-8">
                    <select name="room_id" class="form-select" required>
                      <?php foreach ($availableRooms as $room): ?>
                        <option value="<?= $room['id'] ?>" <?= $room['status'] === 'Under Maintenance' ? 'disabled' : '' ?>>
                          <?= htmlspecialchars($room['room_number']) ?> <?= $room['status'] === 'Under Maintenance' ? '(Under Maintenance)' : '' ?>
                        </option>
                      <?php endforeach; ?>
                    </select>
                  </div>
                </div>

                <div class="mb-3 row">
                  <label class="col-12 col-sm-4 col-form-label fw-bold">Patient's Picture:</label>
                  <div class="col-12 col-sm-8">
                    <input type="file" class="form-control" name="patient_image" accept="image/*">
                  </div>
                </div>

                <div class="mb-3 row">
                  <label class="col-12 col-sm-4 col-form-label fw-bold">First Name:</label>
                  <div class="col-12 col-sm-8">
                    <input type="text" class="form-control" name="first_name" placeholder="Enter First Name" required>
                  </div>
                </div>

                <div class="mb-3 row">
                  <label class="col-12 col-sm-4 col-form-label fw-bold">Middle Name:</label>
                  <div class="col-12 col-sm-8">
                    <input type="text" class="form-control" name="middle_name" placeholder="Enter Middle Name">
                  </div>
                </div>

                <div class="mb-3 row">
                  <label class="col-12 col-sm-4 col-form-label fw-bold">Last Name:</label>
                  <div class="col-12 col-sm-8">
                    <input type="text" class="form-control" name="last_name" placeholder="Enter Last Name" required>
                  </div>
                </div>

                <div class="mb-3 row">
                  <label class="col-12 col-sm-4 col-form-label fw-bold">Date of Birth:</label>
                  <div class="col-12 col-sm-8">
                    <input type="date" class="form-control" name="dob" id="dob" required onchange="calculateAge()">
                  </div>
                </div>

                <div class="mb-3 row">
                  <label class="col-12 col-sm-4 col-form-label fw-bold">Age:</label>
                  <div class="col-12 col-sm-8">
                    <input type="number" class="form-control" name="age" id="age" readonly>
                  </div>
                </div>

                <div class="mb-3 row">
                  <label class="col-12 col-sm-4 col-form-label fw-bold">Gender:</label>
                  <div class="col-12 col-sm-8">
                    <select class="form-select" name="gender" required>
                      <option value="" disabled selected>Select Gender</option>
                      <option value="male">Male</option>
                      <option value="female">Female</option>
                      <option value="other">Other</option>
                    </select>
                  </div>
                </div>

                <div class="mb-3 row">
                  <label class="col-12 col-sm-4 col-form-label fw-bold">Address:</label>
                  <div class="col-12 col-sm-8">
                    <textarea class="form-control" name="address" rows="3" placeholder="Enter Address"></textarea>
                  </div>
                </div>

                <div class="mb-3 row">
                  <label class="col-12 col-sm-4 col-form-label fw-bold">Additional Notes:</label>
                  <div class="col-12 col-sm-8">
                    <textarea class="form-control" name="notes" rows="3" placeholder="Enter Additional Notes"></textarea>
                  </div>
                </div>
              </div>

              <!-- Health Status -->
              <h6 class="mb-3 mt-4">Patient's Health Status</h6>
              <div class="table table-bordered p-3 mb-4">
                <div class="mb-3 row">
                  <label class="col-12 col-sm-4 col-form-label fw-bold">Health Condition:</label>
                  <div class="col-12 col-sm-8">
                    <input type="text" class="form-control" name="health_status" placeholder="Enter Health Status" required>
                  </div>
                </div>

                <div class="mb-3 row">
                  <label class="col-12 col-sm-4 col-form-label fw-bold">Medications:</label>
                  <div class="col-12 col-sm-8">
                    <input type="text" class="form-control" name="medications" placeholder="Enter Medications">
                  </div>
                </div>
              </div>

              <!-- Emergency Contact -->
              <h6 class="mb-3 mt-4">Relative / Emergency Contact Details</h6>
              <div class="table table-bordered p-3 mb-4">
                <div class="mb-3 row">
                  <label class="col-12 col-sm-4 col-form-label fw-bold">Contact Name:</label>
                  <div class="col-12 col-sm-8">
                    <input type="text" class="form-control" name="emergency_contact_name" placeholder="Enter Emergency Contact Name" required>
                  </div>
                </div>

                <div class="mb-3 row">
                  <label class="col-12 col-sm-4 col-form-label fw-bold">Contact Number:</label>
                  <div class="col-12 col-sm-8">
                    <input type="text" class="form-control" name="emergency_contact_number" placeholder="Enter Emergency Contact Number" required>
                  </div>
                </div>

                <div class="mb-3 row">
                  <label class="col-12 col-sm-4 col-form-label fw-bold">Email Address:</label>
                  <div class="col-12 col-sm-8">
                    <input type="email" class="form-control" name="email_address" placeholder="Enter Email Address" required>
                  </div>
                </div>

                <div class="mb-3 row">
                  <label class="col-12 col-sm-4 col-form-label fw-bold">Relationship:</label>
                  <div class="col-12 col-sm-8">
                    <input type="text" class="form-control" name="relationship" placeholder="Enter Relationship" required>
                  </div>
                </div>
              </div>

              <input type="hidden" name="date_added" value="<?php echo date('Y-m-d'); ?>">

              <!-- Medical Terms -->
              <h6 class="mb-3 mt-4">Medical Terms & Conditions</h6>
              <div class="table table-bordered p-3 mb-3" style="max-height: 150px; overflow-y: auto; background: #f9f9f9;">
                <p>
                  By registering a patient, you agree to our clinic’s policies on medical care, privacy,
                  and patient data handling. The clinic may store and process medical information in
                  accordance with applicable laws. You confirm that the details provided are accurate
                  and that you have the authority to submit them.
                </p>
                <p>
                  In case of emergency, you authorize the assigned caregivers and medical staff to
                  provide necessary treatment as deemed appropriate.
                </p>
              </div>
              <div class="form-check mb-3">
                <input type="checkbox" class="form-check-input" id="agree" name="agree" value="1" required>
                <label class="form-check-label" for="agree">I have read and agree to the Medical Terms & Conditions.</label>
              </div>

              <div class="d-flex justify-content-center mt-4">
                <button type="submit" class="btn btn-primary w-50" name="add">Add Patient</button>
              </div>

            </form>
          </div>
        </div>
      </div>
    </div>
  </section>
</main>

<footer id="footer" class="footer">
  <div class="copyright">
    &copy; Copyright <strong><span>ElderlyCare</span></strong>. All Rights Reserved
  </div>
</footer>
<script>
  let residentId = null;

  function showUpdateModal(id) {
    residentId = id;
    const updateModal = new bootstrap.Modal(document.getElementById('updateModal'));
    updateModal.show();
  }

  document.getElementById('confirmUpdateButton').addEventListener('click', function () {
    if (residentId !== null) {
      // Logic for updating resident information
    }
  });
</script>


<!-- Template Main JS File -->
<script src="/elderlycare/assets/js/main.js"></script>
<script src="/elderlycare/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>
