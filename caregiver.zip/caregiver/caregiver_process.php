<?php
session_start(); 

include 'caregiver_dbconnection.php'; 

if (isset($_POST['add'])) {

    $caregiver_id = $_SESSION['user_id'];

        $count_query = "SELECT COUNT(*) AS patient_count FROM patients WHERE caregiver_id = ? AND status = 'approved'";
        $stmt_count = mysqli_prepare($conn, $count_query);
        mysqli_stmt_bind_param($stmt_count, 'i', $caregiver_id);
        mysqli_stmt_execute($stmt_count);
        $result_count = mysqli_stmt_get_result($stmt_count);
        $count_data = mysqli_fetch_assoc($result_count);
        mysqli_stmt_close($stmt_count);

        if ($count_data['patient_count'] >= 5) {
            echo "<script>alert('You have reached the maximum limit of 5 approved patients.'); window.location.href = 'patients_list.php';</script>";
            exit;
        }


    // Get room_id from form
    $room_id = $_POST['room_id'];

    // Proceed with file upload and data insert
    $patient_upload_dir = 'uploads/patients/';
    $patient_file = $_FILES['patient_image'];
    $patient_filename = time() . "_" . uniqid() . "_" . basename($patient_file['name']);
    $patient_target_file = $patient_upload_dir . $patient_filename;
    $patient_file_type = strtolower(pathinfo($patient_target_file, PATHINFO_EXTENSION));

    if ($patient_file['error'] === UPLOAD_ERR_OK) {
        if (in_array($patient_file_type, ['jpg', 'jpeg', 'png', 'gif'])) {
            if ($patient_file['size'] <= 5 * 1024 * 1024) {

                if (!file_exists($patient_upload_dir)) {
                    mkdir($patient_upload_dir, 0777, true);
                }

                if (move_uploaded_file($patient_file['tmp_name'], $patient_target_file)) {
                    $first_name = $_POST['first_name'];
                    $middle_name = $_POST['middle_name'];
                    $last_name = $_POST['last_name'];
                    $dob = $_POST['dob'];
                    $age = $_POST['age'];
                    $gender = $_POST['gender'];
                    $health_status = $_POST['health_status'];
                    $emergency_contact_name = $_POST['emergency_contact_name'];
                    $emergency_contact_number = $_POST['emergency_contact_number'];
                    $email_address = $_POST['email_address'];
                    $relationship = $_POST['relationship'];
                    $address = $_POST['address'];
                    $medications = $_POST['medications'];
                    $notes = $_POST['notes'];
                    $profile_picture = $patient_filename;

                    // Check if patient exists
                    $query_check = "SELECT * FROM patients WHERE first_name = ? AND last_name = ? AND dob = ?";
                    $stmt_check = mysqli_prepare($conn, $query_check);
                    mysqli_stmt_bind_param($stmt_check, 'sss', $first_name, $last_name, $dob);
                    mysqli_stmt_execute($stmt_check);
                    $result_check = mysqli_stmt_get_result($stmt_check);

                    if (mysqli_num_rows($result_check) > 0) {
                        echo "<script>alert('Patient already exists.'); window.location.href = 'add_patient.php';</script>";
                        exit;
                    }
                    mysqli_stmt_close($stmt_check);

                
                        $query = "INSERT INTO patients 
                        (caregiver_id, first_name, middle_name, last_name, dob, age, gender, health_status, emergency_contact_name, emergency_contact_number, email_address, relationship, address, medications, notes, profile_picture, date_added, terms_agreed, terms_agreed_at, room_id)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_DATE, ?, ?, ?)";




                        $stmt = mysqli_prepare($conn, $query);
                        if (!$stmt) {
                            die('Prepare failed: ' . mysqli_error($conn));
                        }

                        // Checkbox for terms
                        $terms_agreed = isset($_POST['agree']) ? 1 : 0;
                        $terms_agreed_at = $terms_agreed ? date('Y-m-d H:i:s') : null;

                        mysqli_stmt_bind_param(
                        $stmt, 
                        'issssissssssssssisi', 
                        $caregiver_id, 
                        $first_name, 
                        $middle_name, 
                        $last_name, 
                        $dob, 
                        $age,
                        $gender,
                        $health_status, 
                        $emergency_contact_name, 
                        $emergency_contact_number, 
                        $email_address, 
                        $relationship, 
                        $address, 
                        $medications, 
                        $notes, 
                        $profile_picture,
                        $terms_agreed,
                        $terms_agreed_at,
                        $room_id // <-- your room_id here
                    );




                    if (mysqli_stmt_execute($stmt)) {
                        $patient_id = mysqli_insert_id($conn);

                    $query_patient_name = "SELECT CONCAT(first_name, ' ', IFNULL(middle_name, ''), ' ', last_name) AS full_name FROM patients WHERE id = ?";
                    $stmt_patient = mysqli_prepare($conn, $query_patient_name);
                    mysqli_stmt_bind_param($stmt_patient, 'i', $patient_id);
                    mysqli_stmt_execute($stmt_patient);
                    $result_patient = mysqli_stmt_get_result($stmt_patient);
                    $patient_data = mysqli_fetch_assoc($result_patient);
                    mysqli_stmt_close($stmt_patient);

                    $patient_name = $patient_data['full_name'] ?? '';

                    // Fetch caregiver full name
                    $cg_q = mysqli_query($conn, "SELECT full_name FROM caregivers_info WHERE caregiver_id = $caregiver_id");
                    $cg_data = mysqli_fetch_assoc($cg_q);
                    $caregiver_name = $cg_data['full_name'] ?? '';


                        $cg_q = mysqli_query($conn, "SELECT full_name FROM caregivers_info WHERE caregiver_id = $caregiver_id");
                        $cg_data = mysqli_fetch_assoc($cg_q);
                        $caregiver_name = $cg_data['full_name'];

                        $notif_message = "New patient \"$first_name $last_name\" added by caregiver $caregiver_name that needs your approval";
                        $notif_user_type = 'caregiver';
                        $notif_query = "INSERT INTO admin_notifications (type, reference_id, message, user_type) 
                                        VALUES ('new_patient', ?, ?, ?)";
                        $notif_stmt = mysqli_prepare($conn, $notif_query);
                        mysqli_stmt_bind_param($notif_stmt, "iss", $patient_id, $notif_message, $notif_user_type);
                        mysqli_stmt_execute($notif_stmt);
                        mysqli_stmt_close($notif_stmt);

                        echo "<script>
                                alert('New Patient request submitted successfully, waiting for admin\'s approval');
                                window.location.href = 'patients_list.php';
                              </script>";
                    } else {
                        echo "<script>alert('Error submitting new patient request.'); window.location.href = 'add_patient.php';</script>";
                    }
                    mysqli_stmt_close($stmt);
                } else {
                    echo "<script>alert('Failed uploading the patient image.'); window.location.href = 'add_patient.php';</script>";
                }
            } else {
                echo "<script>alert('File is too large. Maximum allowed size is 5MB.'); window.location.href = 'add_patient.php';</script>";
            }
        } else {
            echo "<script>alert('Only image files (jpg, jpeg, png, gif) are allowed.'); window.location.href = 'add_patient.php';</script>";
        }
    } else {
        echo "<script>alert('Error uploading file. Error code: " . $patient_file['error'] . "'); window.location.href = 'add_patient.php';</script>";
    }
}




if (isset($_POST['mark_as_read'])) {
   
    mysqli_query($conn, "UPDATE admin_notifications SET is_read = 1 WHERE is_read = 0");
}



if (isset($_POST['submit'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $query = "SELECT * FROM caregivers WHERE email = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "s", $email);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if (mysqli_num_rows($result) > 0) {
        $user = mysqli_fetch_assoc($result);

        if ($user['status'] !== 'Approved') {
            $_SESSION['message'] = "Your account is not yet approved. Please wait for admin approval.";
            header("Location: /elderlycare/templates/caregiver/userLogin.php");
            exit;
        }

        if (password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['email'] = $user['email'];
            $_SESSION['message'] = "Logged in successfully!";
            header("Location: /elderlycare/templates/caregiver/CaregiverDashboard.php");
            exit;
        } else {
            $_SESSION['message'] = "Incorrect password. Please try again.";
            header("Location: /elderlycare/templates/caregiver/userLogin.php");
            exit;
        }
    } else {
        $_SESSION['message'] = "No account found with that email.";
        header("Location: /elderlycare/templates/caregiver/userLogin.php");
        exit;
    }
}






if (isset($_POST['update_patient'])) {
    $id = $_POST['patient_id'];
    $first_name = $_POST['first_name'];
    $middle_name = $_POST['middle_name'];
    $last_name = $_POST['last_name'];
    $dob = $_POST['dob'];
    $health_status = $_POST['health_status'];
    $emergency_contact_name = $_POST['emergency_contact_name'];
    $address = $_POST['address'];
    $medications = $_POST['medications'];
    $notes = $_POST['notes'];


    if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] === UPLOAD_ERR_OK) {
        $upload_dir = 'uploads/patients/';
        $original_name = basename($_FILES['profile_picture']['name']);
        $new_filename = time() . '_' . $original_name;
        $target_file = $upload_dir . $new_filename;

        if (move_uploaded_file($_FILES['profile_picture']['tmp_name'], $target_file)) {
            $query = "UPDATE patients 
                      SET first_name = ?, middle_name = ?, last_name = ?, dob = ?, health_status = ?, 
                          emergency_contact_name = ?, address = ?, medications = ?, notes = ?, profile_picture = ?
                      WHERE id = ?";
            $stmt = mysqli_prepare($conn, $query);
            mysqli_stmt_bind_param($stmt, 'ssssssssssi', $first_name, $middle_name, $last_name, $dob, $health_status, $emergency_contact_name, $address, $medications, $notes, $new_filename, $id);
        } else {
            echo "Failed to upload profile picture.";
            exit;
        }
    } else {
      
        $query = "UPDATE patients 
                  SET first_name = ?, middle_name = ?, last_name = ?, dob = ?, health_status = ?, 
                      emergency_contact_name = ?, address = ?, medications = ?, notes = ?
                  WHERE id = ?";
        $stmt = mysqli_prepare($conn, $query);
        mysqli_stmt_bind_param($stmt, 'sssssssssi', $first_name, $middle_name, $last_name, $dob, $health_status, $emergency_contact_name, $address, $medications, $notes, $id);
    }

    if (mysqli_stmt_execute($stmt)) {
        header("Location: patients_list.php?updated=1");
        exit;
    } else {
        echo "Error updating patient: " . mysqli_error($conn);
    }
}
if (isset($_GET['id']) && !isset($_POST['submitvital'])) { 
    $patient_id = $_GET['id'];

    // First find the room(s) linked to this patient
    $roomQuery = "SELECT id FROM rooms WHERE patient_id = ?";
    if ($roomStmt = $conn->prepare($roomQuery)) {
        $roomStmt->bind_param("i", $patient_id);
        $roomStmt->execute();
        $roomResult = $roomStmt->get_result();

        // Store all affected room ids
        $roomIds = [];
        while ($roomRow = $roomResult->fetch_assoc()) {
            $roomIds[] = $roomRow['id'];
        }
        $roomStmt->close();
    }

    // Delete patient record
    $query = "DELETE FROM patients WHERE id = ?";
    if ($stmt = $conn->prepare($query)) {
        $stmt->bind_param("i", $patient_id);
        $stmt->execute();

        if ($stmt->affected_rows > 0) {
            // Update all rooms related to this patient
            $updateRoomQuery = "UPDATE rooms SET status = 'Available', caregiver_id = NULL, caregivers_name = NULL, patient_name = NULL, patient_id = NULL WHERE id = ?";
            if ($updateRoomStmt = $conn->prepare($updateRoomQuery)) {
                foreach ($roomIds as $roomId) {
                    $updateRoomStmt->bind_param("i", $roomId);
                    $updateRoomStmt->execute();
                }
                $updateRoomStmt->close();
            }

            $caregiver_id = $_SESSION['user_id'];

            // Get caregiver name
            $caregiver_name = "Unknown";
            $caregiverQuery = "SELECT full_name FROM caregivers_info WHERE caregiver_id = ?";
            if ($caregiverStmt = $conn->prepare($caregiverQuery)) {
                $caregiverStmt->bind_param("i", $caregiver_id);
                $caregiverStmt->execute();
                $caregiverResult = $caregiverStmt->get_result();
                if ($caregiverRow = $caregiverResult->fetch_assoc()) {
                    $caregiver_name = $caregiverRow['full_name'];
                }
                $caregiverStmt->close();
            }

            // Notification details
            $notifMessage = "Caregiver '$caregiver_name' deleted a patient record (Patient ID: $patient_id).";
            $notifType = "deleted_patient";
            $reference_id = $patient_id; 

            $notifQuery = "INSERT INTO admin_notifications (message, type, reference_id, is_read, created_at) 
                           VALUES (?, ?, ?, 0, NOW())";
            if ($notifStmt = $conn->prepare($notifQuery)) {
                $notifStmt->bind_param("ssi", $notifMessage, $notifType, $reference_id);
                $notifStmt->execute();
                $notifStmt->close();
            }

            header("Location: patients_list.php");
            exit;
        } else {
            echo "Error: Patient could not be deleted.";
        }

        $stmt->close();
    } else {
        echo "Error preparing statement.";
    }
}


//edit vitals signs

if (isset($_POST['update_vital'])) {
    
    $id = $_POST['id'];
    $blood_pressure = $_POST['blood_pressure'];
    $heart_rate = $_POST['heart_rate'];
    $temperature = $_POST['temperature'];
    $respiration_rate = $_POST['respiration_rate'];
    $pulse_rate = $_POST['pulse_rate'];
    $oxygen_saturation = $_POST['oxygen_saturation'];
    $notes = $_POST['notes'];

    $query = "UPDATE vital_signs SET blood_pressure = ?, heart_rate = ?, temperature = ?, respiration_rate = ?, pulse_rate = ?, oxygen_saturation = ?, notes = ? WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("sssssssi", $blood_pressure, $heart_rate, $temperature, $respiration_rate, $pulse_rate, $oxygen_saturation, $notes, $id);

 if ($stmt->execute()) {
    echo "<script>
            alert('Vital signs updated successfully!');
            window.location.href = 'vital_signs.php';
          </script>";
    exit;
} else {
    echo "<script>
            alert('Error updating record: " . addslashes($conn->error) . "');
            window.history.back();
          </script>";
    exit;
}
}


if (isset($_POST['deleteVital'])) {
    $id = intval($_POST['deleteVital']);

    $stmt = $conn->prepare("DELETE FROM vital_signs WHERE id = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        echo "<script>
                alert('Record deleted successfully!');
                window.location.href = 'vital_signs.php';
              </script>";
        exit;
    } else {
        echo "<script>
                alert('Error deleting record: " . addslashes($conn->error) . "');
                window.history.back();
              </script>";
        exit;
    }
}



use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

function sendEmailToRelative($relative_email, $subject, $message) {
    require_once __DIR__ . '/../../vendor/autoload.php';

    if (!isset($_ENV['EMAIL_USER'])) {
        $dotenv = Dotenv\Dotenv::createImmutable(__DIR__ . '/../../');
        $dotenv->load();
    }

    $mail = new PHPMailer(true);

    try {
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = $_ENV['EMAIL_USER'];
        $mail->Password   = $_ENV['EMAIL_PASS'];
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;

        $mail->setFrom($_ENV['EMAIL_USER'], 'Elderly Care System');
        $mail->addAddress($relative_email);
        $mail->Subject = $subject;
        $mail->Body    = $message;

        $mail->send();
    } catch (Exception $e) {
        error_log("Email failed to send: " . $mail->ErrorInfo);
    }
}




if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submitvital'])) {

    if (!empty($_POST['patient_id'])) {
        $patient_id = $_POST['patient_id'];
        $blood_pressure = $_POST['blood_pressure'];
        $heart_rate = $_POST['heart_rate'];
        $temperature = $_POST['temperature'];
        $respiration_rate = $_POST['respiration_rate'];
        $pulse_rate = $_POST['pulse_rate'];
        $oxygen_saturation = $_POST['oxygen_saturation'];
        $notes = isset($_POST['notes']) ? $_POST['notes'] : '';  

        $caregiver_id = $_SESSION['user_id']; 

        $query = "SELECT * FROM patients WHERE id = ? AND caregiver_id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("ii", $patient_id, $caregiver_id);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            
            $insertQuery = "INSERT INTO vital_signs 
                (patient_id, caregiver_id, blood_pressure, heart_rate, temperature, respiration_rate, pulse_rate, oxygen_saturation, notes)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

            $stmt = $conn->prepare($insertQuery);
            $stmt->bind_param("iisssssss", $patient_id, $caregiver_id, $blood_pressure, $heart_rate, $temperature, $respiration_rate, $pulse_rate, $oxygen_saturation, $notes);

            if ($stmt->execute()) {
               
                $notif_message = "New vital signs recorded for your relative.";
                $notif_type = "vital";
                $date_now = date('Y-m-d H:i:s');

                $relative_query = "SELECT id FROM relatives WHERE patient_id = ?";
                $relative_stmt = $conn->prepare($relative_query);
                $relative_stmt->bind_param("i", $patient_id);
                $relative_stmt->execute();
                $relative_result = $relative_stmt->get_result();

                if ($relative_result->num_rows > 0) {
                    $relative_row = $relative_result->fetch_assoc();
                    $relative_id = $relative_row['id'];

                    $insert_notif = $conn->prepare("INSERT INTO relative_notification (relative_id, patient_id, message, date) VALUES (?, ?, ?, NOW())");
                    $insert_notif->bind_param("iis", $relative_id, $patient_id, $notif_message);
                    $insert_notif->execute();

                    $relative_email_query = $conn->prepare("SELECT email FROM relatives WHERE id = ?");
                    $relative_email_query->bind_param("i", $relative_id);
                    $relative_email_query->execute();
                    $email_result = $relative_email_query->get_result();

                    if ($email_result->num_rows > 0) {
                        $email_row = $email_result->fetch_assoc();
                        $email = $email_row['email'];

                        $subject = "Vital Signs Update";
                        $body = "New vital signs recorded for your relative:\n\n
                        Blood Pressure: $blood_pressure\nHeart Rate: $heart_rate\nTemperature: $temperature\nRespiration Rate: $respiration_rate\nPulse Rate: $pulse_rate\nOxygen Saturation: $oxygen_saturation\n\nNotes: $notes";

                        sendEmailToRelative($email, $subject, $body);
                    }
                }


                echo "<script>
                        alert('Vital signs saved successfully!');
                        window.location.href = 'vital_signs.php';
                    </script>";
            } else {
                echo "<script>alert('Error inserting vital signs.');</script>";
            }

        } else {
            echo "<script>alert('Caregiver is not assigned to this patient.');</script>";
        }
    } else {
        echo "<script>alert('Missing patient ID.');</script>";
    }
}




if (isset($_SESSION['user_id']) && isset($_POST['add_appointment'])) {
    $user_id = $_SESSION['user_id']; 
    $patient_id = $_POST['patient_id'];
    $appointment_date = $_POST['appointment_date'];
    $appointment_time = $_POST['appointment_time'];
    $appointment_purpose = $_POST['appointment_purpose'];

    $stmt = $conn->prepare("SELECT full_name FROM caregivers_info WHERE caregiver_id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $caregiver_full_name = $stmt->get_result()->fetch_assoc()['full_name'] ?? '';

    $stmt = $conn->prepare("SELECT first_name, middle_name, last_name FROM patients WHERE id = ?");
    $stmt->bind_param("i", $patient_id);
    $stmt->execute();
    $p = $stmt->get_result()->fetch_assoc();
    $patient_full_name = $p['first_name'] . ' ' . $p['middle_name'] . ' ' . $p['last_name'];

    $stmt = $conn->prepare("INSERT INTO appointments (caregiver_id, patient_id, appointment_date, appointment_time, title, caregiver_full_name, patient_full_name) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("iisssss", $user_id, $patient_id, $appointment_date, $appointment_time, $appointment_purpose, $caregiver_full_name, $patient_full_name);

    if ($stmt->execute()) {
        $notif_message = "A new appointment \"$appointment_purpose\" has been scheduled for $patient_full_name on $appointment_date at $appointment_time.";

        $relatives = $conn->prepare("SELECT id, email FROM relatives WHERE patient_id = ?");
        $relatives->bind_param("i", $patient_id);
        $relatives->execute();
        $result = $relatives->get_result();

        $notif_stmt = $conn->prepare("INSERT INTO relative_notification (relative_id, patient_id, message, is_read, created_at, date) VALUES (?, ?, ?, 0, NOW(), NOW())");

        while ($rel = $result->fetch_assoc()) {
            $relative_id = $rel['id'];
            $email = $rel['email'];

            $notif_stmt->bind_param("iis", $relative_id, $patient_id, $notif_message);
            $notif_stmt->execute();

            $subject = "New Appointment Scheduled";
            $body = $notif_message;
            sendEmailToRelative($email, $subject, $body);
        }

        echo "<script>
            alert('Appointment successfully added!');
            window.location.href = 'CaregiverDashboard.php';
        </script>";
    } else {
        echo "Error: " . $stmt->error;
    }
    exit;
}







//for task
if (!isset($_SESSION['user_id'])) {
    header('Location: /elderlycare/templates/caregiver/userLogin.php');
    exit;
}

if (isset($_POST['submitTask'])) {
    $caregiver_id = $_SESSION['user_id'];
    $patient_id = $_POST['patient_id'] ?? null;
    $task_description = $_POST['task_description'] ?? '';
    $routine_time = !empty($_POST['routine_time']) ? $_POST['routine_time'] : null;
    $frequency = $_POST['frequency'] ?? 'Daily';
    $task_date = date('Y-m-d');

    if (!$patient_id || !$task_description) {
        header('Location: task_and_notes.php?error=missing_fields');
        exit;
    }

    $stmt = $conn->prepare("INSERT INTO patient_tasks (caregiver_id, patient_id, task_description, routine_time, frequency, task_date) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("iissss", $caregiver_id, $patient_id, $task_description, $routine_time, $frequency, $task_date);


    if ($stmt->execute()) {
        // Get patient name
        $stmt = $conn->prepare("SELECT first_name, middle_name, last_name FROM patients WHERE id = ?");
        $stmt->bind_param("i", $patient_id);
        $stmt->execute();
        $p = $stmt->get_result()->fetch_assoc();
        $full_name = $p['first_name'] . ' ' . $p['middle_name'] . ' ' . $p['last_name'];

        $notif_message = "A new task \"$task_description\" has been assigned to $full_name. Routine: $routine_time | Frequency: $frequency";

        // Fetch relatives
        $rel_stmt = $conn->prepare("SELECT id, email FROM relatives WHERE patient_id = ?");
        $rel_stmt->bind_param("i", $patient_id);
        $rel_stmt->execute();
        $relatives = $rel_stmt->get_result();

        $notif_stmt = $conn->prepare("INSERT INTO relative_notification (relative_id, patient_id, message, is_read, created_at, date) VALUES (?, ?, ?, 0, NOW(), NOW())");

        while ($r = $relatives->fetch_assoc()) {
            $relative_id = $r['id'];
            $email = $r['email'];

            $notif_stmt->bind_param("iis", $relative_id, $patient_id, $notif_message);
            $notif_stmt->execute();

           $subject = "New Task Assigned";
            $body = $notif_message;
            sendEmailToRelative($email, $subject, $body);

        }

        header('Location: task_and_notes.php?success=task_added');
        exit;
    }
}

//edit task
if (isset($_POST['updateTask'])) {
    $task_id = isset($_POST['task_id']) ? intval($_POST['task_id']) : 0;
    $task_description = isset($_POST['task_description']) ? trim($_POST['task_description']) : '';
    $routine_time = isset($_POST['routine_time']) && $_POST['routine_time'] !== '' ? $_POST['routine_time'] : null;
    $frequency = isset($_POST['frequency']) ? $_POST['frequency'] : 'Daily';

    if ($task_id > 0) {
        $stmt = $conn->prepare("
            UPDATE patient_tasks 
            SET task_description = ?, routine_time = ?, frequency = ?
            WHERE id = ?
        ");
        if ($stmt) {
            $stmt->bind_param("sssi", $task_description, $routine_time, $frequency, $task_id);
            $stmt->execute();
            $stmt->close();

            header("Location: task_and_notes.php");
            exit;
        } else {
            echo "Failed to prepare statement: " . $conn->error;
        }
    } else {
        echo "Invalid task ID.";
    }
}

//delete task 

if (isset($_POST['deleteTask'])) {
    $task_id = isset($_POST['task_id']) ? intval($_POST['task_id']) : 0;
    if ($task_id > 0) {
        $stmt = $conn->prepare("DELETE FROM patient_tasks WHERE id = ?");
        if ($stmt) {
            $stmt->bind_param("i", $task_id);
            $stmt->execute();
            $stmt->close();

            header("Location: task_and_notes.php");
            exit;
        } else {
            echo "Failed to prepare delete statement: " . $conn->error;
        }
    } else {
        echo "Invalid task ID for deletion.";
    }
}



//for Medicines
if (!isset($_SESSION['user_id'])) {
    header('Location: /elderlycare/templates/caregiver/userLogin.php');
    exit;
}
if (isset($_POST['submitMedicine'])) {
    $caregiver_id = $_SESSION['user_id'];
    $patient_id = $_POST['patient_id'] ?? null;
    $medicine_name = $_POST['medicine_name'] ?? '';
    $dosage = $_POST['dosage'] ?? '';
    $time_to_take = $_POST['time_to_take'] ?? null; 
    $notes = $_POST['notes'] ?? null; 

    if (!$patient_id || !$medicine_name || !$dosage) {
        header('Location: task_and_notes.php?error=missing_fields');
        exit;
    }

    $query = "INSERT INTO patient_medicines (caregiver_id, patient_id, medicine_name, dosage, time_to_take, notes) 
              VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "iissss", $caregiver_id, $patient_id, $medicine_name, $dosage, $time_to_take, $notes);

    if (mysqli_stmt_execute($stmt)) {
        
        $notif_msg = "New medicine added: $medicine_name ($dosage) for patient ID $patient_id";

        $notif_insert = $conn->prepare("INSERT INTO admin_notifications (user_id, type, reference_id, message, user_type, is_read, created_at) VALUES (?, 'medicine', ?, ?, 'caregiver', 0, NOW())");
        $notif_insert->bind_param("iis", $caregiver_id, $patient_id, $notif_msg);
        $notif_insert->execute();
        $notif_insert->close();

        
        $rel_stmt = $conn->prepare("SELECT id FROM relatives WHERE patient_id = ?");
        $rel_stmt->bind_param("i", $patient_id);
        $rel_stmt->execute();
        $rel_stmt->bind_result($relative_id);
        if ($rel_stmt->fetch()) {
            $rel_stmt->close();

            $notif_msg_rel = "New medicine added for your loved one: Med Name: $medicine_name Dosage:($dosage)";
            $notif_stmt = $conn->prepare("INSERT INTO relative_notification (relative_id, message, is_read, created_at) VALUES (?, ?, 0, NOW())");
            $notif_stmt->bind_param("is", $relative_id, $notif_msg_rel);
            $notif_stmt->execute();
            $notif_stmt->close();

            $email_stmt = $conn->prepare("SELECT email FROM relatives WHERE id = ?");
            $email_stmt->bind_param("i", $relative_id);
            $email_stmt->execute();
            $email_stmt->bind_result($relative_email);
            if ($email_stmt->fetch()) {
                sendEmailToRelative($relative_email, "New Medicine Added for Your Loved One", $notif_msg_rel);
            }
            $email_stmt->close();
        }

        header('Location: task_and_notes.php?success=medicine_added');
        exit;
    } else {
        header('Location: task_and_notes.php?error=db_error');
        exit;
    }
}

//to edit medicines
if (isset($_POST['update_medicine'])) {
    $id = isset($_POST['id']) ? intval($_POST['id']) : 0;
    $medicine_name = isset($_POST['medicine_name']) ? trim($_POST['medicine_name']) : '';
    $dosage = isset($_POST['dosage']) ? trim($_POST['dosage']) : '';
    $time_to_take = isset($_POST['time_to_take']) && $_POST['time_to_take'] !== '' ? $_POST['time_to_take'] : null;
    $notes = isset($_POST['notes']) ? trim($_POST['notes']) : '';

    if ($id > 0 && $medicine_name !== '') {
        $stmt = $conn->prepare("UPDATE patient_medicines SET medicine_name = ?, dosage = ?, time_to_take = ?, notes = ? WHERE id = ?");
        if ($stmt) {
            $stmt->bind_param("ssssi", $medicine_name, $dosage, $time_to_take, $notes, $id);
            $stmt->execute();

            if ($stmt->affected_rows > 0) {
                $stmt->close();
                header("Location: task_and_notes.php");
                exit;
            } else {
                echo "No changes made or invalid medicine ID.";
            }
        } else {
            echo "Prepare failed: " . $conn->error;
        }
    } else {
        echo "Invalid medicine ID or medicine name.";
    }
}



//delete medicine
if (isset($_POST['delete_medicine'])) {
    $medicine_id = isset($_POST['medicine_id']) ? intval($_POST['medicine_id']) : 0;

    if ($medicine_id > 0) {
        $stmt = $conn->prepare("DELETE FROM patient_medicines WHERE id = ?");
        if ($stmt) {
            $stmt->bind_param("i", $medicine_id);
            $stmt->execute();

            if ($stmt->affected_rows > 0) {
                $stmt->close();
                header("Location: task_and_notes.php");
                exit;
            } else {
                echo "Medicine not found or already deleted.";
            }
        } else {
            echo "Failed to prepare delete statement: " . $conn->error;
        }
    } else {
        echo "Invalid medicine ID.";
    }
}



///Caregiver///


if (isset($_POST['updateCaregiverprofile'])) {
    $caregiver_id = $_POST['caregiver_id'];
    $full_name = trim($_POST['full_name']);
    $contact_phone = trim($_POST['contact_phone']);
    $address = trim($_POST['address']);
    $email = trim($_POST['email']);
    $removeImage = isset($_POST['remove_image']) && $_POST['remove_image'] == '1';

    $getImageQuery = mysqli_query($conn, "SELECT pic FROM caregivers_info WHERE caregiver_id = $caregiver_id");
    $current = mysqli_fetch_assoc($getImageQuery);
    $currentPic = $current['pic'] ?? '';
    $newPic = $currentPic;

    if ($removeImage) {
        if (!empty($currentPic) && file_exists("uploads/caregivers/$currentPic")) {
            unlink("uploads/caregivers/$currentPic");
        }
        $newPic = ''; 
    }

    if (isset($_FILES['caregiver_pic']) && $_FILES['caregiver_pic']['error'] === UPLOAD_ERR_OK) {
        $fileTmpPath = $_FILES['caregiver_pic']['tmp_name'];
        $fileName = $_FILES['caregiver_pic']['name'];
        $fileExt = pathinfo($fileName, PATHINFO_EXTENSION);
        $allowedExts = ['jpg', 'jpeg', 'png', 'gif', 'webp'];

        if (in_array(strtolower($fileExt), $allowedExts)) {
            $newPicName = uniqid('cg_', true) . '.' . $fileExt;
            $uploadDir = 'uploads/caregivers/';
            move_uploaded_file($fileTmpPath, $uploadDir . $newPicName);

            if (!empty($currentPic) && file_exists($uploadDir . $currentPic)) {
                unlink($uploadDir . $currentPic);
            }

            $newPic = $newPicName;
        } else {
            echo "<script>alert('Invalid image file type.'); window.location.href = 'caregiver_profile.php';</script>";
            exit;
        }
    }

    $infoUpdate = "UPDATE caregivers_info 
                   SET full_name = ?, contact_phone = ?, address = ?, pic = ?
                   WHERE caregiver_id = ?";
    $stmtInfo = mysqli_prepare($conn, $infoUpdate);
    mysqli_stmt_bind_param($stmtInfo, 'ssssi', $full_name, $contact_phone, $address, $newPic, $caregiver_id);
    $infoSuccess = mysqli_stmt_execute($stmtInfo);

    $emailUpdate = "UPDATE caregivers SET email = ? WHERE id = ?";
    $stmtEmail = mysqli_prepare($conn, $emailUpdate);
    mysqli_stmt_bind_param($stmtEmail, 'si', $email, $caregiver_id);
    $emailSuccess = mysqli_stmt_execute($stmtEmail);

    if ($infoSuccess && $emailSuccess) {
        echo "<script>
                alert('Profile updated successfully.');
                window.location.href = 'caregiver_profile.php';
              </script>";
    } else {
        echo "<script>
                alert('Error updating profile.');
                window.location.href = 'caregiver_profile.php';
              </script>";
    }

    mysqli_stmt_close($stmtInfo);
    mysqli_stmt_close($stmtEmail);
    mysqli_close($conn);
}

else if (isset($_POST['changeCaregiverPassword'])) {
    $caregiver_id = $_POST['caregiver_id'];
    $currentpassword = $_POST['currentpassword'];
    $newpassword = $_POST['newpassword'];
    $confirmpassword = $_POST['confirmpassword'];

    $stmt = $conn->prepare("SELECT password FROM caregivers WHERE id = ?");
    $stmt->bind_param("i", $caregiver_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $result->num_rows === 1) {
        $row = $result->fetch_assoc();
        $hashedPassword = $row['password'];

        if (password_verify($currentpassword, $hashedPassword)) {
            if ($newpassword === $confirmpassword) {
                
                $newHashed = password_hash($newpassword, PASSWORD_BCRYPT);

                $updateStmt = $conn->prepare("UPDATE caregivers SET password = ? WHERE id = ?");
                $updateStmt->bind_param("si", $newHashed, $caregiver_id);

                if ($updateStmt->execute()) {
                        session_unset();
                        session_destroy();
                    echo "<script>alert('Password changed successfully. Please Login again!'); window.location.href='userLogin.php';</script>";
                    exit;
                } else {
                    echo "<script>alert('Failed to update password'); window.location.href='caregiver_profile.php';</script>";
                    exit;
                }
            } else {
                echo "<script>alert('New passwords do not match'); window.location.href='caregiver_profile.php';</script>";
                exit;
            }
        } else {
            echo "<script>alert('Current password is incorrect'); window.location.href='caregiver_profile.php';</script>";
            exit;
        }
    } else {
        echo "<script>alert('Caregiver not found'); window.location.href='caregiver_profile.php';</script>";
        exit;
    }
}



if (isset($_POST['action']) && $_POST['action'] === 'verify_sensitive_panel_password') {


    if (!isset($_SESSION['user_id'])) {
        echo json_encode(['success' => false, 'message' => 'Not logged in']);
        exit;
    }

    $user_id = $_SESSION['user_id'];
    $password = $_POST['password'] ?? '';

    $query = "SELECT password FROM caregivers WHERE id = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, 'i', $user_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $row = mysqli_fetch_assoc($result);

    if ($row && password_verify($password, $row['password'])) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Invalid password']);
    }
    exit;
}


?>






