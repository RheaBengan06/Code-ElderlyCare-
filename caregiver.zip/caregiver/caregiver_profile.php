<?php
session_start();

header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

include 'caregiver_dbconnection.php'; 


if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id']; 
    $email = $_SESSION['email'];
    $caregiver_id = $user_id;

    if (isset($_GET['notif_id'])) {
        $notif_id = (int)$_GET['notif_id'];

        $updateQuery = "UPDATE admin_notifications SET is_read = 1 WHERE id = ?";
        $stmt = mysqli_prepare($conn, $updateQuery);
        mysqli_stmt_bind_param($stmt, 'i', $notif_id);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        $typeQuery = "SELECT type, reference_id FROM admin_notifications WHERE id = ?";
        $stmtType = mysqli_prepare($conn, $typeQuery);
        mysqli_stmt_bind_param($stmtType, 'i', $notif_id);
        mysqli_stmt_execute($stmtType);
        mysqli_stmt_bind_result($stmtType, $type, $reference_id);

        if (mysqli_stmt_fetch($stmtType)) {
            
            mysqli_stmt_close($stmtType);

            if ($type === 'medicine') {
                
                header("Location: task_and_notes.php?id=" . urlencode($reference_id));
                exit;
            } else {
                
                header("Location: password_verify.php");
                exit;
            }
        } else {
            
            mysqli_stmt_close($stmtType);
            header("Location: password_verify.php");
            exit;
        }
    }


    $notifQuery = "SELECT * FROM admin_notifications 
    WHERE user_id = ? AND user_type = 'caregiver' 
    ORDER BY created_at DESC";
    $stmt = mysqli_prepare($conn, $notifQuery);
    mysqli_stmt_bind_param($stmt, 'i', $user_id);
    mysqli_stmt_execute($stmt);
    $notifResult = mysqli_stmt_get_result($stmt);

    $notifications = [];
    while ($row = mysqli_fetch_assoc($notifResult)) {
    $notifications[] = $row;
    }

} else {
    echo "<script>
        alert('Please log in first');
        window.location.href = '/elderlycare/index.php';
    </script>";
    exit;
}

$caregiverQuery = "
    SELECT ci.*, c.email, c.password 
    FROM caregivers_info ci
    JOIN caregivers c ON ci.caregiver_id = c.id
    WHERE ci.caregiver_id = ?
";

$stmt = mysqli_prepare($conn, $caregiverQuery);
mysqli_stmt_bind_param($stmt, 'i', $user_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$caregiver = mysqli_fetch_assoc($result);


?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Caregiver's Profile</title>

<!-- Favicons -->
<link href="/elderlycare/assets/img/logo.png" rel="icon">


<!-- Google Fonts -->
<link href="https://fonts.gstatic.com" rel="preconnect">
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

<!-- Vendor CSS Files -->
<link href="/elderlycare/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/quill/quill.snow.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/quill/quill.bubble.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/remixicon/remixicon.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/simple-datatables/style.css" rel="stylesheet">

<!-- Template Main CSS File -->
<link href="/elderlycare/assets/css/style.css" rel="stylesheet">

</head>
<style>
  .notification-item.unread {
  background-color: #f0f8ff;
}
.notification-item.unread p {
  font-weight: bold;
}
.notifications {
  max-height: 300px; 
  overflow-y: auto;  
}
@media (max-width: 576px), (max-width: 780px) {
    .dropdown-menu.profile {
        position: fixed !important;
        top: 60px;
        left: 0 !important;
        right: 0 !important;
        border-radius: 0;
        z-index: 1050;
    }
}

@media (max-width: 576px) {
    .dropdown-menu.notifications {
        position: fixed !important;
        top: 60px;
        left: 0 !important;
        right: 0 !important;
        width: 100vw !important;
        max-width: none !important;
        border-radius: 0;
        z-index: 1050;
    }
}
</style>
<body>

<header id="header" class="header fixed-top d-flex align-items-center">

<div class="d-flex align-items-center justify-content-between">
  <a href="CaregiverDashboard.php" class="logo d-flex align-items-center">
  <img src="/elderlycare/assets/img/logo.png" alt="Logo">
    <span class="d-none d-lg-block">ElderlyCare</span>
  </a>
  <i class="bi bi-list toggle-sidebar-btn"></i>
</div>


<nav class="header-nav ms-auto">
  <ul class="d-flex align-items-center">

    <li class="nav-item dropdown">
        <a class="nav-link nav-icon" href="#" data-bs-toggle="dropdown">
          <i class="bi bi-bell"></i>
          <?php
          $unreadQuery = "SELECT COUNT(*) AS unread_count FROM admin_notifications WHERE user_id = ? AND user_type = 'admin' AND is_read = 0";
          $stmt = mysqli_prepare($conn, $unreadQuery);
          mysqli_stmt_bind_param($stmt, 'i', $user_id);
          mysqli_stmt_execute($stmt);
          $result = mysqli_stmt_get_result($stmt);
          $unread_count = mysqli_fetch_assoc($result)['unread_count'];
          ?>
          <?php if ($unread_count > 0): ?>
            <span class="badge bg-primary badge-number"><?= $unread_count; ?></span>
          <?php endif; ?>
        </a><!-- End Notification Icon -->

        <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow notifications">
         <li class="dropdown-header">
          <span>
            You have <?= $unread_count; ?> new notification<?= $unread_count !== 1 ? 's' : ''; ?>
          </span>
          <?php if ($unread_count > 0): ?>
            <div class="mt-2">
              <form method="POST">
                <button type="submit" name="markAllRead"  class="btn" style="font-size: 13px; height: 35px;">
                  Mark all as read
                </button>
              </form>
            </div>
          <?php endif; ?>
        </li>

          <li><hr class="dropdown-divider"></li>

          <?php if (count($notifications) > 0): ?>
            <?php foreach ($notifications as $note):
              $liClass = $note['is_read'] == 0 ? 'notification-item unread' : 'notification-item';
            ?>
              <li class="<?= $liClass ?>">
                <a href="?notif_id=<?= $note['id']; ?>" class="d-flex align-items-start text-decoration-none">
                  <i class="bi bi-info-circle text-info me-2"></i>
                  <div>
                    <p class="mb-1"><?= htmlspecialchars($note['message']); ?></p>
                    <small class="text-muted"><?= date("M d, Y H:i", strtotime($note['created_at'])); ?></small>
                  </div>
                </a>
              </li>
              <li><hr class="dropdown-divider"></li>
            <?php endforeach; ?>
          <?php else: ?>
            <li class="notification-item text-center">
              <p>No new notifications</p>
            </li>
          <?php endif; ?>
        </ul>
      </li><!-- End Notification Nav -->




      <!-- Profile Menu -->
    
    <?php
    include 'caregiver_dbconnection.php'; 

    $caregiverInfoQuery = "SELECT pic, full_name FROM caregivers_info WHERE caregiver_id = ?";
    $stmt = mysqli_prepare($conn, $caregiverInfoQuery);
    mysqli_stmt_bind_param($stmt, 'i', $user_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $caregiverInfo = mysqli_fetch_assoc($result);

    $caregiverPic = !empty($caregiverInfo['pic']) 
        ? 'templates/caregiver/uploads/caregivers/' . $caregiverInfo['pic'] 
        : 'assets/img/default-profile.png';


    $caregiverName = $caregiverInfo['full_name'] ?? 'Caregiver';

    ?>
          <li class="nav-item dropdown pe-3">
  <a class="nav-link nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown">
    <?php if (!empty($caregiverPic) && file_exists(__DIR__ . "/../../$caregiverPic")): ?>
      <img src="/elderlycare/<?= htmlspecialchars($caregiverPic); ?>" 
           alt="Profile" 
           class="rounded-circle" 
           style="width: 40px; height: 40px; object-fit: cover;" />
    <?php else: ?>
      <div class="rounded-circle bg-secondary d-flex justify-content-center align-items-center"
           style="width: 40px; height: 40px;">
        <i class="bi bi-person text-white fs-5"></i>
      </div>
    <?php endif; ?>
    <span class="d-none d-md-block dropdown-toggle ps-2"><?= htmlspecialchars($caregiverName) ?></span>
  </a>

  <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow profile">
    <li class="dropdown-header">
      <h6><?= htmlspecialchars($caregiverName) ?></h6>
      <span>Caregiver</span>
    </li>

    <li><hr class="dropdown-divider" /></li>

    <li>
      <a class="dropdown-item d-flex align-items-center" href="caregiver_profile.php">
        <i class="bi bi-person"></i>
        <span>My Profile</span>
      </a>
    </li>

    <li><hr class="dropdown-divider" /></li>

    <li>
      <a class="dropdown-item d-flex align-items-center" href="/elderlycare/logout.php">
    <i class="bi bi-box-arrow-right"></i>
    <span>Sign Out</span>
  </a>
    </li>
  </ul>
</li>

  </nav><!-- End Navbar -->
</header>


<aside id="sidebar" class="sidebar">

    <ul class="sidebar-nav" id="sidebar-nav">

        <li class="nav-item">
            <a class="nav-link collapsed" href="CaregiverDashboard.php">
                <i class="bi bi-grid"></i>
                <span>Dashboard</span>
            </a>
        </li>

        <li class="nav-item">
            <a class="nav-link " href="admin_profile.php">
                <i class="bi bi-person"></i>
                <span>Profile</span>
            </a>
        </li>

    </ul>

</aside>

<main id="main" class="main">

<div class="pagetitle">
    <h2>Profile</h2>
    <nav>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="CaregiverDashboard.php">Home</a></li>
        <li class="breadcrumb-item">Users</li>
        <li class="breadcrumb-item active">Profile</li>
      </ol>
    </nav>
  </div>

  <section class="section profile">
    <div class="row justify-content-center">
      <div class="row">
        <div class="card">
          <div class="card-body pt-3">
            
            <ul class="nav nav-tabs nav-tabs-bordered">
              <li class="nav-item">
                <button class="nav-link active" data-bs-toggle="tab" data-bs-target="#profile-overview">Overview</button>
              </li>
              <li class="nav-item">
                <button class="nav-link" data-bs-toggle="tab" data-bs-target="#profile-edit">Edit Profile</button>
              </li>
              <li class="nav-item">
                <button class="nav-link" data-bs-toggle="tab" data-bs-target="#profile-change-password">Change Password</button>
              </li>
            </ul>
            <div class="tab-content pt-2">
              <div class="tab-pane fade show active profile-overview" id="profile-overview">
                <h5 class="card-title">Profile Details</h5>
                  <div class="row mb-3">
                    <div class="col-lg-3 col-md-4 label">Profile Picture</div>
                    <div class="col-lg-6 col-md-8 text-center">
                      <?php if (!empty($caregiver['pic'])): ?>
                        <img src="uploads/caregivers/<?= $caregiver['pic'] ?>" 
                            alt="Profile Picture" 
                            class="img-fluid" 
                            style="max-width: 150px; border-radius: 20%;">
                      <?php else: ?>
                        <div style="font-size: 100px; color: #ccc;">
                          <i class="bi bi-person-circle"></i>
                        </div>
                      <?php endif; ?>
                    </div>
                </div>


                <div class="row"><div class="col-lg-3 col-md-4 label">Full Name</div><div class="col-lg-9 col-md-8"><?= $caregiver['full_name'] ?></div></div>
                <div class="row"><div class="col-lg-3 col-md-4 label">Birthdate</div><div class="col-lg-9 col-md-8"><?= $caregiver['dob'] ?></div></div>
                <div class="row"><div class="col-lg-3 col-md-4 label">Gender</div><div class="col-lg-9 col-md-8"><?= ucfirst($caregiver['gender']) ?></div></div>
                <div class="row"><div class="col-lg-3 col-md-4 label">Phone</div><div class="col-lg-9 col-md-8"><?= $caregiver['contact_phone'] ?></div></div>
                <div class="row">
                  <div class="col-lg-3 col-md-4 label">Email</div>
                  <div class="col-lg-9 col-md-8"><?= $caregiver['email'] ?></div>
                </div>
                <div class="row"><div class="col-lg-3 col-md-4 label">Address</div><div class="col-lg-9 col-md-8"><?= $caregiver['address'] ?></div></div>
                <div class="row"><div class="col-lg-3 col-md-4 label">Cert. Number</div><div class="col-lg-9 col-md-8"><?= $caregiver['certification_number'] ?: 'N/A' ?></div></div>
                <div class="row"><div class="col-lg-3 col-md-4 label">Experience</div><div class="col-lg-9 col-md-8"><?= $caregiver['experience'] ?> years</div></div>
                <div class="row"><div class="col-lg-3 col-md-4 label">Skills</div><div class="col-lg-9 col-md-8"><?= $caregiver['specialized_skills'] ?: 'N/A' ?></div></div>
                <div class="row"><div class="col-lg-3 col-md-4 label">Availability</div><div class="col-lg-9 col-md-8"><?= ucfirst($caregiver['availability']) ?></div></div>
                <div class="row"><div class="col-lg-3 col-md-4 label">Preferred Hours</div><div class="col-lg-9 col-md-8"><?= $caregiver['preferred_hours'] ?: 'N/A' ?></div></div>
                <div class="row"><div class="col-lg-3 col-md-4 label">Emergency Contact</div><div class="col-lg-9 col-md-8"><?= $caregiver['emergency_contact_name'] ?> (<?= $caregiver['emergency_contact_phone'] ?>)</div></div>
                <div class="row"><div class="col-lg-3 col-md-4 label">Background Check</div><div class="col-lg-9 col-md-8"><?= $caregiver['background_check'] ? 'Passed' : 'Not yet' ?></div></div>
                <div class="row"><div class="col-lg-3 col-md-4 label">Health Check</div><div class="col-lg-9 col-md-8"><?= $caregiver['health_check'] ? 'Passed' : 'Not yet' ?></div></div>
              </div>
  
          <div class="tab-pane fade profile-edit pt-3" id="profile-edit">
            <form action="caregiver_process.php" method="POST"enctype="multipart/form-data">
              <input type="hidden" name="caregiver_id" value="<?= $caregiver_id ?>">
              <input type="hidden" name="remove_image" id="removeImageFlag" value="0">
                <div class="row mb-3">
                  <label for="profileImage" class="col-md-7 col-lg-5 col-form-label">Profile Image</label>
                  <div class="col-lg-2 col-md-8 text-center">
                    <?php if (!empty($caregiver['pic'])): ?>
                      <img src="uploads/caregivers/<?= $caregiver['pic'] ?>" 
                          alt="Profile" 
                          class="img-fluid mb-3 rounded-circle" 
                          style="max-width: 150px;" 
                          id="profileImagePreview">
                    <?php else: ?>
                      <div class="mb-3" style="font-size: 100px; color: #ccc;" id="profileImagePreview">
                        <i class="bi bi-person-circle"></i>
                      </div>
                    <?php endif; ?>

                    <input type="file" name="caregiver_pic" class="form-control" id="profileImageInput" style="display: none;" onchange="previewImage(event)">

                    <div class="d-flex justify-content-center gap-2">
                      <a href="javascript:void(0);" class="btn" title="Upload new profile image" onclick="document.getElementById('profileImageInput').click();">
                        <i class="bi bi-upload"></i> Upload
                      </a>
                      <a href="#" class="btn" title="Remove my profile image" onclick="removeProfileImage(); return false;">
                        <i class="bi bi-trash"></i> Remove
                      </a>
                    </div>
                  </div>
                </div>


              <div class="row mb-3">
                <label class="col-md-4 col-lg-3 col-form-label">Full Name</label>
                <div class="col-md-8 col-lg-9">
                  <input name="full_name" type="text" class="form-control" value="<?= $caregiver['full_name'] ?>">
                </div>
              </div>

              <div class="row mb-3">
                <label class="col-md-4 col-lg-3 col-form-label">Phone</label>
                <div class="col-md-8 col-lg-9">
                  <input name="contact_phone" type="text" class="form-control" value="<?= $caregiver['contact_phone'] ?>">
                </div>
              </div>

              <div class="row mb-3">
                <label class="col-md-4 col-lg-3 col-form-label">Address</label>
                <div class="col-md-8 col-lg-9">
                  <input name="address" type="text" class="form-control" value="<?= $caregiver['address'] ?>">
                </div>
              </div>

             <div class="row mb-3">
                <label class="col-md-4 col-lg-3 col-form-label">Email</label>
                <div class="col-md-8 col-lg-9">
                  <input name="email" type="email" class="form-control" value="<?= $caregiver['email'] ?>">
                </div>
              </div>

              <div class="text-center">
                <button type="submit" name="updateCaregiverprofile"class="btn">Save Changes</button>
              </div>
            </form>
          </div>

             
              <div class="tab-pane fade pt-3" id="profile-change-password">
                
                <form action="caregiver_process.php" method="POST">
                <input type="hidden" name="caregiver_id" value="<?= $caregiver['caregiver_id'] ?>">


                   <div class="row mb-3">
                        <label for="current_password" class="col-md-4 col-lg-3 col-form-label">Current Password</label>
                        <div class="col-md-8 col-lg-9">
                            <div class="input-group">
                                <input name="currentpassword" id="currentpassword" type="password" class="form-control" placeholder="Enter Current Password">
                                <span class="input-group-text" onclick="togglePassword('currentpassword', this)">
                                    <i class="bi bi-eye"></i>
                                </span>
                            </div>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <label for="newpassword" class="col-md-4 col-lg-3 col-form-label">New Password</label>
                        <div class="col-md-8 col-lg-9">
                            <div class="input-group">
                                <input name="newpassword" id="newpassword" type="password" class="form-control" placeholder="Enter New Password">
                                <span class="input-group-text" onclick="togglePassword('newpassword', this)">
                                    <i class="bi bi-eye"></i>
                                </span>
                            </div>
                        </div>
                    </div>


                    <div class="row mb-3">
                        <label for="confirmpassword" class="col-md-4 col-lg-3 col-form-label">Confirm New Password</label>
                        <div class="col-md-8 col-lg-9">
                            <div class="input-group">
                                <input name="confirmpassword" id="confirmpassword" type="password" class="form-control" placeholder="Re-enter New Password">
                                <span class="input-group-text" onclick="togglePassword('confirmpassword', this)">
                                    <i class="bi bi-eye"></i>
                                </span>
                            </div>
                        </div>
                    </div>

                    <div class="text-center">
                        <button type="submit" name="changeCaregiverPassword" class="btn">Change Password</button>


                    </div>
                </form>
              </div>

            </div>
          </div>
        </div>
      </div>
  </section>
</main>
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

<script>
    function togglePassword(inputId, toggleElement) {
        const input = document.getElementById(inputId);
        const icon = toggleElement.querySelector('i');

        if (input.type === 'password') {
            input.type = 'text';
            icon.classList.remove('bi-eye');
            icon.classList.add('bi-eye-slash');
        } else {
            input.type = 'password';
            icon.classList.remove('bi-eye-slash');
            icon.classList.add('bi-eye');
        }
    }
</script>
<script>
function previewImage(event) {
  const reader = new FileReader();
  reader.onload = function () {
    const output = document.getElementById('profileImagePreview');
    if (output.tagName === 'IMG') {
      output.src = reader.result;
    } else {
      output.outerHTML = `<img src="${reader.result}" class="img-fluid mb-3 rounded-circle" style="max-width: 150px;" id="profileImagePreview">`;
    }
  };
  reader.readAsDataURL(event.target.files[0]);
}

function removeProfileImage() {
  document.getElementById('removeImageFlag').value = '1';
  const preview = document.getElementById('profileImagePreview');
  if (preview) preview.style.display = 'none';
}
</script>

<footer id="footer" class="footer">
    <div class="copyright">
        &copy; Copyright <strong><span>FilSha</span></strong>. All Rights Reserved
    </div>
    <div class="credits">
        
    </div>
</footer>

<a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<script src="/elderlycare/assets/js/main.js"></script>


</body>

</html>
