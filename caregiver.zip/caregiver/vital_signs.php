<?php
session_start();


header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

include 'caregiver_dbconnection.php';
include 'medication_notification.php';


if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id']; 
} else {
    header('Location: /elderlycare/templates/caregiver/userLogin.php');
    exit;
}



$sql = "SELECT id, first_name, middle_name, last_name FROM patients WHERE caregiver_id = ?";
$stmt = mysqli_prepare($conn, $sql);
if (!$stmt) {
    die('Failed to prepare the SQL query: ' . mysqli_error($conn));
}

mysqli_stmt_bind_param($stmt, 'i', $user_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$patients = [];
if ($result && mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        $patients[] = $row;
    }


if (isset($_GET['notif_id'])) {
    $notif_id = (int)$_GET['notif_id'];

    // Only mark admin notifications as read
    $updateQuery = "UPDATE admin_notifications SET is_read = 1 WHERE id = ? AND user_type = 'admin'";
    $stmt = mysqli_prepare($conn, $updateQuery);
    mysqli_stmt_bind_param($stmt, 'i', $notif_id);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    $typeQuery = "SELECT type, reference_id FROM admin_notifications WHERE id = ?";
    $stmtType = mysqli_prepare($conn, $typeQuery);
    mysqli_stmt_bind_param($stmtType, 'i', $notif_id);
    mysqli_stmt_execute($stmtType);
    mysqli_stmt_bind_result($stmtType, $type, $reference_id);

    if (mysqli_stmt_fetch($stmtType)) {
        mysqli_stmt_close($stmtType);

        if ($type === 'medicine') {
            header("Location: task_and_notes.php?id=" . urlencode($reference_id));
            exit;
        } else {
            header("Location: password_verify.php");
            exit;
        }
    } else {
        mysqli_stmt_close($stmtType);
        header("Location: password_verify.php");
        exit;
    }
}


$notifQuery = "SELECT * FROM admin_notifications 
               WHERE user_id = ? AND user_type = 'admin' 
               ORDER BY created_at DESC";
$stmt = mysqli_prepare($conn, $notifQuery);
mysqli_stmt_bind_param($stmt, 'i', $user_id);
mysqli_stmt_execute($stmt);
$notifResult = mysqli_stmt_get_result($stmt);

$notifications = [];
while ($row = mysqli_fetch_assoc($notifResult)) {
    $notifications[] = $row;
}
    if (isset($_POST['markAllRead'])) {
        $updateQuery = "UPDATE admin_notifications SET is_read = 1 WHERE user_id = ? AND user_type = 'admin'";
        $stmt = mysqli_prepare($conn, $updateQuery);
        mysqli_stmt_bind_param($stmt, 'i', $user_id);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        // Refresh the page to update notification badge
        header("Location: " . $_SERVER['PHP_SELF']);
        exit;
    }



} else {
    echo "<script>
        alert('Please log in first');
        window.location.href = '/elderlycare/index.php';
    </script>";
    exit;



}


?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Patients</title>

<!-- Favicons -->
<link href="/elderlycare/assets/img/logo.png" rel="icon">
<!-- Google Fonts -->
<link href="https://fonts.gstatic.com" rel="preconnect">
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

<!-- Vendor CSS Files -->
<link href="/elderlycare/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/quill/quill.snow.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/quill/quill.bubble.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/remixicon/remixicon.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/simple-datatables/style.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Template Main CSS File -->
<link href="/elderlycare/assets/css/style.css" rel="stylesheet">
</head>
<style>
  .notification-item.unread {
  background-color: #f0f8ff;
}
.notification-item.unread p {
  font-weight: bold;
}
.notifications {
  max-height: 300px; 
  overflow-y: auto;  
}
table.table-bordered.table-striped tbody td {
  text-align: center;
  vertical-align: middle; 
}
@media (max-width: 576px), (max-width: 780px) {
  .dropdown-menu.profile {
    position: fixed !important;
    top: 60px;
    left: 0 !important;
    right: 0 !important;
    border-radius: 0;
    z-index: 1050;
  }
}

@media (max-width: 576px) {
  .dropdown-menu.notifications {
    position: fixed !important;
    top: 60px;
    left: 0 !important;
    right: 0 !important;
    width: 100vw !important;
    max-width: none !important;
    border-radius: 0;
    z-index: 1050;
  }
}


@media (max-width: 576px) {
  .dropdown-menu.profile,
  .dropdown-menu.notifications {
    position: fixed !important;
    top: 56px;
    left: 0 !important;
    right: 0 !important;
    width: 100vw !important;
    max-width: none !important;
    border-radius: 0;
    z-index: 1050;
    padding: 0.5rem;
  }
  .dropdown-menu.notifications {
    max-height: 300px;
    overflow-y: auto;
  }
}

</style>
<body>


<header id="header" class="header fixed-top d-flex align-items-center">

<div class="d-flex align-items-center justify-content-between">
  <a href="CaregiverDashboard.php" class="logo d-flex align-items-center">
  <img src="/elderlycare/assets/img/logo.png" alt="Logo">
    <span class="d-none d-lg-block">ElderlyCare</span>
  </a>
  <i class="bi bi-list toggle-sidebar-btn"></i>
</div>


  <!-- Navbar items -->
  <nav class="header-nav ms-auto">
    <ul class="d-flex align-items-center">

      <!-- Notification Bell -->
      <li class="nav-item dropdown">
        <a class="nav-link nav-icon" href="#" data-bs-toggle="dropdown">
          <i class="bi bi-bell"></i>
          <?php
          $unreadQuery = "SELECT COUNT(*) AS unread_count FROM admin_notifications WHERE user_id = ? AND user_type = 'admin' AND is_read = 0";
          $stmt = mysqli_prepare($conn, $unreadQuery);
          mysqli_stmt_bind_param($stmt, 'i', $user_id);
          mysqli_stmt_execute($stmt);
          $result = mysqli_stmt_get_result($stmt);
          $unread_count = mysqli_fetch_assoc($result)['unread_count'];
          ?>
          <?php if ($unread_count > 0): ?>
            <span class="badge bg-primary badge-number"><?= $unread_count; ?></span>
          <?php endif; ?>
        </a><!-- End Notification Icon -->

        <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow notifications">
         <li class="dropdown-header">
          <span>
            You have <?= $unread_count; ?> new notification<?= $unread_count !== 1 ? 's' : ''; ?>
          </span>
          <?php if ($unread_count > 0): ?>
            <div class="mt-2">
              <form method="POST">
                <button type="submit" name="markAllRead"  class="btn" style="font-size: 13px; height: 35px;">
                  Mark all as read
                </button>
              </form>
            </div>
          <?php endif; ?>
        </li>

          <li><hr class="dropdown-divider"></li>

          <?php if (count($notifications) > 0): ?>
            <?php foreach ($notifications as $note):
              $liClass = $note['is_read'] == 0 ? 'notification-item unread' : 'notification-item';
            ?>
              <li class="<?= $liClass ?>">
                <a href="?notif_id=<?= $note['id']; ?>" class="d-flex align-items-start text-decoration-none">
                  <i class="bi bi-info-circle text-info me-2"></i>
                  <div>
                    <p class="mb-1"><?= htmlspecialchars($note['message']); ?></p>
                    <small class="text-muted"><?= date("M d, Y H:i", strtotime($note['created_at'])); ?></small>
                  </div>
                </a>
              </li>
              <li><hr class="dropdown-divider"></li>
            <?php endforeach; ?>
          <?php else: ?>
            <li class="notification-item text-center">
              <p>No new notifications</p>
            </li>
          <?php endif; ?>
        </ul>
      </li><!-- End Notification Nav -->

      <!-- Caregiver Profile -->
      <?php
      $caregiverInfoQuery = "SELECT pic, full_name FROM caregivers_info WHERE caregiver_id = ?";
      $stmt = mysqli_prepare($conn, $caregiverInfoQuery);
      mysqli_stmt_bind_param($stmt, 'i', $user_id);
      mysqli_stmt_execute($stmt);
      $result = mysqli_stmt_get_result($stmt);
      $caregiverInfo = mysqli_fetch_assoc($result);

      $caregiverPic = !empty($caregiverInfo['pic']) 
          ? 'templates/caregiver/uploads/caregivers/' . $caregiverInfo['pic'] 
          : 'assets/img/default-profile.png';
      $caregiverName = $caregiverInfo['full_name'] ?? 'Caregiver';
      ?>

      <li class="nav-item dropdown pe-3">
        <a class="nav-link nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown">
          <?php if (!empty($caregiverPic) && file_exists(__DIR__ . "/../../$caregiverPic")): ?>
            <img src="/elderlycare/<?= htmlspecialchars($caregiverPic); ?>" 
                 alt="Profile" 
                 class="rounded-circle" 
                 style="width: 40px; height: 40px; object-fit: cover;" />
          <?php else: ?>
            <div class="rounded-circle bg-secondary d-flex justify-content-center align-items-center"
                 style="width: 40px; height: 40px;">
              <i class="bi bi-person text-white fs-5"></i>
            </div>
          <?php endif; ?>
          <span class="d-none d-md-block dropdown-toggle ps-2"><?= htmlspecialchars($caregiverName) ?></span>
        </a>

        <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow profile">
          <li class="dropdown-header">
            <h6><?= htmlspecialchars($caregiverName) ?></h6>
            <span>Caregiver</span>
          </li>

          <li><hr class="dropdown-divider" /></li>

          <li>
            <a class="dropdown-item d-flex align-items-center" href="caregiver_profile.php">
              <i class="bi bi-person"></i>
              <span>My Profile</span>
            </a>
          </li>

          <li><hr class="dropdown-divider" /></li>

          <li>
            <a class="dropdown-item d-flex align-items-center" href="/elderlycare/logout.php">
              <i class="bi bi-box-arrow-right"></i>
              <span>Sign Out</span>
            </a>
          </li>
        </ul>
      </li>

    </ul>
  </nav><!-- End Navbar --> 


</header>



  <aside id="sidebar" class="sidebar">
  <h3 class="text-white text-center space-below">Caregiver Dashboard</h3>
  <ul class="sidebar-nav" id="sidebar-nav">
    <ul class="sidebar-nav" id="sidebar-nav">
      <li class="nav-item">
        <a class="nav-link collapsed" href="CaregiverDashboard.php">
        <i class="bi bi-house-door"></i>
        <span>Dashboard</span>
      </a>

        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="password_verify.php">
          <i class="bi bi-people"></i>
          <span>My Patients</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="add_patient.php">
          <i class="bi bi-person-plus"></i>
          <span>Add Patient</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link " href="vital_signs.php">
        <i class="bi bi-heart-pulse"></i>
          <span>Vital Signs</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="appointments.php">
        <i class="bi bi-calendar-check"></i>
        <span>Appointments</span>
      </a>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="task_and_notes.php">
          <i class="bi bi-list-check"></i>
          <span>Tasks & Routines</span>
        </a>
      </li>
    
  </aside>
  
  <main id="main" class="main">
  <div class="pagetitle">
    <h2>Vital Signs</h2>
    <nav>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="/dashboard">Home</a></li>
        <li class="breadcrumb-item"><a href="CaregiverDashboard.php">Caregiver Dashboard</a></li>
        <li class="breadcrumb-item active">Vital Signs</li>
      </ol>
    </nav>
  </div>
<section class="section">
  <div class="row">
    <div class="col-lg-12">
      
      <!-- Card: Enter Vital Signs -->
      <div class="card mb-4">
        <div class="card-body">
          <h5 class="card-title">Enter Patient Vital Signs</h5>
          <form action="caregiver_process.php" method="POST">
            <div class="row mb-3">
              <label for="patientId" class="col-sm-2 col-form-label">Patient</label>
              <div class="col-sm-10">
                <select class="form-select" id="patientId" name="patient_id" required>
                  <option value="" selected>Select Patient</option>
                  <?php 
                  $query = "SELECT * FROM patients WHERE caregiver_id = ? AND status = 'approved'"; 
                  $stmt = $conn->prepare($query);
                  $stmt->bind_param("i", $user_id);
                  $stmt->execute();
                  $result = $stmt->get_result();
                  while ($row = $result->fetch_assoc()) {
                    $full_name = trim($row['first_name'] . ' ' . $row['middle_name'] . ' ' . $row['last_name']);
                    echo "<option value='" . $row['id'] . "'>$full_name</option>";
                  }
                  ?>
                </select>
              </div>
            </div>

            <div class="row mb-3">
              <label class="col-sm-2 col-form-label">Blood Pressure</label>
              <div class="col-sm-10">
                <input type="text" class="form-control" name="blood_pressure" placeholder="e.g. 120/80" required>
              </div>
            </div>
            <div class="row mb-3">
              <label class="col-sm-2 col-form-label">Heart Rate (bpm)</label>
              <div class="col-sm-10">
                <input type="text" class="form-control" name="heart_rate" placeholder="e.g. 75" required>
              </div>
            </div>
            <div class="row mb-3">
              <label class="col-sm-2 col-form-label">Temperature (°C)</label>
              <div class="col-sm-10">
                <input type="text" class="form-control" name="temperature" placeholder="e.g. 36.6" required>
              </div>
            </div>
            <div class="row mb-3">
              <label class="col-sm-2 col-form-label">Respiration Rate</label>
              <div class="col-sm-10">
                <input type="text" class="form-control" name="respiration_rate" placeholder="e.g. 18" required>
              </div>
            </div>
            <div class="row mb-3">
              <label class="col-sm-2 col-form-label">Pulse Rate</label>
              <div class="col-sm-10">
                <input type="text" class="form-control" name="pulse_rate" placeholder="e.g. 60–100 bpm" required>
              </div>
            </div>
            <div class="row mb-3">
              <label class="col-sm-2 col-form-label">Oxygen Saturation (%)</label>
              <div class="col-sm-10">
                <input type="text" class="form-control" name="oxygen_saturation" placeholder="e.g. 98" required>
              </div>
            </div>
            <div class="row mb-3">
              <label class="col-sm-2 col-form-label">Notes</label>
              <div class="col-sm-10">
                <textarea class="form-control" name="notes" rows="3" placeholder="Optional notes"></textarea>
              </div>
            </div>

            <div class="d-flex justify-content-center">
              <button type="submit" name="submitvital" class="btn " style="height: 50px;">Save Vital Signs</button>
            </div>
          </form>
        </div>
      </div>

        <!-- Card: Display Vital Signs -->
        <div class="card">
          <div class="card-body">
            <h5 class="card-title">Recent Vital Signs</h5>
            <div class="table-responsive">
              <table class="table table-bordered table-striped">
                <thead>
                  <tr>
                    <th>Date Added</th>
                    <th>Patient</th>
                    <th>Blood Pressure</th>
                    <th>Heart Rate</th>
                    <th>Temperature</th>
                    <th>Respiration Rate</th>
                    <th>Pulse Rate</th>
                    <th>Oxygen Saturation</th>
                    <th>Notes</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                  $query = "
                    SELECT v.*, CONCAT(p.first_name, ' ', p.last_name) AS patient_name
                    FROM vital_signs v
                    JOIN patients p ON v.patient_id = p.id
                    WHERE p.caregiver_id = ?
                    ORDER BY v.created_at DESC
                    LIMIT 10
                  ";
                  $stmt = $conn->prepare($query);
                  $stmt->bind_param("i", $user_id);
                  $stmt->execute();
                  $result = $stmt->get_result();

                  $rows = []; 
                  if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                      $rows[] = $row; 
                  ?>
                    <tr>
                      <td><?= date("Y-m-d", strtotime($row['created_at'])) ?></td>
                      <td><?= htmlspecialchars($row['patient_name']) ?></td>
                      <td><?= htmlspecialchars($row['blood_pressure']) ?></td>
                      <td><?= htmlspecialchars($row['heart_rate']) ?></td>
                      <td><?= htmlspecialchars($row['temperature']) ?></td>
                      <td><?= htmlspecialchars($row['respiration_rate']) ?></td>
                      <td><?= htmlspecialchars($row['pulse_rate']) ?></td>
                      <td><?= htmlspecialchars($row['oxygen_saturation']) ?></td>
                      <td><?= htmlspecialchars($row['notes']) ?></td>
                      <td>
                        <button type="button" class="btn btn-sm" 
                          data-bs-toggle="modal" 
                          data-bs-target="#editVitalModal<?= $row['id'] ?>">
                          Edit
                        </button>

                        <form action="caregiver_process.php" method="POST" style="display:inline;" onsubmit="return confirm('Are you sure you want to delete this record?');">
                          <input type="hidden" name="deleteVital" value="<?= $row['id'] ?>">
                          <button type="submit" class="btn  btn-sm">Delete</button>
                        </form>
                      </td>
                    </tr>
                  <?php
                    }
                  } else {
                    echo '<tr><td colspan="10" class="text-center">No vital signs recorded yet.</td></tr>';
                  }
                  ?>
                </tbody>
              </table>

              <?php
              if (!empty($rows)) {
                foreach ($rows as $row) {
              ?>
                <div class="modal fade" id="editVitalModal<?= $row['id'] ?>" tabindex="-1" aria-labelledby="editVitalModalLabel<?= $row['id'] ?>" aria-hidden="true">
                  <div class="modal-dialog">
                    <form action="caregiver_process.php" method="POST" class="modal-content">
                      <div class="modal-header  text-white">
                        <h5 class="modal-title" id="editVitalModalLabel<?= $row['id'] ?>">Edit Vital Signs</h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                      </div>
                      <div class="modal-body">
                        <input type="hidden" name="id" value="<?= $row['id'] ?>">

                        <div class="mb-3">
                          <label for="blood_pressure_<?= $row['id'] ?>" class="form-label">Blood Pressure</label>
                          <input type="text" class="form-control" id="blood_pressure_<?= $row['id'] ?>" name="blood_pressure" value="<?= htmlspecialchars($row['blood_pressure']) ?>" required>
                        </div>
                        <div class="mb-3">
                          <label for="heart_rate_<?= $row['id'] ?>" class="form-label">Heart Rate (bpm)</label>
                          <input type="text" class="form-control" id="heart_rate_<?= $row['id'] ?>" name="heart_rate" value="<?= htmlspecialchars($row['heart_rate']) ?>" required>
                        </div>
                        <div class="mb-3">
                          <label for="temperature_<?= $row['id'] ?>" class="form-label">Temperature (°C)</label>
                          <input type="text" class="form-control" id="temperature_<?= $row['id'] ?>" name="temperature" value="<?= htmlspecialchars($row['temperature']) ?>" required>
                        </div>
                        <div class="mb-3">
                          <label for="respiration_rate_<?= $row['id'] ?>" class="form-label">Respiration Rate</label>
                          <input type="text" class="form-control" id="respiration_rate_<?= $row['id'] ?>" name="respiration_rate" value="<?= htmlspecialchars($row['respiration_rate']) ?>" required>
                        </div>
                        <div class="mb-3">
                          <label for="pulse_rate_<?= $row['id'] ?>" class="form-label">Pulse Rate</label>
                          <input type="text" class="form-control" id="pulse_rate_<?= $row['id'] ?>" name="pulse_rate" value="<?= htmlspecialchars($row['pulse_rate']) ?>" required>
                        </div>
                        <div class="mb-3">
                          <label for="oxygen_saturation_<?= $row['id'] ?>" class="form-label">Oxygen Saturation (%)</label>
                          <input type="text" class="form-control" id="oxygen_saturation_<?= $row['id'] ?>" name="oxygen_saturation" value="<?= htmlspecialchars($row['oxygen_saturation']) ?>" required>
                        </div>
                        <div class="mb-3">
                          <label for="notes_<?= $row['id'] ?>" class="form-label">Notes</label>
                          <textarea class="form-control" id="notes_<?= $row['id'] ?>" name="notes" rows="3"><?= htmlspecialchars($row['notes']) ?></textarea>
                        </div>
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" name="update_vital" class="btn btn-primary">Save changes</button>
                      </div>
                    </form>
                  </div>
                </div>
              <?php
                }
              }
              ?>

            </div>
          </div>
        </div>

      </div>
    </div>
  </section>

</main>

<script>
  document.querySelector('form').addEventListener('submit', function(event) {
      var patientId = document.getElementById('patientId').value;
      if (patientId === "") {
          alert("Please select a patient.");
          event.preventDefault();
      }
  });
</script>



<footer id="footer" class="footer">
  <div class="copyright">
    &copy; Copyright <strong><span>ElderlyCare</span></strong>. All Rights Reserved
  </div>
</footer>
<script>
  let residentId = null;

  function showUpdateModal(id) {
    residentId = id;
    const updateModal = new bootstrap.Modal(document.getElementById('updateModal'));
    updateModal.show();
  }

  document.getElementById('confirmUpdateButton').addEventListener('click', function () {
    if (residentId !== null) {
     
    }
  });
</script>

<!-- Bootstrap CSS (put in <head>) -->



<!-- Template Main JS File -->
<script src="/elderlycare/assets/js/main.js"></script>
<script src="/elderlycare/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>
