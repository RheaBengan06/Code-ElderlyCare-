<?php
session_start();



header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

include 'caregiver_dbconnection.php'; 
include 'medication_notification.php';

if (!isset($_SESSION['user_id'])) {
    echo "<script>
        alert('Please log in first');
        window.location.href = '/elderlycare/index.php';
    </script>";
    exit();
}

$user_id = $_SESSION['user_id'];


$caregiverInfoQuery = "SELECT pic, full_name FROM caregivers_info WHERE caregiver_id = ?";
$stmt = mysqli_prepare($conn, $caregiverInfoQuery);
mysqli_stmt_bind_param($stmt, 'i', $user_id);
mysqli_stmt_execute($stmt);
$caregiverResult = mysqli_stmt_get_result($stmt);
$caregiverInfo = mysqli_fetch_assoc($caregiverResult);

$caregiverPic = !empty($caregiverInfo['pic']) 
    ? 'templates/caregiver/uploads/caregivers/' . $caregiverInfo['pic'] 
    : 'assets/img/default-profile.png';

$caregiverName = $caregiverInfo['full_name'] ?? 'Caregiver';


$patientQuery = "
    SELECT 
        p.id,
        p.first_name,
        p.middle_name,
        p.last_name,
        p.dob,
        p.gender,
        p.health_status,
        p.profile_picture,
        p.emergency_contact_name,
        p.emergency_contact_number,
        p.relationship,
        p.address,
        p.medications,
        p.notes,
        r.room_number
    FROM patients p
    LEFT JOIN rooms r ON p.room_id = r.id
    WHERE p.caregiver_id = ? AND p.status = 'approved'
";

$stmt = mysqli_prepare($conn, $patientQuery);
mysqli_stmt_bind_param($stmt, 'i', $user_id);
mysqli_stmt_execute($stmt);
$approvedPatientsResult = mysqli_stmt_get_result($stmt);


$pendingRejectedQuery = "
    SELECT 
        id,
        first_name,
        middle_name,
        last_name,
        status
    FROM patients
    WHERE caregiver_id = ? AND (status = 'pending' OR status = 'rejected')
";
$stmt2 = mysqli_prepare($conn, $pendingRejectedQuery);
mysqli_stmt_bind_param($stmt2, 'i', $user_id);
mysqli_stmt_execute($stmt2);
$pendingRejectedResult = mysqli_stmt_get_result($stmt2);


if (isset($_GET['notif_id'])) {
    $notif_id = (int)$_GET['notif_id'];

    // Only mark admin notifications as read
    $updateQuery = "UPDATE admin_notifications SET is_read = 1 WHERE id = ? AND user_type = 'admin'";
    $stmt = mysqli_prepare($conn, $updateQuery);
    mysqli_stmt_bind_param($stmt, 'i', $notif_id);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    $typeQuery = "SELECT type, reference_id FROM admin_notifications WHERE id = ?";
    $stmtType = mysqli_prepare($conn, $typeQuery);
    mysqli_stmt_bind_param($stmtType, 'i', $notif_id);
    mysqli_stmt_execute($stmtType);
    mysqli_stmt_bind_result($stmtType, $type, $reference_id);

    if (mysqli_stmt_fetch($stmtType)) {
        mysqli_stmt_close($stmtType);

        if ($type === 'medicine') {
            header("Location: task_and_notes.php?id=" . urlencode($reference_id));
            exit;
        } else {
            header("Location: password_verify.php");
            exit;
        }
    } else {
        mysqli_stmt_close($stmtType);
        header("Location: password_verify.php");
        exit;
    }
}


$notifQuery = "SELECT * FROM admin_notifications 
               WHERE user_id = ? AND user_type = 'admin' 
               ORDER BY created_at DESC";
$stmt = mysqli_prepare($conn, $notifQuery);
mysqli_stmt_bind_param($stmt, 'i', $user_id);
mysqli_stmt_execute($stmt);
$notifResult = mysqli_stmt_get_result($stmt);

$notifications = [];
while ($row = mysqli_fetch_assoc($notifResult)) {
    $notifications[] = $row;
}
    if (isset($_POST['markAllRead'])) {
        $updateQuery = "UPDATE admin_notifications SET is_read = 1 WHERE user_id = ? AND user_type = 'admin'";
        $stmt = mysqli_prepare($conn, $updateQuery);
        mysqli_stmt_bind_param($stmt, 'i', $user_id);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        // Refresh the page to update notification badge
        header("Location: " . $_SERVER['PHP_SELF']);
        exit;
    }



function calculateAge($dob) {
    if (!$dob) return 'N/A';
    $birthDate = new DateTime($dob);
    $today = new DateTime();
    return $today->diff($birthDate)->y;
}

?>








  <!DOCTYPE html>
  <html lang="en">
  <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>My Patients</title>

      <!-- Favicons -->
      <link href="/elderlycare/assets/img/logo.png" rel="icon">

      <!-- Google Fonts -->
      <link href="https://fonts.gstatic.com" rel="preconnect">
      <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

      <!-- Vendor CSS Files -->
      <link href="/elderlycare/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
      <link href="/elderlycare/assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
      <link href="/elderlycare/assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
      <link href="/elderlycare/assets/vendor/quill/quill.snow.css" rel="stylesheet">
      <link href="/elderlycare/assets/vendor/quill/quill.bubble.css" rel="stylesheet">
      <link href="/elderlycare/assets/vendor/remixicon/remixicon.css" rel="stylesheet">
      <link href="/elderlycare/assets/vendor/simple-datatables/style.css" rel="stylesheet">

      <!-- Template Main CSS File -->
      <link href="/elderlycare/assets/css/style.css" rel="stylesheet">
  </head>


  <style>
    .table , th , td{
      vertical-align: middle;
    }

    .centered-btn {
      display: center;
      align-items: center;
      justify-content: center;
      width: 70px;

      
  }
  .notification-item.unread {
    background-color: #f0f8ff;
  }
  .notification-item.unread p {
    font-weight: bold;
  }
  .notifications {
    max-height: 300px; 
    overflow-y: auto;  
  }
@media (max-width: 576px), (max-width: 780px) {
  .dropdown-menu.profile {
    position: fixed !important;
    top: 60px;
    left: 0 !important;
    right: 0 !important;
    border-radius: 0;
    z-index: 1050;
  }
}

@media (max-width: 576px) {
  .dropdown-menu.notifications {
    position: fixed !important;
    top: 60px;
    left: 0 !important;
    right: 0 !important;
    width: 100vw !important;
    max-width: none !important;
    border-radius: 0;
    z-index: 1050;
  }
}


  </style>
  <body>


  <header id="header" class="header fixed-top d-flex align-items-center">

  <div class="d-flex align-items-center justify-content-between">
    <a href="CaregiverDashboard.php" class="logo d-flex align-items-center">
    <img src="/elderlycare/assets/img/logo.png" alt="Logo">
      <span class="d-none d-lg-block">ElderlyCare</span>
    </a>
    <i class="bi bi-list toggle-sidebar-btn"></i>
  </div>

  <nav class="header-nav ms-auto">
    <ul class="d-flex align-items-center">

      <li class="nav-item dropdown">
        <a class="nav-link nav-icon" href="#" data-bs-toggle="dropdown">
          <i class="bi bi-bell"></i>
          <?php
          $unreadQuery = "SELECT COUNT(*) AS unread_count FROM admin_notifications WHERE user_id = ? AND user_type = 'admin' AND is_read = 0";
          $stmt = mysqli_prepare($conn, $unreadQuery);
          mysqli_stmt_bind_param($stmt, 'i', $user_id);
          mysqli_stmt_execute($stmt);
          $result = mysqli_stmt_get_result($stmt);
          $unread_count = mysqli_fetch_assoc($result)['unread_count'];
          ?>
          <?php if ($unread_count > 0): ?>
            <span class="badge bg-primary badge-number"><?= $unread_count; ?></span>
          <?php endif; ?>
        </a><!-- End Notification Icon -->

        <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow notifications">
         <li class="dropdown-header">
          <span>
            You have <?= $unread_count; ?> new notification<?= $unread_count !== 1 ? 's' : ''; ?>
          </span>
          <?php if ($unread_count > 0): ?>
            <div class="mt-2">
              <form method="POST">
                <button type="submit" name="markAllRead"  class="btn" style="font-size: 13px; height: 35px;">
                  Mark all as read
                </button>
              </form>
            </div>
          <?php endif; ?>
        </li>

          <li><hr class="dropdown-divider"></li>

          <?php if (count($notifications) > 0): ?>
            <?php foreach ($notifications as $note):
              $liClass = $note['is_read'] == 0 ? 'notification-item unread' : 'notification-item';
            ?>
              <li class="<?= $liClass ?>">
                <a href="?notif_id=<?= $note['id']; ?>" class="d-flex align-items-start text-decoration-none">
                  <i class="bi bi-info-circle text-info me-2"></i>
                  <div>
                    <p class="mb-1"><?= htmlspecialchars($note['message']); ?></p>
                    <small class="text-muted"><?= date("M d, Y H:i", strtotime($note['created_at'])); ?></small>
                  </div>
                </a>
              </li>
              <li><hr class="dropdown-divider"></li>
            <?php endforeach; ?>
          <?php else: ?>
            <li class="notification-item text-center">
              <p>No new notifications</p>
            </li>
          <?php endif; ?>
        </ul>
      </li><!-- End Notification Nav -->

          <li class="nav-item dropdown pe-3">
  <a class="nav-link nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown">
    <?php if (!empty($caregiverPic) && file_exists(__DIR__ . "/../../$caregiverPic")): ?>
      <img src="/elderlycare/<?= htmlspecialchars($caregiverPic); ?>" 
           alt="Profile" 
           class="rounded-circle" 
           style="width: 40px; height: 40px; object-fit: cover;" />
    <?php else: ?>
      <div class="rounded-circle bg-secondary d-flex justify-content-center align-items-center"
           style="width: 40px; height: 40px;">
        <i class="bi bi-person text-white fs-5"></i>
      </div>
    <?php endif; ?>
    <span class="d-none d-md-block dropdown-toggle ps-2"><?= htmlspecialchars($caregiverName) ?></span>
  </a>

  <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow profile">
    <li class="dropdown-header">
      <h6><?= htmlspecialchars($caregiverName) ?></h6>
      <span>Caregiver</span>
    </li>

    <li><hr class="dropdown-divider" /></li>

    <li>
      <a class="dropdown-item d-flex align-items-center" href="caregiver_profile.php">
        <i class="bi bi-person"></i>
        <span>My Profile</span>
      </a>
    </li>

    <li><hr class="dropdown-divider" /></li>

    <li>
      <a class="dropdown-item d-flex align-items-center" href="/elderlycare/logout.php">
        <i class="bi bi-box-arrow-right"></i>
        <span>Sign Out</span>
      </a>
    </li>
  </ul>
</li>
    </nav>
  </header>

  <aside id="sidebar" class="sidebar">
    <h3 class="text-white text-center space-below">Caregiver Dashboard</h3>
    <ul class="sidebar-nav" id="sidebar-nav">
      <ul class="sidebar-nav" id="sidebar-nav">
        <li class="nav-item">
          <a class="nav-link collapsed" href="CaregiverDashboard.php">
          <i class="bi bi-house-door"></i>
          <span>Dashboard</span>
        </a>

          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link " href="patients_list.php">
              <i class="bi bi-people"></i>
              <span>My Patients</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link collapsed" href="add_patient.php">
            <i class="bi bi-person-plus"></i>
            <span>Add Patient</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link collapsed" href="vital_signs.php">
          <i class="bi bi-heart-pulse"></i>
            <span>Vital Signs</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link collapsed" href="appointments.php">
          <i class="bi bi-calendar-check"></i>
          <span>Appointments</span>
        </a>
        </li>
        <li class="nav-item">
          <a class="nav-link collapsed" href="task_and_notes.php">
            <i class="bi bi-list-check"></i>
            <span>Tasks & Routines</span>
          </a>
        </li>
      
    </aside>
 
  <main id="main" class="main">
  <div class="pagetitle">
    <h2>My Patient</h2>
    <nav>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="/dashboard">Home</a></li>
        <li class="breadcrumb-item"><a href="CaregiverDashboard.php">Caregiver Dashboard</a></li>  
        <li class="breadcrumb-item active">Add Patient</li>
      </ol>
    </nav>
  </div>

  <section class="section">
    <div class="row">
      <div class="col-12">
        <div class="card mb-4">
          <div class="card-body">
            <h5 class="card-title">List of Patients</h5>

            <div class="tasks-notes mb-3">
              <h6>Patient Records</h6>
              <div class="table-responsive">
                <table class="table table-bordered table-hover">
                  <thead class="table-light">
                    <tr>
                      <th>#</th>
                      <th>Patient ID</th>
                      <th>Room No.</th>
                      <th>Full Name</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php
                    include 'caregiver_dbconnection.php'; 
                    $row_number = 1;
                    while ($row = mysqli_fetch_assoc($approvedPatientsResult)) {
                      $patient_id = $row['id'];
                      $roomNumber = !empty($row['room_number']) ? htmlspecialchars($row['room_number']) : 'No room assigned';
                      $full_name = trim($row['first_name'] . ' ' . $row['middle_name'] . ' ' . $row['last_name']);
                      $personToContact = htmlspecialchars($row['emergency_contact_name']) . 
                                        ' (' . htmlspecialchars($row['emergency_contact_number']) . ') - ' . 
                                        htmlspecialchars($row['relationship']);
                      $age = calculateAge($row['dob']);
                      $gender = !empty($row['gender']) ? htmlspecialchars($row['gender']) : 'Not specified';
                    ?>
                    <tr>
                      <td><?php echo $row_number++; ?></td>
                      <td><?php echo $patient_id; ?></td>
                      <td><?php echo $roomNumber; ?></td>
                      <td><?php echo $full_name; ?></td>
                      <td class="text-nowrap">
                        <button type="button" class="btn btn-sm  mb-1" data-bs-toggle="modal" data-bs-target="#viewPatientModal<?php echo $patient_id; ?>">View</button>
                        <button type="button" class="btn btn-sm  mb-1" onclick="if(confirm('Are you sure you want to delete this patient?')) window.location.href='caregiver_process.php?id=<?php echo $patient_id; ?>'">Delete</button>
                      </td>
                    </tr>

                    <!-- View Modal -->
                    <div class="modal fade" id="viewPatientModal<?php echo $patient_id; ?>" tabindex="-1" aria-labelledby="viewPatientModalLabel" aria-hidden="true">
                      <div class="modal-dialog modal-dialog-scrollable">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h5 class="modal-title">Patient Details - <?php echo $full_name; ?></h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                          </div>
                          <div class="modal-body">
                            <ul class="list-group list-group-flush">
                              <li class="list-group-item"><strong>Patient ID:</strong> <?php echo $patient_id; ?></li>
                              <li class="list-group-item"><strong>Full Name:</strong> <?php echo $full_name; ?></li>
                              <li class="list-group-item"><strong>Date of Birth:</strong> <?php echo $row['dob']; ?></li>
                              <li class="list-group-item"><strong>Age:</strong> <?php echo $age; ?></li>
                              <li class="list-group-item"><strong>Gender:</strong> <?php echo $gender; ?></li>
                              <li class="list-group-item"><strong>Room Number:</strong> <?php echo $roomNumber; ?></li>
                              <li class="list-group-item"><strong>Health Status:</strong> <?php echo $row['health_status']; ?></li>
                              <li class="list-group-item"><strong>Person to Contact:</strong> <?= $personToContact ?></li>
                              <li class="list-group-item"><strong>Address:</strong> <?php echo $row['address']; ?></li>
                              <li class="list-group-item"><strong>Medication:</strong> <?php echo $row['medications']; ?></li>
                              <li class="list-group-item"><strong>Notes:</strong> <?php echo $row['notes']; ?></li>
                              <li class="list-group-item">
                                <strong>Profile Picture:</strong><br>
                                <img src="/ElderlyCare/templates/caregiver/uploads/patients/<?php echo !empty($row['profile_picture']) ? $row['profile_picture'] : 'default-avatar.png'; ?>" alt="Profile Picture" class="img-thumbnail" style="width: 100px; height: 100px; object-fit: cover;">
                              </li>
                            </ul>
                          </div>
                          <div class="modal-footer">
                            <button type="button" class="btn " data-bs-toggle="modal" data-bs-target="#editPatientModal<?php echo $patient_id; ?>">Edit</button>
                            <button type="button" class="btn " data-bs-dismiss="modal">Close</button>
                          </div>
                        </div>
                      </div>
                    </div>

                    <!-- Edit Modal (scrollable for mobile) -->
                    <div class="modal fade" id="editPatientModal<?php echo $patient_id; ?>" tabindex="-1" aria-hidden="true">
                      <div class="modal-dialog modal-dialog-scrollable">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h5 class="modal-title">Edit Patient - <?php echo $full_name; ?></h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                          </div>
                          <div class="modal-body">
                            <form method="POST" action="caregiver_process.php" enctype="multipart/form-data">
                              <input type="hidden" name="patient_id" value="<?php echo $patient_id; ?>">

                              <div class="mb-2"><label>First Name:</label><input type="text" name="first_name" class="form-control" value="<?php echo $row['first_name']; ?>" required></div>
                              <div class="mb-2"><label>Middle Name:</label><input type="text" name="middle_name" class="form-control" value="<?php echo $row['middle_name']; ?>"></div>
                              <div class="mb-2"><label>Last Name:</label><input type="text" name="last_name" class="form-control" value="<?php echo $row['last_name']; ?>" required></div>
                              <div class="mb-2"><label>Date of Birth:</label><input type="date" name="dob" class="form-control" value="<?php echo $row['dob']; ?>"></div>
                              <div class="mb-2"><label>Health Status:</label><input type="text" name="health_status" class="form-control" value="<?php echo $row['health_status']; ?>"></div>
                              <div class="mb-2"><label>Emergency Contact Name:</label><input type="text" name="emergency_contact_name" class="form-control" value="<?php echo $row['emergency_contact_name']; ?>"></div>
                              <div class="mb-2"><label>Emergency Contact Number:</label><input type="text" name="emergency_contact_number" class="form-control" value="<?php echo $row['emergency_contact_number']; ?>"></div>
                              <div class="mb-2"><label>Relationship:</label><input type="text" name="relationship" class="form-control" value="<?php echo $row['relationship']; ?>"></div>
                              <div class="mb-2"><label>Address:</label><textarea name="address" class="form-control"><?php echo $row['address']; ?></textarea></div>
                              <div class="mb-2"><label>Medications:</label><textarea name="medications" class="form-control"><?php echo $row['medications']; ?></textarea></div>
                              <div class="mb-2"><label>Notes:</label><textarea name="notes" class="form-control"><?php echo $row['notes']; ?></textarea></div>
                              <div class="mb-2">
                                <label>Change Profile Picture:</label><br>
                                <input type="file" name="profile_picture" class="form-control">
                                <small class="text-muted">Current:</small><br>
                                <img src="/ElderlyCare/templates/caregiver/uploads/patients/<?php echo !empty($row['profile_picture']) ? $row['profile_picture'] : 'default-avatar.png'; ?>" class="img-thumbnail" style="width: 100px; height: 100px; object-fit: cover;">
                              </div>

                              <div class="d-flex justify-content-between mt-3">
                                <button type="submit" name="update_patient" class="btn ">Update</button>
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                              </div>
                            </form>
                          </div>
                        </div>
                      </div>
                    </div>

                    <?php } ?>
                  </tbody>
                </table>
              </div>
            </div>

            <!-- Pending / Rejected Patients -->
            <h6 class="mt-4">Pending / Rejected Patients</h6>
            <div class="table-responsive">
              <table class="table table-bordered table-hover">
                <thead class="table-light">
                  <tr>
                    <th>#</th>
                    <th>Patient ID</th>
                    <th>Full Name</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                  $pending_row_number = 1;
                  while ($row = mysqli_fetch_assoc($pendingRejectedResult)) {
                    $full_name = $row['first_name'] . ' ' . $row['middle_name'] . ' ' . $row['last_name'];
                  ?>
                  <tr>
                    <td><?php echo $pending_row_number++; ?></td>
                    <td><?php echo $row['id']; ?></td>
                    <td><?php echo $full_name; ?></td>
                    <td><span class="badge bg-<?php echo $row['status'] === 'pending' ? 'warning' : 'danger'; ?>"><?php echo ucfirst($row['status']); ?></span></td>
                  </tr>
                  <?php } ?>
                </tbody>
              </table>
            </div>

          </div>
        </div>
      </div>
    </div>
  </section>
</main>

<!-- Password Confirmation Modal -->
<div class="modal fade" id="passwordConfirmModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Confirm Access</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <p>Please enter your account password to continue:</p>
        <input type="password" id="confirmPasswordInput" class="form-control" placeholder="Enter password">
        <div id="passwordError" class="text-danger mt-2" style="display:none;">Invalid password. Please try again.</div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        <button class="btn btn-primary" id="confirmPasswordBtn">Confirm</button>
      </div>
    </div>
  </div>
</div>
<script>
document.addEventListener("DOMContentLoaded", function() {
    let targetUrl = "";

   
    document.querySelectorAll(".sensitive-link").forEach(link => {
        link.addEventListener("click", function(e) {
            e.preventDefault(); 
            targetUrl = this.getAttribute("href"); 
            let modal = new bootstrap.Modal(document.getElementById("passwordConfirmModal"));
            modal.show();
        });
    });

    
    document.getElementById("confirmPasswordBtn").addEventListener("click", function() {
        let password = document.getElementById("confirmPasswordInput").value;

        fetch("caregiver_process.php", {
            method: "POST",
            headers: {"Content-Type": "application/x-www-form-urlencoded"},
            body: new URLSearchParams({
                action: "verify_sensitive_panel_password",
                password: password
            })
        })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                window.location.href = targetUrl; 
            } else {
                document.getElementById("passwordError").style.display = "block";
            }
        });
    });
});
</script>



      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

  <footer id="footer" class="footer">
    <div class="copyright">
      &copy; Copyright <strong><span>ElderlyCare</span></strong>. All Rights Reserved
    </div>
  </footer>
  <script>
    let residentId = null;

    function showUpdateModal(id) {
      residentId = id;
      const updateModal = new bootstrap.Modal(document.getElementById('updateModal'));
      updateModal.show();
    }

    document.getElementById('confirmUpdateButton').addEventListener('click', function () {
      if (residentId !== null) {
       
      }
    });
  </script>


<script src="/elderlycare/idle-logout.js"></script>

  </body>
  </html>
