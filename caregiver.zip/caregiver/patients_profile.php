<?php
session_start();



header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

include 'caregiver_dbconnection.php'; 


if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    $email = $_SESSION['email'];

} else {
    echo "<script>
        alert('Please log in first');
        window.location.href = '/elderlycare/index.php';
    </script>";
    exit;
}
?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Caregiver's Profile</title>

<!-- Favicons -->
<link href="/elderlycare/assets/img/logo.png" rel="icon">

<!-- Google Fonts -->
<link href="https://fonts.gstatic.com" rel="preconnect">
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

<!-- Vendor CSS Files -->
<link href="/elderlycare/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/quill/quill.snow.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/quill/quill.bubble.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/remixicon/remixicon.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/simple-datatables/style.css" rel="stylesheet">

<!-- Template Main CSS File -->
<link href="/elderlycare/assets/css/style.css" rel="stylesheet">
</head>
<body>


<header id="header" class="header fixed-top d-flex align-items-center">

<div class="d-flex align-items-center justify-content-between">
  <a href="CaregiverDashboard.php" class="logo d-flex align-items-center">
  <img src="/elderlycare/assets/img/logo.png" alt="Logo">
    <span class="d-none d-lg-block">ElderlyCare</span>
  </a>
  <i class="bi bi-list toggle-sidebar-btn"></i>
</div>

<div class="search-bar">
  <form class="search-form d-flex align-items-center" method="POST" action="#">
    <input type="text" name="query" placeholder="Search" title="Enter search keyword">
    <button type="submit" title="Search"><i class="bi bi-search"></i></button>
  </form>
</div>

<nav class="header-nav ms-auto">
  <ul class="d-flex align-items-center">

    <li class="nav-item d-block d-lg-none">
      <a class="nav-link nav-icon search-bar-toggle " href="#">
        <i class="bi bi-search"></i>
      </a>
    </li>


      <li class="nav-item dropdown">
        <a class="nav-link nav-icon" href="#" data-bs-toggle="dropdown">
          <i class="bi bi-bell"></i>
          <span class="badge bg-primary badge-number">4</span>
        </a>
        <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow notifications">
          <li class="dropdown-header">
            You have 4 new notifications
            <a href="#"><span class="badge rounded-pill bg-primary p-2 ms-2">View all</span></a>
          </li>
          <li>
            <hr class="dropdown-divider">
          </li>

        </ul>
      </li>


      <li class="nav-item dropdown pe-3">
        <a class="nav-link nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown">
          <img src="/elderlycare/assets/img/dan.jpg" alt="Profile" class="rounded-circle">
          <span class="d-none d-md-block dropdown-toggle ps-2">Tuala</span>
        </a>

        <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow profile">
          <li class="dropdown-header">
            <h6>Tuala</h6>
            <span>Admin</span>
          </li>
          <li>
            <hr class="dropdown-divider">
          </li>

          <li>
            <a class="dropdown-item d-flex align-items-center" href="caregiver_profile.php">
              <i class="bi bi-person"></i>
              <span>My Profile</span>
            </a>
          </li>
          <li>
            <hr class="dropdown-divider">
          </li>

          <li>
            <a class="dropdown-item d-flex align-items-center" href="/elderlycare/logout.php">
              <i class="bi bi-box-arrow-right"></i>
              <span>Sign Out</span>
            </a>
      </li>
    </ul>
  </nav>
</header>


<aside id="sidebar" class="sidebar">
  <h3 class="text-white text-center space-below">Caregiver Dashboard</h3>
  <ul class="sidebar-nav" id="sidebar-nav">
    <ul class="sidebar-nav" id="sidebar-nav">
      <li class="nav-item">
        <a class="nav-link collapsed" href="CaregiverDashboard.php">
        <i class="bi bi-house-door"></i>
        <span>Dashboard</span>
      </a>

        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link  " href="patients_profile.php">
        <i class="bi bi-person-circle"></i>
        <span>Caregiver's Profile</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed " href="patients_list.php">
            <i class="bi bi-people"></i>
            <span>My Patients</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="add_patient.php">
          <i class="bi bi-person-plus"></i>
          <span>Add Patient</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="vital_signs.php">
        <i class="bi bi-heart-pulse"></i>
          <span>Vital Signs</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="appointments.php">
        <i class="bi bi-calendar-check"></i>
        <span>Appointments</span>
      </a>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="task_and_notes.php">
          <i class="bi bi-list-check"></i>
          <span>Tasks & Routines</span>
        </a>
      </li>
    
  </aside>
  <main id="main" class="main">
  <div class="pagetitle">
    <h2>Caregiver's Profile</h2>
    <nav>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="CaregiverDashboard.php">Home</a></li>
        <li class="breadcrumb-item active">Caregiver's Profile</li>
      </ol>
    </nav>
  </div>

  <section class="section">
    <div class="row">
      <div class="col-lg-12">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title">Caregiver's Overview</h5>

            <div class="patient-profile">
              <div class="row">
                <div class="col-md-4">
                  <img src="/elderlycare/assets/img/patient.jpg" alt="Patient Profile" class="img-fluid rounded-circle">
                </div>
                <div class="col-md-8">
                  <h3>John Doe</h3>
                  <p><strong>Age: </strong> 72</p>
                  <p><strong>Health Status: </strong> Healthy</p>
                  <p><strong>Caregiver: </strong> Jane Smith</p>
                  <p><strong>Emergency Contact: </strong> Sarah Doe - 555-1234</p>
                </div>
              </div>
            </div>

            
            <div class="medical-info mt-4">
              <h4>Medical Information</h4>
              <ul>
                <li><strong>Medications: </strong> Blood Pressure Medication, Diabetes Medication</li>
                <li><strong>Allergies: </strong> Penicillin</li>
                <li><strong>Medical History: </strong> Hypertension, Type 2 Diabetes</li>
              </ul>
            </div>

            
            <div class="appointments mt-4">
              <h4>Upcoming Appointments</h4>
              <table class="table">
                <thead>
                  <tr>
                    <th>Date</th>
                    <th>Doctor</th>
                    <th>Reason</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>Feb 10, 2025</td>
                    <td>Dr. Smith</td>
                    <td>Routine Checkup</td>
                  </tr>
                  <tr>
                    <td>Feb 15, 2025</td>
                    <td>Dr. Johnson</td>
                    <td>Cardiology Consultation</td>
                  </tr>
                </tbody>
              </table>
            </div>

            
            <div class="contact-info mt-4">
              <h4>Contact Information</h4>
              <ul>
                <li><strong>Primary Caregiver: </strong> Jane Smith - 555-6789</li>
                <li><strong>Emergency Contact: </strong> Sarah Doe - 555-1234</li>
              </ul>
            </div>

            
            <div class="medical-history mt-4">
              <h4>Vital Signs</h4>
              <ul>
                <li><strong>Blood Pressure: </strong> 120/80 mmHg</li>
                <li><strong>Heart Rate: </strong> 72 bpm</li>
                <li><strong>Temperature: </strong> 98.6°F</li>
              </ul>
            </div>

            
            <div class="manage-patient mt-4" style="display: flex; justify-content: center; gap: 10px;">
              <button class="btn"  style="height: 50px;" onclick="showUpdateModal(1)">Update Profile</button>
              <button class="btn"  style="height: 50px;"onclick="deleteProfile(1)">Delete Profile</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</main>

<footer id="footer" class="footer">
  <div class="copyright">
    &copy; Copyright <strong><span>ElderlyCare</span></strong>. All Rights Reserved
  </div>
</footer>
<script>
  let residentId = null;

  function showUpdateModal(id) {
    residentId = id;
    const updateModal = new bootstrap.Modal(document.getElementById('updateModal'));
    updateModal.show();
  }

  document.getElementById('confirmUpdateButton').addEventListener('click', function () {
    if (residentId !== null) {
      
    }
  });
</script>


<!-- Template Main JS File -->
<script src="/elderlycare/assets/js/main.js"></script>
<script src="/elderlycare/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>
