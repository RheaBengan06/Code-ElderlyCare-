<?php
if (session_status() === PHP_SESSION_NONE) session_start();
include 'caregiver_dbconnection.php';

if (!isset($_SESSION['user_id'])) exit("Not logged in");
$caregiver_id = $_SESSION['user_id'];

// Fetch linked relative
$stmt = $conn->prepare("SELECT r.id, r.name FROM relatives r 
                        JOIN patients p ON r.patient_id = p.id 
                        WHERE p.caregiver_id = ? LIMIT 1");
$stmt->bind_param("i", $caregiver_id);
$stmt->execute();
$relative = $stmt->get_result()->fetch_assoc();
if (!$relative) exit("No relative found");

$relative_id = $relative['id'];
$relative_name = $relative['name'];

// Handle sending message
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $message = trim($_POST['message'] ?? '');

    $stmt = $conn->prepare("
        INSERT INTO messages (sender_type, sender_id, receiver_id, message) 
        VALUES ('caregiver', ?, ?, ?)
    ");
    $stmt->bind_param("iis", $caregiver_id, $relative_id, $message);
    $stmt->execute();
    exit;
}

// Fetch messages
if (isset($_GET['fetch'])) {
    $stmt = $conn->prepare("SELECT * FROM messages 
        WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?)
        ORDER BY timestamp ASC");
    $stmt->bind_param("iiii", $caregiver_id, $relative_id, $relative_id, $caregiver_id);
    $stmt->execute();
    $messages = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    echo json_encode($messages);
    exit;
}

// Fetch unseen messages count
if (isset($_GET['unseen'])) {
    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM messages WHERE sender_type='relative' AND sender_id=? AND receiver_id=? AND is_seen=0");
    $stmt->bind_param("ii", $relative_id, $caregiver_id);
    $stmt->execute();
    $count = $stmt->get_result()->fetch_assoc();
    echo json_encode($count);
    exit;
}
?>


<!-- Chat HTML -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">

<div id="chat-icon" style="position:fixed;bottom:20px;right:20px;background:#3b83f0;color:white;border-radius:50%;width:60px;height:60px;display:flex;justify-content:center;align-items:center;cursor:pointer;box-shadow:0 4px 10px rgba(0,0,0,0.3);z-index:9999;">
  <i class="bi bi-chat-dots-fill" style="font-size:28px;"></i>
  <span id="newMsgIndicator" style="position:absolute;top:5px;right:5px;width:12px;height:12px;background:red;border-radius:50%;display:none;"></span>
</div>

<div id="chat-box" style="position:fixed;bottom:85px;right:20px;width:350px;background:white;border:1px solid #ccc;border-radius:10px;box-shadow:0 4px 12px rgba(0,0,0,0.2);display:none;z-index:9999;">
  <div style="background:#0d6efd;color:white;padding:10px;border-radius:10px 10px 0 0;">
    <strong><?php echo htmlspecialchars($relative_name); ?></strong>
    <span id="close-chat" style="float:right;cursor:pointer;">&times;</span>
  </div>

  <div id="chat-messages" style="height:250px;overflow-y:auto;padding:10px;"></div>

  <div style="display:flex;align-items:center;padding:8px;border-top:1px solid #ccc;">
    <input type="text" id="messageInput" class="form-control" placeholder="Type a message...">
    <button id="sendMsg" class="btn btn-primary ms-2">Send</button>
  </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
const chatBox = $('#chat-box');
const chatIcon = $('#chat-icon');
const chatMessages = $('#chat-messages');
const messageInput = $('#messageInput');
const newMsgIndicator = $('#newMsgIndicator');

// Open/close chat
chatIcon.click(()=>{ 
    chatBox.fadeIn(200); 
    chatIcon.fadeOut(200); 
    newMsgIndicator.hide(); 
});
$('#close-chat').click(()=>{ 
    chatBox.fadeOut(200); 
    chatIcon.fadeIn(200); 
});

// Load messages
function loadMessages(scroll=true) {
    $.get('messages.php', { fetch: 1 }, function(data) {
        let messages = JSON.parse(data);
        const atBottom = chatMessages[0].scrollHeight - chatMessages.scrollTop() - chatMessages.outerHeight() < 50;

        chatMessages.html('');
        messages.forEach(msg => {
            let cls = msg.sender_type === 'caregiver' ? 'sent' : 'received';
            chatMessages.append(`
                <div class="message ${cls}" style="
                    padding:8px 12px; border-radius:10px; margin-bottom:5px; max-width:75%;
                    background:${cls==='sent'?'#007bff':'#e5e5e5'};
                    color:${cls==='sent'?'#fff':'#000'};
                    margin-left:${cls==='sent'?'auto':'0'};
                    margin-right:${cls==='sent'?'0':'auto'};">
                    ${msg.message}
                </div>
            `);
        });

        if(scroll && atBottom){
            chatMessages.scrollTop(chatMessages[0].scrollHeight);
        }
    });
}

// Check new messages indicator
function checkNewMessages() {
    $.get('messages.php', { unseen: 1 }, function(data) {
        let res = JSON.parse(data);
        if(res.count > 0 && chatBox.is(':hidden')) {
            newMsgIndicator.show();
        } else {
            newMsgIndicator.hide();
        }
    });
}

setInterval(loadMessages, 2000);
setInterval(checkNewMessages, 3000);
loadMessages();
checkNewMessages();

// Send message
$('#sendMsg').click(()=>{
    const msg = messageInput.val().trim();
    if(msg === '') return;

    $.post('messages.php', { message: msg }, ()=>{
        messageInput.val('');
        loadMessages();
        newMsgIndicator.hide();
    });
});

// Enter key to send
messageInput.keypress(e=>{
    if(e.which===13){ 
        $('#sendMsg').click(); 
        return false; 
    }
});
</script>
