<?php
include 'caregiver_dbconnection.php';

$caregiver_id = $_SESSION['user_id'];

$medicineNotifQuery = "
    SELECT pm.id, p.first_name, p.last_name, pm.medicine_name, pm.dosage, pm.time_to_take
    FROM patient_medicines pm
    INNER JOIN patients p ON pm.patient_id = p.id
    WHERE pm.caregiver_id = ?
      AND DATE(pm.time_to_take) = CURDATE()
      AND TIME(pm.time_to_take) BETWEEN CURTIME() AND ADDTIME(CURTIME(), '00:15:00')
";



$stmtMed = mysqli_prepare($conn, $medicineNotifQuery);
mysqli_stmt_bind_param($stmtMed, "i", $caregiver_id);
mysqli_stmt_execute($stmtMed);
$resultMed = mysqli_stmt_get_result($stmtMed);

while ($med = mysqli_fetch_assoc($resultMed)) {
    $notif_message = "Time to give {$med['medicine_name']} ({$med['dosage']}) to {$med['first_name']} {$med['last_name']} at " . date("h:i A", strtotime($med['time_to_take']));
    
    
    $checkNotif = mysqli_prepare($conn, "SELECT id FROM admin_notifications WHERE user_id = ? AND user_type = 'caregiver' AND message = ? AND DATE(created_at) = CURDATE()");
    mysqli_stmt_bind_param($checkNotif, "is", $caregiver_id, $notif_message);
    mysqli_stmt_execute($checkNotif);
    mysqli_stmt_store_result($checkNotif);

    if (mysqli_stmt_num_rows($checkNotif) == 0) {
        $insertNotif = mysqli_prepare($conn, "INSERT INTO admin_notifications (user_id, user_type, type, message, is_read, created_at) VALUES (?, 'caregiver', 'medicine', ?, 0, NOW())");
        mysqli_stmt_bind_param($insertNotif, "is", $caregiver_id, $notif_message);
        mysqli_stmt_execute($insertNotif);

    }
}

?>