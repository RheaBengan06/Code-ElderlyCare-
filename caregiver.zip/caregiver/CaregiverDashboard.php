<?php
session_start();

header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

include 'caregiver_dbconnection.php'; 
include 'medication_notification.php';

if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    $email = $_SESSION['email'];     

if (isset($_GET['notif_id'])) {
    $notif_id = (int)$_GET['notif_id'];

    // Only mark admin notifications as read
    $updateQuery = "UPDATE admin_notifications SET is_read = 1 WHERE id = ? AND user_type = 'admin'";
    $stmt = mysqli_prepare($conn, $updateQuery);
    mysqli_stmt_bind_param($stmt, 'i', $notif_id);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    $typeQuery = "SELECT type, reference_id FROM admin_notifications WHERE id = ?";
    $stmtType = mysqli_prepare($conn, $typeQuery);
    mysqli_stmt_bind_param($stmtType, 'i', $notif_id);
    mysqli_stmt_execute($stmtType);
    mysqli_stmt_bind_result($stmtType, $type, $reference_id);

    if (mysqli_stmt_fetch($stmtType)) {
        mysqli_stmt_close($stmtType);

        if ($type === 'medicine') {
            header("Location: task_and_notes.php?id=" . urlencode($reference_id));
            exit;
        } else {
            header("Location: password_verify.php");
            exit;
        }
    } else {
        mysqli_stmt_close($stmtType);
        header("Location: password_verify.php");
        exit;
    }
}

$notifQuery = "SELECT * FROM admin_notifications 
               WHERE user_id = ? AND user_type = 'admin' 
               ORDER BY created_at DESC";
$stmt = mysqli_prepare($conn, $notifQuery);
mysqli_stmt_bind_param($stmt, 'i', $user_id);
mysqli_stmt_execute($stmt);
$notifResult = mysqli_stmt_get_result($stmt);

$notifications = [];
while ($row = mysqli_fetch_assoc($notifResult)) {
    $notifications[] = $row;
}
    // Handle "Mark all as read" button
    if (isset($_POST['markAllRead'])) {
        $updateQuery = "UPDATE admin_notifications SET is_read = 1 WHERE user_id = ? AND user_type = 'admin'";
        $stmt = mysqli_prepare($conn, $updateQuery);
        mysqli_stmt_bind_param($stmt, 'i', $user_id);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        // Refresh the page to update notification badge
        header("Location: " . $_SERVER['PHP_SELF']);
        exit;
    }


    $patientQuery = "SELECT COUNT(*) AS total_patients FROM patients WHERE caregiver_id = ?";
    $stmt = mysqli_prepare($conn, $patientQuery);
    mysqli_stmt_bind_param($stmt, 'i', $user_id);
    mysqli_stmt_execute($stmt);
    $patientResult = mysqli_stmt_get_result($stmt);
    $totalPatients = ($patientResult && mysqli_num_rows($patientResult) > 0) 
        ? mysqli_fetch_assoc($patientResult)['total_patients'] 
        : 0;

    
    $pendingQuery = "SELECT COUNT(*) AS pending_count FROM patients WHERE caregiver_id = ? AND status = 'pending'";
    $stmt = mysqli_prepare($conn, $pendingQuery);
    mysqli_stmt_bind_param($stmt, 'i', $user_id);
    mysqli_stmt_execute($stmt);
    $pendingResult = mysqli_stmt_get_result($stmt);
    $pendingPatients = ($pendingResult && mysqli_num_rows($pendingResult) > 0) 
        ? mysqli_fetch_assoc($pendingResult)['pending_count'] 
        : 0;



date_default_timezone_set('Asia/Manila');
$month = isset($_GET['month']) ? (int)$_GET['month'] : (int)date('n');
$year = isset($_GET['year']) ? (int)$_GET['year'] : (int)date('Y');

if (!checkdate($month, 1, $year)) {
    $month = (int)date('n');
    $year = (int)date('Y');
}

$prevMonth = $month - 1;
$nextMonth = $month + 1;
$prevYear = $year;
$nextYear = $year;

if ($prevMonth < 1) {
    $prevMonth = 12;
    $prevYear--;
}
if ($nextMonth > 12) {
    $nextMonth = 1;
    $nextYear++;
}

$monthName = date('F', mktime(0, 0, 0, $month, 1, $year));

$daysInMonth = cal_days_in_month(CAL_GREGORIAN, $month, $year);
$firstDayOfMonth = date('w', strtotime("$year-$month-01"));

// Prepare appointments by date for the calendar
$appointmentsByDate = [];
$sql = "SELECT a.appointment_date, a.title, a.patient_full_name 
        FROM appointments a
        WHERE MONTH(a.appointment_date) = ? 
          AND YEAR(a.appointment_date) = ? 
          AND a.caregiver_id = ?";  
$stmt = $conn->prepare($sql);
$stmt->bind_param("iii", $month, $year, $caregiver_id); 
$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    $appointmentDate = date('j', strtotime($row['appointment_date']));
    $appointmentsByDate[$appointmentDate][] = $row;
}





} else {
    echo "<script>
        alert('Please log in first');
        window.location.href = '/elderlycare/index.php';
    </script>";
    exit;
}

 $caregiver_id = $user_id;

$tasks = [];
$query = "SELECT pt.*, 
                 CONCAT(p.first_name, ' ', IFNULL(p.middle_name, ''), ' ', p.last_name) AS patient_name 
          FROM patient_tasks pt
          JOIN patients p ON pt.patient_id = p.id
          WHERE pt.caregiver_id = ?";
$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, 'i', $caregiver_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

while ($row = mysqli_fetch_assoc($result)) {
    $tasks[] = $row;
}



?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Dashboard</title>

    <link href="/elderlycare/assets/img/logo.png" rel="icon">

<!-- Google Fonts -->
<link href="https://fonts.gstatic.com" rel="preconnect">
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

<!-- Vendor CSS Files -->
<link href="/elderlycare/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/quill/quill.snow.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/quill/quill.bubble.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/remixicon/remixicon.css" rel="stylesheet">
<link href="/elderlycare/assets/vendor/simple-datatables/style.css" rel="stylesheet">

<!-- Template Main CSS File -->
<link href="/elderlycare/assets/css/style.css" rel="stylesheet">

</head>

<style>
.notification-item.unread {
    background-color: #f0f8ff;
}
.notification-item.unread p {
    font-weight: bold;
}
.notifications {
    max-height: 300px; 
    overflow-y: auto;  
}

.reminder-container-wrapper {
    display: flex;
    gap: 20px;
    justify-content: center;
    flex-wrap: wrap;
    margin: 20px 0;
}

.reminder-box {
    background-color: #f0f8ff;
    border-top: 6px solid rgb(84, 145, 209);
    padding: 10px;
    border-radius: 10px;
    box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
    font-family: Arial, sans-serif;
    width: 30%;            
    max-width: 350px;      
    height: 200px;        
    overflow-y: auto;      
    box-sizing: border-box;
    text-align: left;
}

.reminder-box h4 {
    color: rgb(201, 34, 45);
    margin-bottom: 15px;
}

.reminder-box ul {
    list-style-type: none;
    padding-left: 0;
    margin: 0;
}

.reminder-box li, 
.reminder-box p.i {
    background: #ffffff;
    padding: 12px 15px;
    margin-bottom: 10px;
    border: 1px solid #ddd;
    border-radius: 6px;
    transition: background 0.3s;
}

.reminder-box li:hover {
    background-color: #f9f9f9;
}

.reminder-box li strong {
    color: #333;
}

@media (max-width: 576px), (max-width: 780px) {
    .dropdown-menu.profile {
        position: fixed !important;
        top: 60px;
        left: 0 !important;
        right: 0 !important;
        border-radius: 0;
        z-index: 1050;
    }
}

@media (max-width: 576px) {
    .dropdown-menu.notifications {
        position: fixed !important;
        top: 60px;
        left: 0 !important;
        right: 0 !important;
        width: 100vw !important;
        max-width: none !important;
        border-radius: 0;
        z-index: 1050;
    }
}
.calendar-wrapper {
    display: grid;
    grid-template-columns: repeat(7, 1fr); /* 7 days per week */
    grid-auto-rows: 120px; /* fixed height for each day */
    gap: 8px;
    max-width: 90%;
    margin: 0 auto;
    padding: 5px;
}

.day-card {
    border: 1px solid #ddd;
    border-radius: 6px;
    padding: 6px;
    display: flex;
    flex-direction: column;
    justify-content: flex-start;
    overflow: hidden;
    background: #fdfdfd;
    box-shadow: 0 1px 3px rgba(0,0,0,0.05);
    cursor: pointer;
    transition: all 0.3s ease;
    max-height: 90px; /* initial fixed height */
}

/* Expanded state */
.day-card.expanded {
    max-height: 500px; /* enough to show full content */
    overflow: visible;
}

/* Scrollable list if needed */
.day-card ul {
    padding-left: 8px;
    margin: 0;
    overflow-y: auto;
}


/* Text styling */
.day-card strong {
    font-size: 0.9rem;
    margin-bottom: 4px;
}

.day-card li {
    font-size: 0.8rem;
    margin-bottom: 2px;
}


.day-card.past-appointment {
    background: #f8d7da;
}

.day-card.future-appointment {
    background: #d1ecf1;
}

/* Responsive adjustments */
@media (max-width: 992px) {
    .calendar-wrapper {
        grid-template-columns: repeat(4, 1fr);
    }
}

@media (max-width: 768px) {
    .calendar-wrapper {
        grid-template-columns: repeat(2, 1fr);
    }
}

@media (max-width: 576px) {
    .calendar-wrapper {
        grid-template-columns: 1fr;
    }
}
/* Hover effect for day card */
.day-card:hover {
    transform: scale(1.05);          /* slightly zoom the card */
    z-index: 10;                      /* bring it on top of others */
    box-shadow: 0 4px 12px rgba(0,0,0,0.2); /* stronger shadow */
    transition: transform 0.2s, box-shadow 0.2s;
}

/* Optional: pointer cursor */
.day-card:hover {
    cursor: pointer;
}

/* Scrollable list remains the same */
.day-card ul {
    flex-grow: 1;
    overflow-y: auto;
}



</style>
<body>



<header id="header" class="header fixed-top d-flex align-items-center">

  <div class="d-flex align-items-center justify-content-between">
    <a href="CaregiverDashboard.php" class="logo d-flex align-items-center">
      <img src="/elderlycare/assets/img/logo.png" alt="Logo">
      <span class="d-none d-lg-block">ElderlyCare</span>
    </a>
    <i class="bi bi-list toggle-sidebar-btn"></i>
  </div><!-- End Logo -->

  <!-- Navbar items -->
  <nav class="header-nav ms-auto">
    <ul class="d-flex align-items-center">

      <!-- Notification Bell -->
      <li class="nav-item dropdown">
        <a class="nav-link nav-icon" href="#" data-bs-toggle="dropdown">
          <i class="bi bi-bell"></i>
          <?php
          $unreadQuery = "SELECT COUNT(*) AS unread_count FROM admin_notifications WHERE user_id = ? AND user_type = 'admin' AND is_read = 0";
          $stmt = mysqli_prepare($conn, $unreadQuery);
          mysqli_stmt_bind_param($stmt, 'i', $user_id);
          mysqli_stmt_execute($stmt);
          $result = mysqli_stmt_get_result($stmt);
          $unread_count = mysqli_fetch_assoc($result)['unread_count'];
          ?>
          <?php if ($unread_count > 0): ?>
            <span class="badge bg-primary badge-number"><?= $unread_count; ?></span>
          <?php endif; ?>
        </a><!-- End Notification Icon -->

        <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow notifications">
         <li class="dropdown-header">
          <span>
            You have <?= $unread_count; ?> new notification<?= $unread_count !== 1 ? 's' : ''; ?>
          </span>
          <?php if ($unread_count > 0): ?>
            <div class="mt-2">
              <form method="POST">
                <button type="submit" name="markAllRead"  class="btn" style="font-size: 13px; height: 35px;">
                  Mark all as read
                </button>
              </form>
            </div>
          <?php endif; ?>
        </li>

          <li><hr class="dropdown-divider"></li>

          <?php if (count($notifications) > 0): ?>
            <?php foreach ($notifications as $note):
              $liClass = $note['is_read'] == 0 ? 'notification-item unread' : 'notification-item';
            ?>
              <li class="<?= $liClass ?>">
                <a href="?notif_id=<?= $note['id']; ?>" class="d-flex align-items-start text-decoration-none">
                  <i class="bi bi-info-circle text-info me-2"></i>
                  <div>
                    <p class="mb-1"><?= htmlspecialchars($note['message']); ?></p>
                    <small class="text-muted"><?= date("M d, Y H:i", strtotime($note['created_at'])); ?></small>
                  </div>
                </a>
              </li>
              <li><hr class="dropdown-divider"></li>
            <?php endforeach; ?>
          <?php else: ?>
            <li class="notification-item text-center">
              <p>No new notifications</p>
            </li>
          <?php endif; ?>
        </ul>
      </li><!-- End Notification Nav -->

      <!-- Caregiver Profile -->
      <?php
      $caregiverInfoQuery = "SELECT pic, full_name FROM caregivers_info WHERE caregiver_id = ?";
      $stmt = mysqli_prepare($conn, $caregiverInfoQuery);
      mysqli_stmt_bind_param($stmt, 'i', $user_id);
      mysqli_stmt_execute($stmt);
      $result = mysqli_stmt_get_result($stmt);
      $caregiverInfo = mysqli_fetch_assoc($result);

      $caregiverPic = !empty($caregiverInfo['pic']) 
          ? 'templates/caregiver/uploads/caregivers/' . $caregiverInfo['pic'] 
          : 'assets/img/default-profile.png';
      $caregiverName = $caregiverInfo['full_name'] ?? 'Caregiver';
      ?>

      <li class="nav-item dropdown pe-3">
        <a class="nav-link nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown">
          <?php if (!empty($caregiverPic) && file_exists(__DIR__ . "/../../$caregiverPic")): ?>
            <img src="/elderlycare/<?= htmlspecialchars($caregiverPic); ?>" 
                 alt="Profile" 
                 class="rounded-circle" 
                 style="width: 40px; height: 40px; object-fit: cover;" />
          <?php else: ?>
            <div class="rounded-circle bg-secondary d-flex justify-content-center align-items-center"
                 style="width: 40px; height: 40px;">
              <i class="bi bi-person text-white fs-5"></i>
            </div>
          <?php endif; ?>
          <span class="d-none d-md-block dropdown-toggle ps-2"><?= htmlspecialchars($caregiverName) ?></span>
        </a>

        <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow profile">
          <li class="dropdown-header">
            <h6><?= htmlspecialchars($caregiverName) ?></h6>
            <span>Caregiver</span>
          </li>

          <li><hr class="dropdown-divider" /></li>

          <li>
            <a class="dropdown-item d-flex align-items-center" href="caregiver_profile.php">
              <i class="bi bi-person"></i>
              <span>My Profile</span>
            </a>
          </li>

          <li><hr class="dropdown-divider" /></li>

          <li>
            <a class="dropdown-item d-flex align-items-center" href="/elderlycare/logout.php">
              <i class="bi bi-box-arrow-right"></i>
              <span>Sign Out</span>
            </a>
          </li>
        </ul>
      </li>

    </ul>
  </nav><!-- End Navbar --> 

</header><!-- End Header -->



<aside id="sidebar" class="sidebar">
  
  <h3 class="text-white text-center space-below">Caregiver Dashboard</h3>
  <ul class="sidebar-nav" id="sidebar-nav">
    
    <li class="nav-item">
      <a class="nav-link" href="CaregiverDashboard.php">
        <i class="bi bi-house-door"></i>
        <span>Dashboard</span>
      </a>
    </li>
<li class="nav-item">
  <a class="nav-link collapsed" href="password_verify.php">
    <i class="bi bi-people"></i>
    <span>My Patients</span>
  </a>
</li>

    <li class="nav-item">
      <a class="nav-link collapsed" href="add_patient.php">
        <i class="bi bi-person-plus"></i>
        <span>Add Patient</span>
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link collapsed" href="vital_signs.php">
        <i class="bi bi-heart-pulse"></i>
        <span>Vital Signs</span>
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link collapsed" href="appointments.php">
        <i class="bi bi-calendar-check"></i>
        <span>Appointments</span>
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link collapsed" href="task_and_notes.php">
        <i class="bi bi-list-check"></i>
        <span>Tasks & Routines</span>
      </a>
    </li>
  </ul>
</aside>

<main id="main" class="main">
<?php if (isset($_SESSION['message'])): ?>
<div id="login-alert" class="alert alert-success fade show mt-5" 
     role="alert" 
     style="max-width: 500px; margin: 0 auto; text-align: center;">
    <?= $_SESSION['message']; ?>
</div>
<?php unset($_SESSION['message']); endif; ?>

<script>
    setTimeout(() => {
        const alertBox = document.getElementById('login-alert');
        if (alertBox) {
            alertBox.classList.remove('show');
            alertBox.classList.add('hide');
            setTimeout(() => alertBox.remove(), 300); 
        }
    }, 3000);
</script>

    <div class="pagetitle">
        <h2>Dashboard</h2>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="AdminDashboard.php">Home</a></li>
                <li class="breadcrumb-item active">Dashboard</li>
            </ol>
        </nav>
    </div>

    <section class="section dashboard">

    <?php

date_default_timezone_set('Asia/Manila');

$today = date('Y-m-d');
$target_date = date('Y-m-d', strtotime('+2 days')); // Still used to mark notified
$tomorrow = date('Y-m-d', strtotime('+1 day'));

$stmt = $conn->prepare("SELECT id, appointment_date, appointment_time, title, patient_full_name, notified
                        FROM appointments
                        WHERE caregiver_id = ?
                          AND appointment_date >= ? AND appointment_date <= ?");
$stmt->bind_param("iss", $user_id, $today, $target_date);
$stmt->execute();
$upcoming = $stmt->get_result();

$upcomingAppointments = [];
$toUpdate = [];

while ($row = $upcoming->fetch_assoc()) {
    $upcomingAppointments[] = $row;
    if (is_null($row['notified']) || $row['notified'] == 0) {
        $toUpdate[] = $row['id'];
    }
}

if (!empty($toUpdate)) {
    $placeholders = implode(',', array_fill(0, count($toUpdate), '?'));
    $types = str_repeat('i', count($toUpdate));

    $updSql = "UPDATE appointments SET notified = 1 WHERE id IN ($placeholders)";
    $upd = $conn->prepare($updSql);

    $params = array_merge([$types], $toUpdate);
    $tmp = [];
    foreach ($params as $key => $value) {
        $tmp[$key] = &$params[$key];
    }

    call_user_func_array([$upd, 'bind_param'], $tmp);
    $upd->execute();
}

$visibleAppointments = array_filter($upcomingAppointments, function ($appt) use ($today, $target_date) {
    return $appt['appointment_date'] >= $today && $appt['appointment_date'] <= $target_date;
});

$upcomingCount = count($visibleAppointments);
?>
<?php if ($upcomingCount > 0): ?>
  <div class="reminder-container-wrapper">

    <div class="reminder-box appointment-reminder">
      <h4>📅 Appointment Reminders:</h4>
      <ul>
        <?php if (!empty($visibleAppointments)): ?>
          <?php foreach ($visibleAppointments as $row): ?>
            <?php
              $label = '';
              $apptDate = $row['appointment_date'];
              if ($apptDate === $today) {
                $label = "<span style='color: red;'>[Today]</span>";
              } elseif ($apptDate === $tomorrow) {
                $label = "<span style='color: orange;'>[Tomorrow]</span>";
              } else {
                $label = "<span style='color: blue;'>In 2 days</span>";
              }
            ?>
            <li>
              <?= $label ?> <strong><?= htmlspecialchars($row['title']) ?></strong> 
              of Patient <strong><?= htmlspecialchars($row['patient_full_name']) ?></strong> on 
              <?= htmlspecialchars($row['appointment_date']) ?> at 
              <?= htmlspecialchars($row['appointment_time']) ?>
            </li>
          <?php endforeach; ?>
        <?php else: ?>
          <p>No upcoming appointments within 2 days.</p>
        <?php endif; ?>
      </ul>
    </div>

    <?php
    $today = date('Y-m-d');

    $taskReminderQuery = "
      SELECT pt.id AS task_id,
             pt.task_description,
             pt.routine_time,
             CONCAT(p.first_name, ' ', IFNULL(p.middle_name,''), ' ', p.last_name) AS full_name
      FROM patient_tasks pt
      JOIN patients p ON p.id = pt.patient_id
      WHERE p.caregiver_id = ?
        AND NOT EXISTS (
            SELECT 1 FROM task_completion_log tcl
            WHERE tcl.task_id = pt.id
              AND DATE(tcl.completed_at) = CURDATE()
              AND tcl.caregiver_id = ?
        )
      ORDER BY pt.routine_time
    ";

    $stmtTaskRemind = mysqli_prepare($conn, $taskReminderQuery);
    mysqli_stmt_bind_param($stmtTaskRemind, "ii", $caregiver_id, $caregiver_id);
    mysqli_stmt_execute($stmtTaskRemind);
    $taskRemindersResult = mysqli_stmt_get_result($stmtTaskRemind);

    $medReminderQuery = "
      SELECT pm.id AS medicine_id,
             pm.medicine_name,
             pm.dosage,
             pm.time_to_take,
             CONCAT(p.first_name, ' ', IFNULL(p.middle_name,''), ' ', p.last_name) AS full_name
      FROM patient_medicines pm
      JOIN patients p ON pm.patient_id = p.id
      WHERE p.caregiver_id = ?
        AND NOT EXISTS (
            SELECT 1 FROM medicine_log ml
            WHERE ml.medicine_id = pm.id
              AND DATE(ml.administered_at) = ?
              AND ml.caregiver_id = ?
        )
      ORDER BY pm.time_to_take
    ";

    $stmtMedRemind = mysqli_prepare($conn, $medReminderQuery);
    if (!$stmtMedRemind) {
      die("Prepare failed: " . mysqli_error($conn));
    }
    mysqli_stmt_bind_param($stmtMedRemind, "isi", $caregiver_id, $today, $caregiver_id);
    mysqli_stmt_execute($stmtMedRemind);
    $medRemindersResult = mysqli_stmt_get_result($stmtMedRemind);
    ?>

    <div class="reminder-box task-reminder">
      <h4>📝 Today's Task Reminders</h4>
      <?php if (mysqli_num_rows($taskRemindersResult) > 0): ?>
        <ul>
          <?php while ($task = mysqli_fetch_assoc($taskRemindersResult)): ?>
            <li>
              <strong><?= htmlspecialchars($task['full_name']) ?></strong> - 
              <?= htmlspecialchars($task['task_description']) ?> at 
              <?= date("h:i A", strtotime($task['routine_time'])) ?>
            </li>
          <?php endwhile; ?>
        </ul>
      <?php else: ?>
        <p class="i">No tasks pending for today.</p>
      <?php endif; ?>
    </div>

    <div class="reminder-box medicine-reminder">
      <h4>💊 Today's Medicine Reminders</h4>
      <?php if (mysqli_num_rows($medRemindersResult) > 0): ?>
        <ul>
          <?php while ($med = mysqli_fetch_assoc($medRemindersResult)): ?>
            <li>
              <strong><?= htmlspecialchars($med['full_name']) ?></strong> - 
              <?= htmlspecialchars($med['medicine_name']) ?> (<?= htmlspecialchars($med['dosage']) ?>) at 
              <?= date("h:i A", strtotime($med['time_to_take'])) ?>
            </li>
          <?php endwhile; ?>
        </ul>
      <?php else: ?>
        <p class="i">No medicines pending for today.</p>
      <?php endif; ?>
    </div>

  </div> 
<?php endif; ?>



        <div class="row">

            <div class="col-lg-12">
                <div class="row">

                    <div class="col-xxl-6 col-md-6">
                        <div class="card info-card patients-card">
                            <div class="card-body">
                                <h5 class="card-title">Total Patients</h5>
                                <div class="d-flex align-items-center justify-content-center">
                                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                        <i class="bi bi-people"></i>
                                    </div>
                                    <div class="ps-3">
                                        <h2 style="color:rgb(21, 63, 141);"><?php echo htmlspecialchars($totalPatients); ?></h2>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xxl-6 col-md-6">
                        <div class="card info-card pending-patients-card">
                            <div class="card-body">
                                <h5 class="card-title">Pending Patients</h5>
                                <div class="d-flex align-items-center justify-content-center">
                                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                        <i class="bi bi-person-plus"></i>
                                    </div>
                                    <div class="ps-3">
                                        <h2 style="color:rgb(21, 63, 141);"><?php echo htmlspecialchars($pendingPatients); ?></h2>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
<div class="row appointments-row">
  <div class="col-12">
      <div class="card info-card appointments-card">
          <div class="card-body">
              <h5 class="card-title"><?php echo $monthName . " $year"; ?> - Appointments</h5>

              <div class="calendar-nav d-flex justify-content-between mb-3">
                  <form method="GET" action="">
                      <input type="hidden" name="month" value="<?php echo $prevMonth; ?>">
                      <input type="hidden" name="year" value="<?php echo $prevYear; ?>">
                      <button type="submit" class="btn">Previous</button>
                  </form>

                  <form method="GET" action="">
                      <input type="hidden" name="month" value="<?php echo $nextMonth; ?>">
                      <input type="hidden" name="year" value="<?php echo $nextYear; ?>">
                      <button type="submit" class="btn">Next</button>
                  </form>
              </div>

              <div class="calendar-wrapper">
                  <?php
                  $currentDate = date('Y-m-d');

                  for ($day = 1; $day <= $daysInMonth; $day++):
                      $appointmentsForDay = isset($appointmentsByDate[$day]) ? $appointmentsByDate[$day] : [];
                      $isPast = false;
                      foreach ($appointmentsForDay as $appointment) {
                          if (strtotime($appointment['appointment_date']) < strtotime($currentDate)) {
                              $isPast = true;
                              break;
                          }
                      }
                      $dayClass = $isPast ? 'past-appointment' : 'future-appointment';
                  ?>
                      <div class="day-card <?= $dayClass ?>">
                          <strong>Day <?= $day ?></strong>
                          <?php if (!empty($appointmentsForDay)): ?>
                              <ul>
                                  <?php foreach ($appointmentsForDay as $appt): ?>
                                      <li>
                                          <strong><?= htmlspecialchars($appt['title']) ?></strong><br>
                                          Patient: <?= htmlspecialchars($appt['patient_full_name']) ?>
                                      </li>
                                  <?php endforeach; ?>
                              </ul>
                          <?php else: ?>
                              <p>No appointments</p>
                          <?php endif; ?>
                      </div>
                  <?php endfor; ?>
              </div>
          </div>
      </div>
  </div>
</div>


          </div>
      </div>
  </div>
</div>


    </section>
</main>

<footer id="footer" class="footer">
  <div class="copyright">
    &copy; Copyright <strong><span>ElderlyCare</span></strong>. All Rights Reserved
  </div>
</footer>
<script>
  let residentId = null;

  function showUpdateModal(id) {
    residentId = id;
    const updateModal = new bootstrap.Modal(document.getElementById('updateModal'));
    updateModal.show();
  }

  document.getElementById('confirmUpdateButton').addEventListener('click', function () {
    if (residentId !== null) {
      
    }
  });
</script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
      
        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-toggle="tooltip"]'));
        var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });



    });
</script>
<script>
const dayCards = document.querySelectorAll('.day-card');

dayCards.forEach(card => {
    card.addEventListener('click', () => {
        // Collapse other cards first (optional)
        dayCards.forEach(c => {
            if (c !== card) c.classList.remove('expanded');
        });

        // Toggle expansion
        card.classList.toggle('expanded');
    });
});

</script>

<script src="/elderlycare/assets/vendor/apexcharts/apexcharts.min.js"></script>
<script src="/elderlycare/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="/elderlycare/assets/vendor/chart.js/chart.umd.js"></script>
<script src="/elderlycare/assets/vendor/echarts/echarts.min.js"></script>
<script src="/elderlycare/assets/vendor/quill/quill.js"></script>
<script src="/elderlycare/assets/vendor/simple-datatables/simple-datatables.js"></script>
<script src="/elderlycare/assets/vendor/tinymce/tinymce.min.js"></script>
<script src="/elderlycare/assets/vendor/php-email-form/validate.js"></script>


<script src="/elderlycare/assets/js/main.js"></script>
<?php include 'messages.php'; ?>

</body>
</html>
